import { useState, useEffect } from 'react';
import { MathParser } from './utils/parser';
import { CalcMode, HistoryItem, CalcKeyType } from './types';
import Keypad from './components/Keypad';
import GraphingView from './components/GraphingView';
import HistorySidebar from './components/HistorySidebar';
import ConverterView from './components/ConverterView';
import SpecialCalculationView from './components/SpecialCalculationView';
import FormulasView from './components/FormulasView';
import MoneyView from './components/MoneyView';
import { PWAInstallButton } from './components/PWAInstallButton';
import { OfflineIndicator } from './components/OfflineIndicator';
import {
  Calculator,
  LineChart,
  Activity,
  Maximize2,
  FolderSync,
  Sparkles,
  Info,
  ExternalLink,
  Sigma,
  Binary,
  Compass,
  Coins,
} from 'lucide-react';

export default function App() {
  const [mode, setMode] = useState<CalcMode>('scientific');
  const [expression, setExpression] = useState<string>('');
  const [result, setResult] = useState<string>('');
  const [isDegrees, setIsDegrees] = useState<boolean>(false);
  const [memory, setMemory] = useState<number | null>(null);
  const [calculusFormula, setCalculusFormula] = useState<string>('x * sin(x)');
  const [specialOption, setSpecialOption] = useState<'derivation_integration' | 'permutation_combinational' | 'ap_gp'>('derivation_integration');
  const [specialSubOption, setSpecialSubOption] = useState<'derivation' | 'integration' | 'permutation' | 'combination' | 'ap' | 'gp' | undefined>(undefined);
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('calc_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [errorState, setErrorState] = useState<string | null>(null);

  // Synchronize history with local storage
  useEffect(() => {
    try {
      localStorage.setItem('calc_history', JSON.stringify(history));
    } catch (err) {
      console.error("Failed to persist history:", err);
    }
  }, [history]);

  // Evaluate the expression and set the active result
  const handleEvaluate = (exprToEval: string) => {
    if (!exprToEval || exprToEval.trim() === '') {
      setResult('');
      setErrorState(null);
      return;
    }

    try {
      const parser = new MathParser({ isDegrees });
      const val = parser.evaluate(exprToEval);

      // Sane result rounding
      let output = '';
      if (Math.abs(val) < 1e-10 && val !== 0) {
        output = '0'; // filter floating-point noise e.g. sin(pi)
      } else if (Math.abs(val) < 1e-9 || Math.abs(val) > 1e12) {
        output = val.toExponential(8);
      } else {
        // limit floating noise but keep precise decimal values
        output = Number(val.toFixed(10)).toString();
      }

      setResult(output);
      setErrorState(null);

      // Append to calculation history lists
      const newItem: HistoryItem = {
        id: Math.random().toString(36).substring(2, 9),
        expression: exprToEval,
        result: output,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      };
      setHistory((prev) => [newItem, ...prev].slice(0, 40)); // Cap history records at last 40 items
    } catch (err: any) {
      setResult('');
      setErrorState(err.message || 'Syntax Error');
    }
  };

  // Gracefully handles key clicks
  const handleKeyPress = (value: string, type: CalcKeyType) => {
    setErrorState(null);

    if (value === 'CALC_INTEGRAL') {
      if (expression.trim() !== '') {
        setCalculusFormula(expression);
      }
      setSpecialOption('derivation_integration');
      setSpecialSubOption('integration');
      setMode('special');
      return;
    }

    if (value === 'CALC_DERIVATIVE') {
      if (expression.trim() !== '') {
        setCalculusFormula(expression);
      }
      setSpecialOption('derivation_integration');
      setSpecialSubOption('derivation');
      setMode('special');
      return;
    }

    if (value === 'AC') {
      setExpression('');
      setResult('');
      return;
    }

    if (value === 'BACKSPACE') {
      setExpression((prev) => {
        // Backspace utility to drop functional blocks e.g., 'sin('
        const functionsToMatch = [
          'asin(', 'acos(', 'atan(', 'sinh(', 'cosh(', 'tanh(',
          'sin(', 'cos(', 'tan(', 'ln(', 'log(', 'sqrt(', 'pi', 'e'
        ];
        for (const fn of functionsToMatch) {
          if (prev.endsWith(fn)) {
            return prev.slice(0, -fn.length);
          }
        }
        return prev.slice(0, -1);
      });
      return;
    }

    if (value === '=') {
      handleEvaluate(expression);
      return;
    }

    // Standard variable/number/operator insertions
    setExpression((prev) => {
      // Sane multiply layout insertions
      if (value === 'pow') {
        return prev + '^';
      }
      return prev + value;
    });
  };

  // Keyboard integration: listen to document inputs
  useEffect(() => {
    if (mode !== 'scientific') return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // Ensure we don't intercept inputs inside other input boxes (e.g., graphing or units panels)
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'SELECT'
      ) {
        return;
      }

      const key = e.key;

      if (/[0-9]/.test(key)) {
        handleKeyPress(key, 'number');
      } else if (['+', '-', '*', '/', '%', '^', '(', ')', '.'].includes(key)) {
        handleKeyPress(key, 'operator');
      } else if (key === 'Enter' || key === '=') {
        e.preventDefault();
        handleKeyPress('=', 'action');
      } else if (key === 'Backspace') {
        handleKeyPress('BACKSPACE', 'action');
      } else if (key === 'Escape' || key.toLowerCase() === 'c') {
        handleKeyPress('AC', 'action');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [expression, mode, isDegrees]);

  // Memory keys handlers
  const handleMemoryAction = (action: string) => {
    try {
      const currentVal = result ? parseFloat(result) : parseFloat(expression);
      const parser = new MathParser({ isDegrees });

      switch (action) {
        case 'MC':
          setMemory(null);
          break;
        case 'MR':
          if (memory !== null) {
            setExpression((prev) => prev + memory.toString());
          }
          break;
        case 'M+': {
          const evalVal = parser.evaluate(expression || '0');
          setMemory((prev) => (prev ?? 0) + evalVal);
          break;
        }
        case 'M-': {
          const evalVal = parser.evaluate(expression || '0');
          setMemory((prev) => (prev ?? 0) - evalVal);
          break;
        }
        case 'MS': {
          const evalVal = parser.evaluate(expression || '0');
          setMemory(evalVal);
          break;
        }
      }
    } catch (err: any) {
      setErrorState('Memory Action Error: ' + err.message);
    }
  };

  // Format expression for visualization on the slate screen
  const formatDisplayExpression = (expr: string) => {
    if (!expr) return '0';
    return expr
      .replace(/\*/g, ' × ')
      .replace(/\//g, ' ÷ ')
      .replace(/\-/g, ' − ')
      .replace(/\+/g, ' + ')
      .replace(/\^/g, ' ^ ')
      .replace(/pi/g, 'π')
      .replace(/sqrt/g, '√')
      .replace(/asin/g, 'sin⁻¹')
      .replace(/acos/g, 'cos⁻¹')
      .replace(/atan/g, 'tan⁻¹');
  };

  // Recall selected item from history sidebar back into slate expression
  const handleSelectHistory = (item: HistoryItem) => {
    setExpression(item.expression);
    setResult(item.result);
    setErrorState(null);
  };

  return (
    <div className="min-h-screen bg-[#020617] text-slate-100 font-sans selection:bg-[#6366F1]/30">
      {/* Decorative top grid accent */}
      <div className="absolute top-0 left-0 right-0 h-48 bg-gradient-to-b from-[#0F172A]/40 to-transparent pointer-events-none border-b border-slate-800/10" />

      {/* Primary Container */}
      <div className="max-w-7xl mx-auto px-4 py-6 md:py-10 relative z-10">
        {/* App Title Header Bar */}
        <header className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 mb-8 border-b border-slate-800">
          <div className="flex items-center justify-between gap-4 w-full lg:w-auto">
            <div>
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#6366F1] to-indigo-400 flex items-center justify-center shadow-lg">
                  <Calculator className="w-4 h-4 text-white" />
                </div>
                <h1 className="text-xl font-bold font-sans tracking-tight text-slate-100 flex items-center gap-2">
                  <span>Quantum Scientific</span>
                  <span className="text-[10px] font-mono tracking-wider text-indigo-400 font-bold bg-[#0F172A] border border-slate-800 px-2 py-0.5 rounded-md">
                    V2.0
                  </span>
                </h1>
              </div>
              <p className="text-xs text-slate-400 mt-1 max-w-sm">
                Highly professional computer algebra engine & interactive Cartesian plotter.
              </p>
            </div>

            <div className="lg:hidden">
              <PWAInstallButton />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Core Workspace Mode Navigation */}
            <nav className="flex items-center gap-1.5 bg-[#0F172A] p-1.5 rounded-xl border border-slate-800 overflow-x-auto max-w-full">
              <button
                onClick={() => setMode('scientific')}
                className={`flex items-center gap-1.5 text-xs font-semibold px-4 py-2 rounded-lg transition-all ${
                  mode === 'scientific'
                    ? 'bg-[#1E293B] text-slate-100 shadow-md border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                id="mode_nav_scientific"
              >
                <Calculator className="w-3.5 h-3.5 text-[#6366F1]" />
                <span>Scientific Algebra</span>
              </button>
              <button
                onClick={() => setMode('graphing')}
                className={`flex items-center gap-1.5 text-xs font-semibold px-4 py-2 rounded-lg transition-all ${
                  mode === 'graphing'
                    ? 'bg-[#1E293B] text-slate-100 shadow-md border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                id="mode_nav_graphing"
              >
                <LineChart className="w-3.5 h-3.5 text-indigo-400" />
                <span>Cartesian Graph</span>
              </button>
              <button
                onClick={() => setMode('converter')}
                className={`flex items-center gap-1.5 text-xs font-semibold px-4 py-2 rounded-lg transition-all ${
                  mode === 'converter'
                    ? 'bg-[#1E293B] text-slate-100 shadow-md border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                id="mode_nav_converter"
              >
                <FolderSync className="w-3.5 h-3.5 text-indigo-400" />
                <span>Converter Section</span>
              </button>
              <button
                onClick={() => {
                  setMode('special');
                  setSpecialOption('derivation_integration');
                  setSpecialSubOption(undefined);
                }}
                className={`flex items-center gap-1.5 text-xs font-semibold px-4 py-2 rounded-lg transition-all ${
                  mode === 'special'
                    ? 'bg-[#1E293B] text-slate-100 shadow-md border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                id="mode_nav_special"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
                <span>Special Calculation</span>
              </button>
              <button
                onClick={() => setMode('formulas')}
                className={`flex items-center gap-1.5 text-xs font-semibold px-4 py-2 rounded-lg transition-all ${
                  mode === 'formulas'
                    ? 'bg-[#1E293B] text-slate-100 shadow-md border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                id="mode_nav_formulas"
              >
                <Compass className="w-3.5 h-3.5 text-indigo-400" />
                <span>Formulas Geometry</span>
              </button>
              <button
                onClick={() => setMode('money')}
                className={`flex items-center gap-1.5 text-xs font-semibold px-4 py-2 rounded-lg transition-all ${
                  mode === 'money'
                    ? 'bg-[#1E293B] text-slate-100 shadow-md border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                id="mode_nav_money"
              >
                <Coins className="w-3.5 h-3.5 text-indigo-400" />
                <span>Money Section</span>
              </button>
            </nav>

            <div className="hidden lg:block">
              <PWAInstallButton />
            </div>
          </div>
        </header>

        {/* Live workspace layout switchers */}
        <main className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {mode === 'scientific' && (
            <>
              {/* Left Column: Calculator Board & Display Screen */}
              <div className="lg:col-span-8 flex flex-col gap-5">
                {/* Modern Dual-line LED Slate Display board */}
                <div className="bg-[#020617] border border-slate-800 rounded-2xl p-6 flex flex-col justify-between min-h-[160px] shadow-inner shadow-2xl relative overflow-hidden group">
                  {/* Background display glow decoration */}
                  <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-3xl group-hover:bg-indigo-500/10 transition-all pointer-events-none" />

                  {/* Top-row mathematical formula input */}
                  <div className="text-right text-xs font-mono text-slate-400/95 tracking-wide overflow-x-auto whitespace-nowrap scrollbar-none pb-2 select-text" title="Active algebra formula formulation">
                    {formatDisplayExpression(expression)}
                  </div>

                  {/* Bottom-row output projection with blinking cursor */}
                  <div className="flex items-end justify-between mt-4">
                    <span className="text-slate-500 font-mono text-xs select-none">
                      {isDegrees ? 'DEG' : 'RAD'}
                    </span>
                    <div className="text-right flex items-center justify-end font-mono select-text truncate max-w-full">
                      <span className="text-2xl md:text-3.5xl font-semibold tracking-tight text-slate-100">
                        {result || '0'}
                      </span>
                      {expression && !result && (
                        <span className="w-1.5 h-6 bg-[#6366F1] ml-1.5 animate-pulse rounded-full" />
                      )}
                    </div>
                  </div>

                  {/* Live real-time preview evaluation if parsing compiles seamlessly */}
                  {expression && !result && !errorState && (
                    <div className="text-right text-[10px] font-mono text-slate-500 mt-1 pointer-events-none select-none">
                      Press Enter or = to evaluate
                    </div>
                  )}

                  {/* Red display validation banner */}
                  {errorState && (
                    <div className="absolute left-6 top-3 text-[10px] font-mono text-rose-400 bg-rose-500/10 px-2.5 py-1 rounded-md border border-rose-500/10">
                      {errorState}
                    </div>
                  )}
                </div>

                {/* Main Scientific Keyboard Box */}
                <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-2.5xl">
                  <Keypad
                    onKeyPress={handleKeyPress}
                    isDegrees={isDegrees}
                    onToggleDegRad={() => setIsDegrees(!isDegrees)}
                    memory={memory}
                    onMemoryAction={handleMemoryAction}
                  />
                </div>
              </div>

              {/* Right Column: Calculations History sidebar */}
              <div className="lg:col-span-4 h-full">
                <HistorySidebar
                  history={history}
                  onSelect={handleSelectHistory}
                  onClear={() => setHistory([])}
                />
              </div>
            </>
          )}

          {mode === 'graphing' && (
            <div className="lg:col-span-12">
              <GraphingView initialFormula={expression || 'x^2'} />
            </div>
          )}

          {mode === 'converter' && (
            <div className="lg:col-span-12">
              <ConverterView />
            </div>
          )}

          {mode === 'special' && (
            <div className="lg:col-span-12">
              <SpecialCalculationView
                initialFormula={calculusFormula}
                initialOption={specialOption}
                initialSubOption={specialSubOption}
              />
            </div>
          )}

          {mode === 'formulas' && (
            <div className="lg:col-span-12">
              <FormulasView />
            </div>
          )}

          {mode === 'money' && (
            <div className="lg:col-span-12">
              <MoneyView />
            </div>
          )}
        </main>

        {/* Footer Technical Metadata bar */}
        <footer className="mt-16 pt-6 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 text-xs font-mono text-slate-500">
          <div className="flex items-center gap-1">
            <span>Precision Computer Algebra Standard</span>
            <span className="text-[#6366F1]">●</span>
            <span>IEEE 754 Float Math</span>
          </div>
          <div className="flex items-center gap-1 text-slate-450">
            <span>Built with industrial-grade UI & canvas-based vector curves</span>
          </div>
        </footer>
      </div>

      {/* Offline Connectivity Notification */}
      <OfflineIndicator />
    </div>
  );
}
