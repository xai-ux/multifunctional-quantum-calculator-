export type CalcMode = 'scientific' | 'graphing' | 'converter' | 'special' | 'formulas' | 'money';

export interface HistoryItem {
  id: string;
  expression: string;
  result: string;
  timestamp: string;
}

export type CalcKeyType =
  | 'number'
  | 'operator'
  | 'function'
  | 'constant'
  | 'action'
  | 'memory';

export interface CalcKeyConfig {
  value: string;         // Internal expression representation (e.g. 'sin(')
  display: string;       // Button text / label
  type: CalcKeyType;
  span?: number;         // grid-cols span size (e.g. 2)
  tooltip?: string;      // description of operation
  isSubscript?: boolean; // toggle style for superscript or specialized labeling
}
