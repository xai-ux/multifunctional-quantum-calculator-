// Mathematical expression tokenizer and parser for the Scientific Calculator.
// Supports: +, -, *, /, ^ (power), %, ! (factorial), standard functions, constants (pi, e), and variable 'x' (for graphing).

export interface ParserOptions {
  isDegrees?: boolean; // Default to Radians if false
  xValue?: number;     // Value of variable 'x' for graphing evaluation
}

export class MathParser {
  private input: string = "";
  private pos: number = 0;
  private currentRawToken: string = "";
  private isDegrees: boolean = false;
  private xValue: number = 0;

  constructor(options?: ParserOptions) {
    this.isDegrees = !!options?.isDegrees;
    this.xValue = options?.xValue ?? 0;
  }

  // Factorial utility
  private static factorial(n: number): number {
    if (n < 0) throw new Error("Domain Error (Factorial of negative)");
    if (!Number.isInteger(n)) {
      // Gamma approximation for non-integers, or simplified fallback
      // Since it's a calculator, we can do standard lanczos or simple sound gamma approximation,
      // but standard factorial for integers is expected. Let's implement standard integer factorial,
      // and for small decimals we can do a simplified Stirling/Gamma or throw a domain error.
      // Let's support float factorial using a reputable gamma approximation:
      return MathParser.gammaGamma(n + 1);
    }
    if (n > 170) return Infinity; // Limit to prevent JS overflow
    let result = 1;
    for (let i = 2; i <= n; i++) result *= i;
    return result;
  }

  // Iterative combinations nCr to prevent overflow
  private static nCr(n: number, r: number): number {
    if (n < 0 || r < 0 || r > n) return 0;
    if (!Number.isInteger(n) || !Number.isInteger(r)) {
      throw new Error("nCr expects positive integers as arguments");
    }
    if (r === 0 || r === n) return 1;
    if (r > n / 2) r = n - r; // Symmetry
    let res = 1;
    for (let i = 1; i <= r; i++) {
      res = (res * (n - r + i)) / i;
    }
    return Math.round(res);
  }

  // Permutations nPr implementation
  private static nPr(n: number, r: number): number {
    if (n < 0 || r < 0 || r > n) return 0;
    if (!Number.isInteger(n) || !Number.isInteger(r)) {
      throw new Error("nPr expects positive integers as arguments");
    }
    let res = 1;
    for (let i = n - r + 1; i <= n; i++) {
      res *= i;
    }
    return Math.round(res);
  }

  // Lanczos approximation to compute Gamma(z)
  private static gammaGamma(z: number): number {
    if (z < 0.5) {
      return Math.PI / (Math.sin(Math.PI * z) * MathParser.gammaGamma(1 - z));
    }
    z -= 1;
    const p = [
      0.99999999999980993, 676.5203681218851, -1259.1392167224028,
      771.32342877765313, -176.61502916214059, 12.507343278686905,
      -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7,
    ];
    let x = p[0];
    for (let i = 1; i < p.length; i++) {
      x += p[i] / (z + i);
    }
    const t = z + p.length - 1.5;
    return Math.sqrt(2 * Math.PI) * Math.pow(t, z + 0.5) * Math.exp(-t) * x;
  }

  /**
   * Main evaluate function.
   * Cleans input (e.g. expands implicit multiplication, corrects symbols) and runs parser.
   */
  public evaluate(expression: string): number {
    if (!expression || expression.trim() === "") {
      throw new Error("Empty Expression");
    }

    // Standardize unicode characters and clean input
    let clean = expression
      .replace(/×/g, "*")
      .replace(/÷/g, "/")
      .replace(/−/g, "-")
      .replace(/π/g, "pi")
      .replace(/√/g, "sqrt")
      .trim();

    // Setup state
    this.input = clean;
    this.pos = 0;

    // Run the parser structure: Expression -> Term -> Power -> Factorial -> Unary -> Primary
    const result = this.parseExpression();

    // Ensure entire input was consumed
    this.skipWhitespace();
    if (this.pos < this.input.length) {
      throw new Error(`Unexpected character '${this.input[this.pos]}'`);
    }

    if (isNaN(result)) {
      throw new Error("Not a Number");
    }

    return result;
  }

  private skipWhitespace() {
    while (this.pos < this.input.length && /\s/.test(this.input[this.pos])) {
      this.pos++;
    }
  }

  // Peek the character at relative offset
  private peek(offset: number = 0): string {
    const p = this.pos + offset;
    if (p >= this.input.length) return "";
    return this.input[p];
  }

  private parseExpression(): number {
    let result = this.parseTerm();
    this.skipWhitespace();

    while (this.pos < this.input.length) {
      const char = this.peek();
      if (char === "+") {
        this.pos++;
        result += this.parseTerm();
      } else if (char === "-") {
        this.pos++;
        result -= this.parseTerm();
      } else {
        break;
      }
    }
    return result;
  }

  private parseTerm(): number {
    let result = this.parsePower();
    this.skipWhitespace();

    while (this.pos < this.input.length) {
      const char = this.peek();
      if (char === "*") {
        this.pos++;
        result *= this.parsePower();
      } else if (char === "/") {
        this.pos++;
        const denominator = this.parsePower();
        if (denominator === 0) {
          throw new Error("Division by Zero");
        }
        result /= denominator;
      } else if (char === "%") {
        this.pos++;
        const denominator = this.parsePower();
        result = result % denominator;
      } else {
        // Support implicit multiplication, e.g., 2(x+3) or 3pi or 2x
        // Trigger implicit multiplication if current char signals the start of a primary:
        // - digits, decimal dot
        // - letters: x, pi, sin, cos
        // - open parentheses '('
        const nextChar = this.peek();
        if (
          /[0-9.a-zA-Z(]/.test(nextChar) &&
          !/^[+\-*/^%]/.test(nextChar)
        ) {
          result *= this.parsePower();
        } else {
          break;
        }
      }
      this.skipWhitespace();
    }
    return result;
  }

  private parsePower(): number {
    let result = this.parseFactorial();
    this.skipWhitespace();

    if (this.peek() === "^") {
      this.pos++;
      // Exponentiation is right-associative (e.g. 2^3^2 = 2^(3^2))
      const exponent = this.parsePower();
      result = Math.pow(result, exponent);
    }
    return result;
  }

  private parseFactorial(): number {
    let result = this.parseUnary();
    this.skipWhitespace();

    // Factorial can be chained or repeated postfix, e.g. 3!!
    while (this.peek() === "!") {
      this.pos++;
      result = MathParser.factorial(result);
    }
    return result;
  }

  private parseUnary(): number {
    this.skipWhitespace();
    const char = this.peek();

    if (char === "-") {
      this.pos++;
      return -this.parseUnary();
    }
    if (char === "+") {
      this.pos++;
      return this.parseUnary();
    }

    return this.parsePrimary();
  }

  private parsePrimary(): number {
    this.skipWhitespace();
    const char = this.peek();

    if (char === "") {
      throw new Error("Unexpected end of expression");
    }

    // 1. Parentheses: (expression)
    if (char === "(") {
      this.pos++;
      const val = this.parseExpression();
      this.skipWhitespace();
      if (this.peek() !== ")") {
        throw new Error("Mismatched Parentheses");
      }
      this.pos++; // consume ')'
      return val;
    }

    // 2. Numeric Constant
    if (/[0-9.]/.test(char)) {
      let numStr = "";
      let hasDot = false;
      while (this.pos < this.input.length) {
        const c = this.peek();
        if (c === ".") {
          if (hasDot) throw new Error("Malformed Number");
          hasDot = true;
          numStr += c;
          this.pos++;
        } else if (/[0-9]/.test(c)) {
          numStr += c;
          this.pos++;
        } else {
          break;
        }
      }

      // Handle scientific notation exponent e.g. 1e+5, 3e-4, 5e6
      if (this.peek().toLowerCase() === "e" && /[0-9+-]/.test(this.peek(1))) {
        numStr += this.peek(); // 'e'
        this.pos++;
        const sign = this.peek();
        if (sign === "+" || sign === "-") {
          numStr += sign;
          this.pos++;
        }
        while (this.pos < this.input.length && /[0-9]/.test(this.peek())) {
          numStr += this.peek();
          this.pos++;
        }
      }

      const val = parseFloat(numStr);
      if (isNaN(val)) throw new Error("Invalid Number");
      return val;
    }

    // 3. Named constants & functions
    if (/[a-zA-Z]/.test(char)) {
      let ident = "";
      while (this.pos < this.input.length && /[a-zA-Z0-9]/.test(this.peek())) {
        ident += this.peek();
        this.pos++;
      }

      const lowerIdent = ident.toLowerCase();

      // Standard Constants
      if (lowerIdent === "pi") {
        return Math.PI;
      }
      if (lowerIdent === "e") {
        return Math.E;
      }
      if (lowerIdent === "x") {
        return this.xValue;
      }

      // Functions: ident(expression, ...)
      // Check if open parenthesis succeeds function name
      this.skipWhitespace();
      if (this.peek() !== "(") {
        // If it's a constant without parens, throw syntax error otherwise it might be implicit multiplication of custom variable, but we only have pi, e, and x
        throw new Error(`Unknown identifier '${ident}'`);
      }

      this.pos++; // consume '('
      const args: number[] = [];
      args.push(this.parseExpression());
      this.skipWhitespace();
      while (this.peek() === ",") {
        this.pos++; // consume ','
        args.push(this.parseExpression());
        this.skipWhitespace();
      }
      if (this.peek() !== ")") {
        throw new Error(`Expected matching ')' for function '${ident}'`);
      }
      this.pos++; // consume ')'

      const arg = args[0];

      // Evaluate functions
      switch (lowerIdent) {
        case "ncr": {
          if (args.length !== 2) throw new Error("nCr expects exactly 2 arguments: ncr(n, r)");
          return MathParser.nCr(args[0], args[1]);
        }
        case "npr": {
          if (args.length !== 2) throw new Error("nPr expects exactly 2 arguments: npr(n, r)");
          return MathParser.nPr(args[0], args[1]);
        }
        case "sin":
          return Math.sin(this.angleToRad(arg));
        case "cos":
          return Math.cos(this.angleToRad(arg));
        case "tan": {
          const rad = this.angleToRad(arg);
          // Handle tan(pi/2) domain error / large values gracefully
          if (Math.abs(Math.cos(rad)) < 1e-15) {
            throw new Error("Domain Error (Tan value undefined)");
          }
          return Math.tan(rad);
        }
        case "asin": {
          if (arg < -1 || arg > 1) throw new Error("Domain Error (asin)");
          return this.radToAngle(Math.asin(arg));
        }
        case "acos": {
          if (arg < -1 || arg > 1) throw new Error("Domain Error (acos)");
          return this.radToAngle(Math.acos(arg));
        }
        case "atan":
          return this.radToAngle(Math.atan(arg));
        case "sinh":
          return Math.sinh(arg);
        case "cosh":
          return Math.cosh(arg);
        case "tanh":
          return Math.tanh(arg);
        case "ln": {
          if (arg <= 0) throw new Error("Domain Error (ln of non-positive)");
          return Math.log(arg);
        }
        case "log":
        case "log10": {
          if (arg <= 0) throw new Error("Domain Error (log of non-positive)");
          return Math.log10(arg);
        }
        case "log2": {
          if (arg <= 0) throw new Error("Domain Error (log of non-positive)");
          return Math.log2(arg);
        }
        case "sqrt": {
          if (arg < 0) throw new Error("Domain Error (sqrt of negative)");
          return Math.sqrt(arg);
        }
        case "cbrt":
          return Math.cbrt(arg);
        case "abs":
          return Math.abs(arg);
        case "exp":
          return Math.exp(arg);
        default:
          throw new Error(`Unsupported function '${ident}'`);
      }
    }

    throw new Error(`Unexpected character '${char}'`);
  }

  // Convert given angle to radians
  private angleToRad(val: number): number {
    if (this.isDegrees) {
      return (val * Math.PI) / 180;
    }
    return val;
  }

  // Convert radian value to angle (either radian or degree mode)
  private radToAngle(val: number): number {
    if (this.isDegrees) {
      return (val * 180) / Math.PI;
    }
    return val;
  }
}
