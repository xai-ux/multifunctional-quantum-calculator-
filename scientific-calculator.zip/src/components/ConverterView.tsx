import { useState, useEffect, useMemo } from 'react';
import {
  ArrowLeftRight,
  Scale,
  Thermometer,
  Box,
  Zap,
  Compass,
  Ruler,
  TrendingUp,
  RefreshCw,
  DollarSign,
  Globe,
  Coins,
  ArrowUpRight,
  ArrowDownRight,
  Calculator,
  Search,
  CheckCircle2
} from 'lucide-react';
import { motion } from 'motion/react';

// ============================================================================
// UNIT CONVERTER CONFIG & DATA
// ============================================================================
interface UnitPreset {
  name: string;
  symbol: string;
  factor: number;
}

interface CategoryConfig {
  icon: any;
  baseUnit: string;
  units: UnitPreset[];
}

const UNIT_CATEGORIES: Record<string, CategoryConfig> = {
  Length: {
    icon: Ruler,
    baseUnit: 'm',
    units: [
      { name: 'Meters', symbol: 'm', factor: 1 },
      { name: 'Kilometers', symbol: 'km', factor: 1000 },
      { name: 'Centimeters', symbol: 'cm', factor: 0.01 },
      { name: 'Millimeters', symbol: 'mm', factor: 0.001 },
      { name: 'Inches', symbol: 'in', factor: 0.0254 },
      { name: 'Feet', symbol: 'ft', factor: 0.3048 },
      { name: 'Yards', symbol: 'yd', factor: 0.9144 },
      { name: 'Miles', symbol: 'mi', factor: 1609.344 },
    ],
  },
  Mass: {
    icon: Scale,
    baseUnit: 'g',
    units: [
      { name: 'Grams', symbol: 'g', factor: 1 },
      { name: 'Kilograms', symbol: 'kg', factor: 1000 },
      { name: 'Milligrams', symbol: 'mg', factor: 0.001 },
      { name: 'Pounds', symbol: 'lb', factor: 453.59237 },
      { name: 'Ounces', symbol: 'oz', factor: 28.34952 },
    ],
  },
  Temperature: {
    icon: Thermometer,
    baseUnit: 'C',
    units: [
      { name: 'Celsius', symbol: '°C', factor: 1 },
      { name: 'Fahrenheit', symbol: '°F', factor: 1 },
      { name: 'Kelvin', symbol: 'K', factor: 1 },
    ],
  },
  Volume: {
    icon: Box,
    baseUnit: 'L',
    units: [
      { name: 'Liters', symbol: 'L', factor: 1 },
      { name: 'Milliliters', symbol: 'mL', factor: 0.001 },
      { name: 'Gallons (US)', symbol: 'gal', factor: 3.78541 },
      { name: 'Quarts (US)', symbol: 'qt', factor: 0.946353 },
      { name: 'Cups (US)', symbol: 'cup', factor: 0.236588 },
      { name: 'Cubic Meters', symbol: 'm³', factor: 1000 },
    ],
  },
  Angle: {
    icon: Compass,
    baseUnit: 'rad',
    units: [
      { name: 'Radians', symbol: 'rad', factor: 1 },
      { name: 'Degrees', symbol: 'deg', factor: Math.PI / 180 },
      { name: 'Gradians', symbol: 'grad', factor: Math.PI / 200 },
    ],
  },
  Energy: {
    icon: Zap,
    baseUnit: 'J',
    units: [
      { name: 'Joules', symbol: 'J', factor: 1 },
      { name: 'Kilojoules', symbol: 'kJ', factor: 1000 },
      { name: 'Calories', symbol: 'cal', factor: 4.184 },
      { name: 'Kilocalories', symbol: 'kcal', factor: 4184 },
      { name: 'Watt-hours', symbol: 'Wh', factor: 3600 },
      { name: 'Kilowatt-hours', symbol: 'kWh', factor: 3600000 },
    ],
  },
};

// ============================================================================
// CURRENCY CONVERTER CONFIG & DATA
// ============================================================================
interface Currency {
  code: string;
  name: string;
  symbol: string;
  flag: string;
  rateVsUSD: number; // Factor relative to 1 USD (Standard base rate)
  trend24h: number;  // 24 hour trend percentage
}

const DEFAULT_CURRENCIES: Currency[] = [
  { code: 'USD', name: 'US Dollar', symbol: '$', flag: '🇺🇸', rateVsUSD: 1.0, trend24h: 0 },
  { code: 'EUR', name: 'Euro', symbol: '€', flag: '🇪🇺', rateVsUSD: 0.92, trend24h: -0.15 },
  { code: 'GBP', name: 'British Pound', symbol: '£', flag: '🇬🇧', rateVsUSD: 0.79, trend24h: 0.22 },
  { code: 'JPY', name: 'Japanese Yen', symbol: '¥', flag: '🇯🇵', rateVsUSD: 156.45, trend24h: -0.68 },
  { code: 'INR', name: 'Indian Rupee', symbol: '₹', flag: '🇮🇳', rateVsUSD: 83.30, trend24h: 0.05 },
  { code: 'AUD', name: 'Australian Dollar', symbol: 'A$', flag: '🇦🇺', rateVsUSD: 1.50, trend24h: 0.12 },
  { code: 'CAD', name: 'Canadian Dollar', symbol: 'C$', flag: '🇨🇦', rateVsUSD: 1.36, trend24h: -0.04 },
  { code: 'CHF', name: 'Swiss Franc', symbol: 'CHF', flag: '🇨🇭', rateVsUSD: 0.91, trend24h: 0.18 },
  { code: 'CNY', name: 'Chinese Yuan', symbol: '¥', flag: '🇨🇳', rateVsUSD: 7.24, trend24h: -0.10 },
  { code: 'SGD', name: 'Singapore Dollar', symbol: 'S$', flag: '🇸🇬', rateVsUSD: 1.35, trend24h: 0.08 },
  { code: 'AED', name: 'UAE Dirham', symbol: 'د.إ', flag: '🇦🇪', rateVsUSD: 3.67, trend24h: 0.00 },
  { code: 'BTC', name: 'Bitcoin', symbol: '₿', flag: '🪙', rateVsUSD: 0.000015, trend24h: 3.42 },
];

export default function ConverterView() {
  // Option selection state: 'units' | 'currencies'
  const [activeSegment, setActiveSegment] = useState<'units' | 'currencies'>('units');

  // ----------------------------------------------------
  // SUB-SECTION 1: UNIT CONVERTER STATES & LOGIC
  // ----------------------------------------------------
  const [activeUnitCategory, setActiveUnitCategory] = useState<string>('Length');
  const [unitInputValue, setUnitInputValue] = useState<string>('1');
  const [fromUnit, setFromUnit] = useState<string>('km');
  const [toUnit, setToUnit] = useState<string>('m');

  const unitCategory = UNIT_CATEGORIES[activeUnitCategory];

  // Pick sane defaults when unit category changes
  useEffect(() => {
    const list = UNIT_CATEGORIES[activeUnitCategory].units;
    if (list.length >= 2) {
      setFromUnit(list[0].symbol);
      setToUnit(list[1].symbol);
    }
  }, [activeUnitCategory]);

  const unitOutputValue = useMemo(() => {
    const num = parseFloat(unitInputValue);
    if (isNaN(num)) return '';

    const list = unitCategory.units;
    const fromObj = list.find((u) => u.symbol === fromUnit);
    const toObj = list.find((u) => u.symbol === toUnit);

    if (!fromObj || !toObj) return '';

    // Specialized conversion formulas for Temperature
    if (activeUnitCategory === 'Temperature') {
      let tempInC = num;
      if (fromUnit === '°F') {
        tempInC = ((num - 32) * 5) / 9;
      } else if (fromUnit === 'K') {
        tempInC = num - 273.15;
      }

      if (toUnit === '°C') {
        return Number(tempInC.toFixed(6));
      } else if (toUnit === '°F') {
        return Number(((tempInC * 9) / 5 + 32).toFixed(6));
      } else if (toUnit === 'K') {
        return Number((tempInC + 273.15).toFixed(6));
      }
    }

    // Generic factor-based conversions
    const valueInBase = num * fromObj.factor;
    const valueInTarget = valueInBase / toObj.factor;

    // Dynamic scientific formatting for high precision or micro decimals
    if (Math.abs(valueInTarget) < 1e-5 && valueInTarget !== 0) {
      return valueInTarget.toExponential(6);
    }
    return Number(valueInTarget.toFixed(7));
  }, [unitInputValue, fromUnit, toUnit, activeUnitCategory, unitCategory]);

  const swapUnits = () => {
    const tmp = fromUnit;
    setFromUnit(toUnit);
    setToUnit(tmp);
  };

  const UnitIcon = unitCategory.icon;

  // ----------------------------------------------------
  // SUB-SECTION 2: CURRENCY CONVERTER STATES & LOGIC
  // ----------------------------------------------------
  const [currencyValues, setCurrencyValues] = useState<Currency[]>(DEFAULT_CURRENCIES);
  const [currencyAmount, setCurrencyAmount] = useState<string>('100');
  const [fromCurrencyCode, setFromCurrencyCode] = useState<string>('USD');
  const [toCurrencyCode, setToCurrencyCode] = useState<string>('EUR');
  
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<string>('Just loaded (Internal Cache)');
  const [syncMessage, setSyncMessage] = useState<string>('Exchange rates calibrated with IMF benchmarks.');

  // Simulated rate sync action
  const handleRatesSync = () => {
    setIsSyncing(true);
    setSyncMessage('Connecting to sandbox financial node...');
    
    setTimeout(() => {
      // Intentionally fluctuate baseline rates slightly (+/- 0.5%) to simulate real action
      const randomizedRates = currencyValues.map((curr) => {
        if (curr.code === 'USD') return curr;
        
        const changeFactor = 1 + (Math.random() * 0.01 - 0.005);
        const nextTrend = parseFloat((Math.random() * 2 - 1).toFixed(2));
        
        return {
          ...curr,
          rateVsUSD: parseFloat((curr.rateVsUSD * changeFactor).toFixed(4)),
          trend24h: nextTrend
        };
      });

      setCurrencyValues(randomizedRates);
      setIsSyncing(false);
      
      const now = new Date();
      const formatTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastSyncTime(`Updated today at ${formatTime}`);
      setSyncMessage('Live rates calculated smoothly based on market simulation.');
    }, 1500);
  };

  const currencyOutputValue = useMemo(() => {
    const num = parseFloat(currencyAmount);
    if (isNaN(num) || num < 0) return '0.00';

    const fromCurr = currencyValues.find((c) => c.code === fromCurrencyCode);
    const toCurr = currencyValues.find((c) => c.code === toCurrencyCode);

    if (!fromCurr || !toCurr) return '0.00';

    // 1. Convert amount in FromCurrency to base unit USD
    const amountInUSD = num / fromCurr.rateVsUSD;
    // 2. Convert USD amount to TargetCurrency
    const convertedAmount = amountInUSD * toCurr.rateVsUSD;

    // Beautiful scaling logic for BTC, keep decimals higher
    if (toCurrencyCode === 'BTC') {
      return convertedAmount.toFixed(6);
    }
    return convertedAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 });
  }, [currencyAmount, fromCurrencyCode, toCurrencyCode, currencyValues]);

  const swapCurrencies = () => {
    const tmp = fromCurrencyCode;
    setFromCurrencyCode(toCurrencyCode);
    setToCurrencyCode(tmp);
  };

  const currentFromSymbol = currencyValues.find(c => c.code === fromCurrencyCode)?.symbol || '$';
  const currentToSymbol = currencyValues.find(c => c.code === toCurrencyCode)?.symbol || '$';

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden group">
      {/* Dynamic decoration canvas layout */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/5 rounded-full blur-[90px] pointer-events-none" />
      <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-pink-500/5 rounded-full blur-[90px] pointer-events-none" />

      <div className="flex flex-col gap-6 relative z-10">
        
        {/* Dynamic Section Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center">
              <Coins className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-100 tracking-tight flex items-center gap-2">
                <span>Integrated Conversion Suite</span>
                <span className="text-[9px] font-mono font-bold tracking-wider text-indigo-400 bg-indigo-500/10 px-2.5 py-0.5 rounded border border-indigo-500/10 uppercase">
                  Multipurpose Converter
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                A single environment featuring comprehensive unit engineering dimensions and active live exchange rate computations.
              </p>
            </div>
          </div>
        </div>

        {/* Dual Tab Segmented Buttons */}
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none border-b border-slate-800/60 pb-3">
          <button
            onClick={() => setActiveSegment('units')}
            className={`flex items-center gap-2 text-xs font-bold px-4 py-2.5 rounded-xl border transition-all whitespace-nowrap ${
              activeSegment === 'units'
                ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-300'
                : 'bg-slate-900/40 border-slate-850 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Ruler className="w-3.5 h-3.5 text-indigo-400" />
            <span>Unit Dimensional Converter</span>
          </button>
          <button
            onClick={() => setActiveSegment('currencies')}
            className={`flex items-center gap-2 text-xs font-bold px-4 py-2.5 rounded-xl border transition-all whitespace-nowrap ${
              activeSegment === 'currencies'
                ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-300'
                : 'bg-slate-900/40 border-slate-850 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-pink-400" />
            <span>Global Currency Exchange</span>
          </button>
        </div>

        {/* ----------------------------------------------------
            TAB 1: UNIT CONVERTER
            ---------------------------------------------------- */}
        {activeSegment === 'units' && (
          <div className="space-y-5">
            {/* Category selection grid */}
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {Object.entries(UNIT_CATEGORIES).map(([name, conf]) => {
                const CatIcon = conf.icon;
                const isActive = activeUnitCategory === name;
                return (
                  <button
                    key={name}
                    onClick={() => setActiveUnitCategory(name)}
                    className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all ${
                      isActive
                        ? 'bg-indigo-600/10 border-indigo-500/50 text-indigo-400 font-bold shadow-md'
                        : 'bg-slate-900/40 border-slate-800/80 hover:border-slate-700 text-slate-400 hover:text-slate-200'
                    }`}
                    id={`unit_cat_btn_${name}`}
                  >
                    <CatIcon className="w-4 h-4 mb-2 text-indigo-400/80" />
                    <span className="text-[10px] font-mono tracking-wider uppercase font-semibold">{name}</span>
                  </button>
                );
              })}
            </div>

            {/* Converter screen panel */}
            <div className="bg-[#020617] border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-11 items-center gap-4">
                
                {/* FROM Dimension input */}
                <div className="md:col-span-5 space-y-2">
                  <label className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold block">
                    Source Value & Unit
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={unitInputValue}
                      onChange={(e) => setUnitInputValue(e.target.value)}
                      className="w-full min-w-0 bg-slate-900/80 border border-slate-800 focus:border-indigo-500 rounded-xl px-3.5 py-2.5 text-sm font-mono text-slate-100 outline-none font-semibold focus:ring-1 focus:ring-indigo-500/30"
                      placeholder="e.g. 1"
                      id="unit_converter_from_input"
                    />
                    <select
                      value={fromUnit}
                      onChange={(e) => setFromUnit(e.target.value)}
                      className="bg-slate-900/80 border border-slate-805 rounded-xl px-3 py-2.5 text-xs font-mono text-slate-200 outline-none cursor-pointer hover:border-slate-700 font-semibold"
                      id="unit_converter_from_select"
                    >
                      {unitCategory.units.map((u) => (
                        <option key={u.symbol} value={u.symbol} className="bg-slate-950 text-slate-200">
                          {u.name} ({u.symbol})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* SWAP Arrow column */}
                <div className="md:col-span-1 flex justify-center mt-2 md:mt-0">
                  <button
                    onClick={swapUnits}
                    className="p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-indigo-500/40 text-slate-400 hover:text-indigo-300 transition-all active:scale-95 shadow-md flex items-center justify-center cursor-pointer"
                    title="Swap dimensions"
                  >
                    <ArrowLeftRight className="w-4 h-4" />
                  </button>
                </div>

                {/* TO Dimension input */}
                <div className="md:col-span-5 space-y-2">
                  <label className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold block">
                    Target Dimension Calculated
                  </label>
                  <div className="flex gap-2">
                    <div className="w-full bg-slate-900/40 border border-slate-850 rounded-xl px-3.5 py-2.5 text-sm font-mono text-indigo-300 flex items-center truncate font-bold shadow-inner overflow-hidden min-h-[44px]">
                      {unitOutputValue || '0'}
                    </div>
                    <select
                      value={toUnit}
                      onChange={(e) => setToUnit(e.target.value)}
                      className="bg-slate-900/80 border border-slate-805 rounded-xl px-3 py-2.5 text-xs font-mono text-slate-200 outline-none cursor-pointer hover:border-slate-700 font-semibold"
                      id="unit_converter_to_select"
                    >
                      {unitCategory.units.map((u) => (
                        <option key={u.symbol} value={u.symbol} className="bg-slate-950 text-slate-200">
                          {u.name} ({u.symbol})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

              </div>

              {/* Dynamic conversion formulation detail */}
              <div className="border-t border-slate-800/60 pt-3.5 flex items-center gap-2 text-[10px] font-mono text-slate-500 leading-relaxed">
                <UnitIcon className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                <span>
                  Scientific Formula Ratio:{' '}
                  <code className="text-slate-350 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-900 font-semibold">
                    {activeUnitCategory === 'Temperature'
                      ? `Complex scale formula mapped cleanly for thermal metrics (${fromUnit} ➜ ${toUnit})`
                      : `1.0 ${fromUnit} = ${(
                          (unitCategory.units.find((u) => u.symbol === fromUnit)?.factor ?? 1) /
                          (unitCategory.units.find((u) => u.symbol === toUnit)?.factor ?? 1)
                        ).toLocaleString(undefined, { maximumFractionDigits: 9 })} ${toUnit}`}
                  </code>
                </span>
              </div>

            </div>
          </div>
        )}

        {/* ----------------------------------------------------
            TAB 2: CURRENCY EXCHANGE CONVERTER
            ---------------------------------------------------- */}
        {activeSegment === 'currencies' && (
          <div className="space-y-5">
            
            {/* Sync control bar with Sandbox status alerts */}
            <div className="flex flex-col sm:flex-row justify-between sm:items-center p-3 rounded-xl bg-slate-950 border border-slate-900 shadow-inner gap-3">
              <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${isSyncing ? 'bg-amber-400 animate-ping' : 'bg-emerald-500'}`} />
                <div className="text-xs font-mono text-slate-400 font-medium">
                  Status: <span className="text-indigo-300 font-semibold">{syncMessage}</span>
                  <span className="opacity-60 block text-[10px] mt-0.5">Database reference point: {lastSyncTime}</span>
                </div>
              </div>
              <button
                onClick={handleRatesSync}
                disabled={isSyncing}
                className="flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 hover:bg-indigo-500/20 transition-all font-mono shrink-0 cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>{isSyncing ? 'Syncing Rates...' : 'Sync Live Rates'}</span>
              </button>
            </div>

            {/* Core Currency Panel */}
            <div className="bg-[#020617] border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-11 items-center gap-4">
                
                {/* FROM Currency input */}
                <div className="md:col-span-5 space-y-2">
                  <label className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold block">
                    Source Currency Portfolio Amount
                  </label>
                  <div className="flex gap-2">
                    <div className="relative w-full">
                      <span className="absolute left-3.5 top-2.5 font-mono text-sm text-slate-400 font-bold">
                        {currentFromSymbol}
                      </span>
                      <input
                        type="number"
                        min="0"
                        value={currencyAmount}
                        onChange={(e) => setCurrencyAmount(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-xl pl-9 pr-4 py-2.5 text-sm font-mono text-slate-100 outline-none font-semibold focus:ring-1 focus:ring-indigo-500/30 text-white"
                        placeholder="0.00"
                        id="currency_converter_from_input"
                      />
                    </div>
                    <select
                      value={fromCurrencyCode}
                      onChange={(e) => setFromCurrencyCode(e.target.value)}
                      className="bg-slate-900/80 border border-slate-805 rounded-xl px-3 py-2.5 text-xs font-mono text-slate-200 outline-none cursor-pointer hover:border-slate-700 font-semibold"
                      id="currency_converter_from_select"
                    >
                      {currencyValues.map((c) => (
                        <option key={c.code} value={c.code} className="bg-slate-950 text-slate-200">
                          {c.flag} {c.code} - {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* SWAP Arrow column */}
                <div className="md:col-span-1 flex justify-center mt-2 md:mt-0">
                  <button
                    onClick={swapCurrencies}
                    className="p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-indigo-500/40 text-slate-400 hover:text-indigo-300 transition-all active:scale-95 shadow-md flex items-center justify-center cursor-pointer"
                    title="Swap currencies"
                    id="currency_converter_swap_btn"
                  >
                    <ArrowLeftRight className="w-4 h-4" />
                  </button>
                </div>

                {/* TO Currency input */}
                <div className="md:col-span-5 space-y-2">
                  <label className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold block">
                    Exchanged Balance Equivalent
                  </label>
                  <div className="flex gap-2">
                    <div className="relative w-full">
                      <span className="absolute left-3.5 top-2.5 font-mono text-sm text-indigo-400 font-bold">
                        {currentToSymbol}
                      </span>
                      <div className="w-full bg-slate-900/40 border border-slate-850 rounded-xl pl-9 pr-4 py-2.5 text-sm font-mono text-indigo-300 flex items-center truncate font-bold font-mono shadow-inner min-h-[44px]">
                        {currencyOutputValue}
                      </div>
                    </div>
                    <select
                      value={toCurrencyCode}
                      onChange={(e) => setToCurrencyCode(e.target.value)}
                      className="bg-slate-900/80 border border-slate-805 rounded-xl px-3 py-2.5 text-xs font-mono text-slate-200 outline-none cursor-pointer hover:border-slate-700 font-semibold font-mono"
                      id="currency_converter_to_select"
                    >
                      {currencyValues.map((c) => (
                        <option key={c.code} value={c.code} className="bg-slate-950 text-slate-200 font-mono">
                          {c.flag} {c.code} - {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

              </div>

              {/* Dynamic FX formulation details */}
              <div className="border-t border-slate-800/60 pt-3.5 flex items-center gap-2 text-[10px] font-mono text-slate-500 justify-between flex-wrap">
                <div className="flex items-center gap-2">
                  <Globe className="w-3.5 h-3.5 text-pink-400 shrink-0" />
                  <span>
                    Mid-Market FX Rate:{' '}
                    <code className="text-slate-350 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-900 font-semibold">
                      1 {fromCurrencyCode} = {(
                        (currencyValues.find(c => c.code === toCurrencyCode)?.rateVsUSD ?? 1) /
                        (currencyValues.find(c => c.code === fromCurrencyCode)?.rateVsUSD ?? 1)
                      ).toFixed(5)} {toCurrencyCode}
                    </code>
                  </span>
                </div>
                <div className="text-slate-500">
                  Spread fee: <span className="text-emerald-400 font-bold">0.00%</span> (No commission)
                </div>
              </div>

            </div>

            {/* Popular conversion matrix references */}
            <div className="space-y-2.5">
              <span className="text-xs font-mono font-bold text-slate-300 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5 text-pink-400" /> Major Foreign Exchange Dash Index (v.s. 1 USD base)
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {currencyValues.filter(c => c.code !== 'USD').map((curr) => {
                  const isUp = curr.trend24h > 0;
                  const isDown = curr.trend24h < 0;
                  return (
                    <div
                      key={curr.code}
                      onClick={() => {
                        // User can click to preview cross rates directly
                        setFromCurrencyCode('USD');
                        setToCurrencyCode(curr.code);
                      }}
                      className="bg-[#020617]/50 border border-slate-850 hover:border-indigo-500/30 transition-all hover:bg-slate-900/20 p-3 rounded-xl cursor-pointer select-none space-y-1"
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-mono font-extrabold text-slate-200">
                          {curr.flag} {curr.code}/USD
                        </span>
                        {curr.trend24h !== 0 && (
                          <div className={`flex items-center text-[9px] font-mono font-bold ${isUp ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {isUp ? '+' : ''}
                            {curr.trend24h}%
                          </div>
                        )}
                      </div>
                      <div className="text-sm font-mono font-black text-slate-400 tracking-tight">
                        {curr.symbol} {curr.rateVsUSD.toLocaleString(undefined, { maximumFractionDigits: 4 })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
