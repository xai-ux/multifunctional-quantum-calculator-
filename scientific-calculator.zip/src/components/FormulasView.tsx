import { useState, useMemo, useRef, useEffect } from 'react';
import {
  HelpCircle,
  TrendingUp,
  Info,
  Layers,
  Sparkles,
  Calculator,
  Compass,
  ChevronDown,
  Box,
  Check,
  Search,
  Copy,
  BookOpen,
  Sliders,
  Maximize2
} from 'lucide-react';
import { SHAPES_LIST, solveGeometry } from '../lib/formulasData';
import {
  ALGEBRA_FORMULAS,
  TRIG_FORMULAS,
  SPECIAL_TRIG_VALUES
} from '../lib/algebraTrigData';

// Converts LaTeX mathematical syntax to user-friendly human mathematical notation
function formatFormulaToHuman(tex: string): string {
  if (!tex) return '';
  let s = tex;

  // Convert fractions: \frac{A}{B} to (A) / (B)
  let prev;
  do {
    prev = s;
    s = s.replace(/\\frac\s*{(.*?)}{(.*?)}/g, '($1) / ($2)');
  } while (s !== prev);

  // Exponents
  s = s.replace(/\^2\b/g, '²');
  s = s.replace(/\^{2}/g, '²');
  s = s.replace(/\^3\b/g, '³');
  s = s.replace(/\^{3}/g, '³');
  s = s.replace(/\^4\b/g, '⁴');
  s = s.replace(/\^{4}/g, '⁴');
  s = s.replace(/\^n\b/g, 'ⁿ');
  s = s.replace(/\^{n}/g, 'ⁿ');

  // Subscripts
  s = s.replace(/_i\b/g, 'ᵢ');
  s = s.replace(/_{i}/g, 'ᵢ');
  s = s.replace(/_e\b/g, 'ₑ');
  s = s.replace(/_{e}/g, 'ₑ');
  s = s.replace(/_a\b/g, 'ₐ');
  s = s.replace(/_{a}/g, 'ₐ');
  s = s.replace(/_p\b/g, 'ₚ');
  s = s.replace(/_{p}/g, 'ₚ');
  s = s.replace(/_1\b/g, '₁');
  s = s.replace(/_2\b/g, '₂');
  s = s.replace(/_3\b/g, '₃');
  s = s.replace(/_{3}/g, '₃');
  s = s.replace(/\\vec\s*{(.*?)}/g, '$1⃗');
  s = s.replace(/\\vec\s*([a-zA-Z0-9])/g, '$1⃗');
  s = s.replace(/\\hat\s*{(.*?)}/g, '$1̂');
  s = s.replace(/\\hat\s*([a-zA-Z0-9])/g, '$1̂');
  s = s.replace(/\\mathbf\s*{(.*?)}/g, '$1');
  s = s.replace(/_{ext}/g, '_ext');
  s = s.replace(/_{int}/g, '_int');
  s = s.replace(/_{base}/g, '_base');
  s = s.replace(/_{lat}/g, '_lateral');

  // Square roots: \sqrt{x} and \sqrt x
  do {
    prev = s;
    s = s.replace(/\\sqrt\s*{(.*?)}/g, '√($1)');
    s = s.replace(/\\sqrt\s*([a-zA-Z0-9.\+-\/\\\*]+)/g, '√$1');
  } while (s !== prev);

  // Unicode mathematical symbols
  s = s.replace(/\\times/g, ' × ');
  s = s.replace(/\\cdot/g, ' · ');
  s = s.replace(/\\div/g, ' ÷ ');
  s = s.replace(/\\approx/g, ' ≈ ');
  s = s.replace(/\\pi/g, 'π');
  s = s.replace(/\\theta_e/g, 'θ_ext');
  s = s.replace(/\\theta_i/g, 'θ_int');
  s = s.replace(/\\theta/g, 'θ');
  s = s.replace(/\\alpha/g, 'α');
  s = s.replace(/\\beta/g, 'β');
  s = s.replace(/\\gamma/g, 'γ');
  s = s.replace(/\\delta/g, 'δ');
  s = s.replace(/\\phi/g, 'φ');
  s = s.replace(/\\cot/g, 'cot');
  s = s.replace(/\\sin/g, 'sin');
  s = s.replace(/\\cos/g, 'cos');
  s = s.replace(/\\tan/g, 'tan');
  s = s.replace(/\\arccos/g, 'arccos');
  s = s.replace(/\\arcsin/g, 'arcsin');
  s = s.replace(/\\arctan/g, 'arctan');
  s = s.replace(/\\deg/g, '°');
  s = s.replace(/\\circ/g, '°');
  s = s.replace(/\^\\circ/g, '°');
  s = s.replace(/\^\{?\\circ\}?/g, '°');
  s = s.replace(/\\infty/g, '∞');

  // Strip remaining LaTeX slashes and extra brackets
  s = s.replace(/\\([\{\}_^])/g, '$1');
  s = s.replace(/\\/g, ''); 
  s = s.replace(/[{}]/g, '');

  // Format cosmetic spacing and brackets
  s = s.replace(/\s+/g, ' ');

  return s.trim();
}

export default function FormulasView() {
  // Top formula tab segments: 'geometry' | 'algebra' | 'trigonometry'
  const [activeTab, setActiveTab] = useState<'geometry' | 'algebra' | 'trigonometry'>('geometry');

  // Search & Filters for Algebra
  const [algebraSearch, setAlgebraSearch] = useState<string>('');
  const [activeAlgebraCategory, setActiveAlgebraCategory] = useState<string>('All');

  // Search & Filters for Trig
  const [trigSearch, setTrigSearch] = useState<string>('');
  const [activeTrigCategory, setActiveTrigCategory] = useState<string>('All');

  // Shared copy state
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // ----------------------------------------------------
  // SECTION 1: GEOMETRY FORMULAS ENGINE PROPERTIES
  // ----------------------------------------------------
  const [selectedShapeId, setSelectedShapeId] = useState<string>('tri_equilateral');
  const [selectedCalcKey, setSelectedCalcKey] = useState<string>('area');
  const [isSolveForDropdownOpen, setIsSolveForDropdownOpen] = useState(false);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('All');

  const dropdownRef = useRef<HTMLDivElement>(null);

  // Filter categories available
  const subCategories = useMemo(() => {
    return ['All', 'Triangles', 'Quadrilaterals', 'Higher Polygons', 'Curved 2D Shapes', 'Polyhedrons (Flat Faces)', 'Curved Solids', 'Platonic Solids'];
  }, []);

  const activeShape = useMemo(() => {
    return SHAPES_LIST.find((s) => s.id === selectedShapeId) || SHAPES_LIST[0];
  }, [selectedShapeId]);

  // Track values for the shape inputs
  const [formValues, setFormValues] = useState<Record<string, string>>({});

  // Reset inputs with default values when selected shape changes
  useEffect(() => {
    const initialVals: Record<string, string> = {};
    activeShape.inputs.forEach((inp) => {
      initialVals[inp.key] = inp.defaultValue.toString();
    });
    setFormValues(initialVals);
  }, [selectedShapeId, activeShape]);

  // Adjust active calculation key when shape category switches between 2D and 3D
  useEffect(() => {
    if (activeShape.category === '2d') {
      setSelectedCalcKey('area');
    } else {
      setSelectedCalcKey('volume');
    }
  }, [selectedShapeId, activeShape]);

  // Filter shapes to show in the list
  const filteredShapes = useMemo(() => {
    if (activeCategoryFilter === 'All') return SHAPES_LIST;
    return SHAPES_LIST.filter((s) => s.subCategory === activeCategoryFilter);
  }, [activeCategoryFilter]);

  // All calculation keys based on 2D vs 3D
  const availableCalculations = useMemo(() => {
    if (activeShape.category === '2d') {
      return [
        { key: 'area', name: 'Area', desc: 'Enclosed flat space inside shape' },
        { key: 'perimeter', name: 'Perimeter / Circumference', desc: 'Total surrounding boundary distance' },
        { key: 'interior_angles', name: 'Interior Angles', desc: 'Angles formed inside the shape faces' },
        { key: 'exterior_angles', name: 'Exterior Angles', desc: 'Angles formed outside extending standard edges' },
        { key: 'diagonal_length', name: 'Diagonal / Altitude', desc: 'Corner-to-corner length or altitude diagonal' },
        { key: 'radius', name: 'Circumradius (R)', desc: 'Distance from center to vertices' },
        { key: 'diameter', name: 'Diameter (D)', desc: 'Full bounding width metric' },
        { key: 'apothem', name: 'Apothem (Inradius r)', desc: 'Concentric radius perpendicular to flat edges' },
        { key: 'centroid', name: 'Centroid', desc: 'Geometric balancing point center of mass' },
        { key: 'moment_of_inertia', name: 'Moment of Inertia', desc: 'Rotational area second moment of inertia' },
        { key: 'perimeter_to_area_ratio', name: 'Perimeter-to-Area Ratio', desc: 'Symmetrical spatial compactness metric' },
      ];
    } else {
      return [
        { key: 'volume', name: 'Volume Capacity', desc: 'Total three-dimensional capacity space inside' },
        { key: 'surface_area', name: 'Total Surface Area', desc: 'Total outward area of all combined faces' },
        { key: 'lateral_surface_area', name: 'Lateral / Curved Area', desc: 'Side face areas excluding top & bottom base caps' },
        { key: 'slant_height', name: 'Slant Height', desc: 'Elevation diagonal distance from base edge' },
        { key: 'space_diagonal', name: 'Space Diagonal', desc: 'Internal corner-to-corner diagonal distance' },
        { key: 'face_diagonal', name: 'Face Diagonal', desc: 'Diagonal line drawn across a single flat plane face' },
        { key: 'edge_length', name: 'Cumulative Edge Length', desc: 'Combined lengths of all structural meet lines' },
        { key: 'base_area', name: 'Base Area', desc: 'Area metric profile of the foundational base plane' },
        { key: 'centroid', name: 'Volume Centroid', desc: 'Center of mass balance point position' },
        { key: 'moment_of_inertia', name: 'Moment of Rotational Inertia', desc: 'Resistance coefficient to circular acceleration' },
        { key: 'perimeter_to_area_ratio', name: 'Surface-to-Volume Ratio', desc: 'Outward area per dimensional capacity index' },
      ];
    }
  }, [activeShape]);

  // Solve the geometry based on state
  const calculationResult = useMemo(() => {
    try {
      return solveGeometry(selectedShapeId, selectedCalcKey, formValues);
    } catch (err) {
      return {
        result: 0,
        formulaTex: 'Error',
        steps: [{ title: 'Failed to compute', detail: 'Verify input boundaries are positive numbers.' }]
      };
    }
  }, [selectedShapeId, selectedCalcKey, formValues]);

  // Handle dropdown click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsSolveForDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleInputChange = (key: string, val: string) => {
    setFormValues((prev) => ({ ...prev, [key]: val }));
  };

  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // ----------------------------------------------------
  // SECTION 2: ALGEBRA ENGINE WIDGETS & LOGIC
  // ----------------------------------------------------
  const [quadA, setQuadA] = useState<string>('1');
  const [quadB, setQuadB] = useState<string>('-5');
  const [quadC, setQuadC] = useState<string>('6');

  const quadSolution = useMemo(() => {
    const a = parseFloat(quadA);
    const b = parseFloat(quadB);
    const c = parseFloat(quadC);

    if (isNaN(a) || isNaN(b) || isNaN(c)) {
      return { error: 'Please enter valid coefficients.', steps: [], resultString: '' };
    }
    if (a === 0) {
      return { error: 'Coefficient "a" cannot be 0 in a quadratic equation.', steps: [], resultString: '' };
    }

    const steps: string[] = [];
    const discValue = b * b - 4 * a * c;
    steps.push(`Discriminant computation (Δ): Δ = b² - 4ac = (${b})² - 4·(${a})·(${c}) = ${b * b} - ${4 * a * c} = ${discValue}`);

    if (discValue > 0) {
      const rootD = Math.sqrt(discValue);
      const x1 = (-b + rootD) / (2 * a);
      const x2 = (-b - rootD) / (2 * a);
      steps.push(`Since Δ > 0, there are 2 distinct real roots.`);
      steps.push(`Solve using Quadratic Formula: x = [-b ± √Δ] / (2a)`);
      steps.push(`x₁ = [-(${b}) + √${discValue}] / (2 · ${a}) = [${-b} + ${rootD.toFixed(4)}] / ${2 * a} = ${x1.toFixed(5)}`);
      steps.push(`x₂ = [-(${b}) - √${discValue}] / (2 · ${a}) = [${-b} - ${rootD.toFixed(4)}] / ${2 * a} = ${x2.toFixed(5)}`);
      return {
        type: 'real_two',
        disc: discValue,
        roots: [x1.toFixed(5), x2.toFixed(5)],
        steps,
        resultString: `x₁ = ${x1.toFixed(5)},  x₂ = ${x2.toFixed(5)}`
      };
    } else if (discValue === 0) {
      const x = -b / (2 * a);
      steps.push(`Since Δ = 0, there is exactly 1 repeated real root.`);
      steps.push(`Root: x = -b / (2a) = -(${b}) / (2 · ${a}) = ${x.toFixed(5)}`);
      return {
        type: 'real_one',
        disc: discValue,
        roots: [x.toFixed(5)],
        steps,
        resultString: `x = ${x.toFixed(5)} (Repeated Root)`
      };
    } else {
      const realPart = -b / (2 * a);
      const imagPart = Math.sqrt(-discValue) / (2 * a);
      const r1Str = `${realPart.toFixed(5)} + ${imagPart.toFixed(5)}i`;
      const r2Str = `${realPart.toFixed(5)} - ${imagPart.toFixed(5)}i`;
      steps.push(`Since Δ < 0, there are 2 complex (imaginary) roots.`);
      steps.push(`Solve: x = -b/(2a) ± i · √(|Δ|)/(2a)`);
      steps.push(`Real Part = -(${b}) / (2 · ${a}) = ${realPart.toFixed(5)}`);
      steps.push(`Imaginary Part = √(${Math.abs(discValue)}) / (2 · ${a}) = ${imagPart.toFixed(5)}`);
      steps.push(`Roots: x₁,₂ = ${realPart.toFixed(5)} ± ${imagPart.toFixed(5)}i`);
      return {
        type: 'complex',
        disc: discValue,
        roots: [r1Str, r2Str],
        steps,
        resultString: `x₁,₂ = ${realPart.toFixed(5)} ± ${imagPart.toFixed(5)}i`
      };
    }
  }, [quadA, quadB, quadC]);

  const filteredAlgebraFormulas = useMemo(() => {
    const sTerm = algebraSearch.toLowerCase();
    
    return ALGEBRA_FORMULAS.map((cat) => {
      // If Category filter does not match, skip
      if (activeAlgebraCategory !== 'All' && cat.categoryName !== activeAlgebraCategory) {
        return { ...cat, items: [] };
      }
      const filteredItems = cat.items.filter((item) => {
        return (
          item.name.toLowerCase().includes(sTerm) ||
          item.formula.toLowerCase().includes(sTerm) ||
          item.humanReadable.toLowerCase().includes(sTerm) ||
          item.example.toLowerCase().includes(sTerm)
        );
      });
      return { ...cat, items: filteredItems };
    }).filter((cat) => cat.items.length > 0);
  }, [algebraSearch, activeAlgebraCategory]);

  const algebraCategories = useMemo(() => {
    return ['All', ...ALGEBRA_FORMULAS.map(c => c.categoryName)];
  }, []);

  // ----------------------------------------------------
  // SECTION 3: TRIGONOMETRY ENGINE PROPERTIES & WIDGETS
  // ----------------------------------------------------
  const [trigAngle, setTrigAngle] = useState<number>(45);

  const unitCircleValues = useMemo(() => {
    const angleRad = (trigAngle * Math.PI) / 180;
    const rawSin = Math.sin(angleRad);
    const rawCos = Math.cos(angleRad);

    const formatWithPrec = (v: number) => {
      if (Math.abs(v) < 1e-10) return '0.0000';
      return v.toFixed(4);
    };

    const sinStr = formatWithPrec(rawSin);
    const cosStr = formatWithPrec(rawCos);

    let tanStr = '';
    if (Math.abs(rawCos) < 1e-10) {
      tanStr = rawSin > 0 ? 'Undefined (∞)' : 'Undefined (-∞)';
    } else {
      tanStr = formatWithPrec(rawSin / rawCos);
    }

    let cscStr = '';
    if (Math.abs(rawSin) < 1e-10) {
      cscStr = 'Undefined (∞)';
    } else {
      cscStr = formatWithPrec(1 / rawSin);
    }

    let secStr = '';
    if (Math.abs(rawCos) < 1e-10) {
      secStr = 'Undefined (∞)';
    } else {
      secStr = formatWithPrec(1 / rawCos);
    }

    let cotStr = '';
    if (Math.abs(rawSin) < 1e-10) {
      cotStr = 'Undefined (∞)';
    } else {
      cotStr = formatWithPrec(rawCos / rawSin);
    }

    // SVG coordinates mapped inside a 100x100 viewport centered at 50,50
    // Radius of circle = 32
    return {
      rad: angleRad.toFixed(4),
      sin: sinStr,
      cos: cosStr,
      tan: tanStr,
      csc: cscStr,
      sec: secStr,
      cot: cotStr,
      x: 50 + 32 * rawCos,
      y: 50 - 32 * rawSin // Svg Y index decreases as we go up
    };
  }, [trigAngle]);

  const filteredTrigFormulas = useMemo(() => {
    const sTerm = trigSearch.toLowerCase();
    
    return TRIG_FORMULAS.map((cat) => {
      if (activeTrigCategory !== 'All' && cat.categoryName !== activeTrigCategory) {
        return { ...cat, items: [] };
      }
      const filteredItems = cat.items.filter((item) => {
        return (
          item.name.toLowerCase().includes(sTerm) ||
          item.formula.toLowerCase().includes(sTerm) ||
          item.humanReadable.toLowerCase().includes(sTerm) ||
          item.example.toLowerCase().includes(sTerm)
        );
      });
      return { ...cat, items: filteredItems };
    }).filter((cat) => cat.items.length > 0);
  }, [trigSearch, activeTrigCategory]);

  const trigCategories = useMemo(() => {
    return ['All', ...TRIG_FORMULAS.map(c => c.categoryName)];
  }, []);

  // ----------------------------------------------------
  // INTERACTIVE GEOMETRIC WIREFRAMES SVG RENDERER
  // ----------------------------------------------------
  const renderInteractiveSVG = () => {
    const strokeActive = "stroke-indigo-400";
    const strokeHelper = "stroke-pink-400/60";
    const fillShape = "fill-indigo-500/10";
    
    switch (selectedShapeId) {
      case 'tri_equilateral':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <polygon points="50,20 15,80 85,80" className={`${fillShape} ${strokeActive} stroke-[1.5]`} />
            <line x1="50" y1="20" x2="50" y2="80" className={`${strokeHelper} stroke-[1] stroke-dashed`} />
            <text x="52" y="50" className="text-[7px] font-mono fill-pink-300">h</text>
            <text x="50" y="88" className="text-[7px] font-mono fill-slate-350 text-center">a</text>
            <text x="25" y="48" className="text-[7px] font-mono fill-slate-400">a</text>
            <text x="70" y="48" className="text-[7px] font-mono fill-slate-400">a</text>
            <circle cx="50" cy="80" r="1.5" className="fill-slate-400" />
            <circle cx="50" cy="56" r="2" className="fill-indigo-400 animate-pulse" />
          </svg>
        );
      case 'tri_isosceles':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <polygon points="50,15 20,80 80,80" className={`${fillShape} ${strokeActive} stroke-[1.5]`} />
            <line x1="50" y1="15" x2="50" y2="80" className={`${strokeHelper} stroke-[1] stroke-dashed`} />
            <text x="52" y="45" className="text-[7px] font-mono fill-pink-300">h</text>
            <text x="50" y="88" className="text-[7px] font-mono fill-slate-400">b</text>
            <text x="28" y="45" className="text-[7px] font-mono fill-slate-400">a</text>
            <text x="68" y="45" className="text-[7px] font-mono fill-slate-400">a</text>
          </svg>
        );
      case 'tri_scalene':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <polygon points="40,20 15,80 85,80" className={`${fillShape} ${strokeActive} stroke-[1.5]`} />
            <line x1="40" y1="20" x2="40" y2="80" className={`${strokeHelper} stroke-[1] stroke-dashed`} />
            <text x="43" y="50" className="text-[7px] font-mono fill-pink-300">h_a</text>
            <text x="50" y="88" className="text-[7px] font-mono fill-slate-350">a</text>
            <text x="20" y="48" className="text-[7px] font-mono fill-slate-400 font-bold">b</text>
            <text x="63" y="48" className="text-[7px] font-mono fill-slate-400">c</text>
          </svg>
        );
      case 'tri_right':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <polygon points="25,20 25,80 85,80" className={`${fillShape} ${strokeActive} stroke-[1.5]`} />
            <rect x="25" y="74" width="6" height="6" className="fill-none stroke-indigo-400/40" />
            <text x="16" y="50" className="text-[7px] font-mono fill-slate-350">b</text>
            <text x="50" y="88" className="text-[7px] font-mono fill-slate-350">a</text>
            <text x="55" y="48" className="text-[7px] font-mono fill-pink-300">c (diag)</text>
          </svg>
        );
      case 'quad_square':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <rect x="25" y="25" width="50" height="50" rx="3" className={`${fillShape} ${strokeActive} stroke-[1.5]`} />
            <line x1="25" y1="25" x2="75" y2="75" className={`${strokeHelper} stroke-[1] stroke-dashed`} />
            <text x="50" y="21" className="text-[7px] font-mono fill-slate-350">s</text>
            <text x="18" y="52" className="text-[7px] font-mono fill-slate-350">s</text>
            <text x="52" y="48" className="text-[7px] font-mono fill-pink-300">d</text>
          </svg>
        );
      case 'quad_rectangle':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <rect x="18" y="30" width="64" height="40" rx="3" className={`${fillShape} ${strokeActive} stroke-[1.5]`} />
            <line x1="18" y1="30" x2="82" y2="70" className={`${strokeHelper} stroke-[1] stroke-dashed`} />
            <text x="50" y="25" className="text-[7px] font-mono fill-slate-350">l</text>
            <text x="11" y="52" className="text-[7px] font-mono fill-slate-350">w</text>
            <text x="52" y="48" className="text-[7px] font-mono fill-pink-300">d</text>
          </svg>
        );
      case 'quad_parallelogram':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <polygon points="30,30 80,30 70,70 20,70" className={`${fillShape} ${strokeActive} stroke-[1.5]`} />
            <line x1="30" y1="30" x2="30" y2="70" className={`${strokeHelper} stroke-[1] stroke-dashed`} />
            <text x="50" y="25" className="text-[7px] font-mono fill-slate-350">b</text>
            <text x="21" y="52" className="text-[7px] font-mono fill-slate-350">a</text>
            <text x="33" y="52" className="text-[7px] font-mono fill-pink-300">h</text>
            <text x="24" y="66" className="text-[5px] font-mono fill-indigo-300 font-bold">θ</text>
          </svg>
        );
      case 'quad_rhombus':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <polygon points="50,15 80,50 50,85 20,50" className={`${fillShape} ${strokeActive} stroke-[1.5]`} />
            <line x1="50" y1="15" x2="50" y2="85" className={`${strokeHelper} stroke-[1] stroke-dashed`} />
            <line x1="20" y1="50" x2="80" y2="50" className={`${strokeHelper} stroke-[1] stroke-dashed`} />
            <text x="68" y="28" className="text-[7px] font-mono fill-slate-350">s</text>
            <text x="52" y="35" className="text-[7px] font-mono fill-pink-300">d2</text>
            <text x="35" y="48" className="text-[7px] font-mono fill-pink-300">d1</text>
          </svg>
        );
      case 'quad_trapezoid':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <polygon points="30,30 70,30 85,70 15,70" className={`${fillShape} ${strokeActive} stroke-[1.5]`} />
            <line x1="30" y1="30" x2="30" y2="70" className={`${strokeHelper} stroke-[1] stroke-dashed`} />
            <text x="50" y="25" className="text-[7px] font-mono fill-slate-350">b</text>
            <text x="50" y="78" className="text-[7px] font-mono fill-slate-350">a</text>
            <text x="18" y="50" className="text-[7px] font-mono fill-slate-400">c</text>
            <text x="80" y="50" className="text-[7px] font-mono fill-slate-400">d</text>
            <text x="33" y="52" className="text-[7px] font-mono fill-pink-300">h</text>
          </svg>
        );
      case 'quad_kite':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <polygon points="50,15 80,45 50,85 20,45" className={`${fillShape} ${strokeActive} stroke-[1.5]`} />
            <line x1="50" y1="15" x2="50" y2="85" className={`${strokeHelper} stroke-[1] stroke-dashed`} />
            <line x1="20" y1="45" x2="80" y2="45" className={`${strokeHelper} stroke-[1] stroke-dashed`} />
            <text x="68" y="28" className="text-[7px] font-mono fill-slate-450">a</text>
            <text x="68" y="68" className="text-[7px] font-mono fill-slate-450">b</text>
            <text x="52" y="32" className="text-[6px] font-mono fill-pink-300">d2</text>
            <text x="30" y="43" className="text-[6px] font-mono fill-pink-300">d1</text>
          </svg>
        );
      case 'poly_pentagon':
      case 'poly_hexagon':
      case 'poly_heptagon':
      case 'poly_octagon':
      case 'poly_nonagon':
      case 'poly_decagon': {
        let n = 5;
        if (selectedShapeId === 'poly_hexagon') n = 6;
        else if (selectedShapeId === 'poly_heptagon') n = 7;
        else if (selectedShapeId === 'poly_octagon') n = 8;
        else if (selectedShapeId === 'poly_nonagon') n = 9;
        else if (selectedShapeId === 'poly_decagon') n = 10;

        const points: string[] = [];
        for (let i = 0; i < n; i++) {
          const angle = (i * 2 * Math.PI) / n - Math.PI / 2;
          const x = 50 + 32 * Math.cos(angle);
          const y = 50 + 32 * Math.sin(angle);
          points.push(`${x},${y}`);
        }
        
        const midAngle = (0.5 * 2 * Math.PI) / n - Math.PI / 2;
        const apoX = 50 + (32 * Math.cos(Math.PI / n)) * Math.cos(midAngle);
        const apoY = 50 + (32 * Math.cos(Math.PI / n)) * Math.sin(midAngle);

        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <polygon points={points.join(' ')} className={`${fillShape} ${strokeActive} stroke-[1.5]`} />
            <circle cx="50" cy="50" r="32" className="fill-none stroke-slate-700 stroke-[0.8] stroke-dashed" />
            <line x1="50" y1="50" x2="50" y2="18" className={`${strokeHelper} stroke-[1]`} />
            <line x1="50" y1="50" x2={apoX} y2={apoY} className="stroke-emerald-400 stroke-[1] stroke-dashed" />
            <circle cx="50" cy="50" r="1.5" className="fill-slate-100" />
            <text x="52" y="32" className="text-[6px] font-mono fill-pink-300">R</text>
            <text x="49" y="59" className="text-[6px] font-mono fill-emerald-300 font-semibold text-center">a_p</text>
            <text x="80" y="52" className="text-[7px] font-mono fill-slate-350">s</text>
          </svg>
        );
      }
      case 'curve_circle':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <circle cx="50" cy="50" r="32" className={`${fillShape} ${strokeActive} stroke-[1.5]`} />
            <line x1="50" y1="50" x2="82" y2="50" className={`${strokeHelper} stroke-[1.5]`} />
            <line x1="18" y1="50" x2="50" y2="50" className="stroke-indigo-300/40 stroke-[1.5] stroke-dashed" />
            <circle cx="50" cy="50" r="2.5" className="fill-slate-100" />
            <text x="64" y="44" className="text-[7px] font-mono fill-pink-300">r</text>
            <text x="32" y="44" className="text-[6px] font-mono fill-indigo-300/60">d (full)</text>
          </svg>
        );
      case 'curve_semicircle':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <path d="M 18 60 A 32 32 0 0 1 82 60 Z" className={`${fillShape} ${strokeActive} stroke-[1.5]`} />
            <line x1="50" y1="60" x2="50" y2="28" className={`${strokeHelper} stroke-[1] stroke-dashed`} />
            <line x1="50" y1="60" x2="82" y2="60" className="stroke-indigo-300 stroke-[1.5]" />
            <circle cx="50" cy="60" r="2" className="fill-slate-100" />
            <text x="64" y="54" className="text-[7px] font-mono fill-indigo-300">r</text>
            <text x="44" y="42" className="text-[7px] font-mono fill-pink-300">r</text>
          </svg>
        );
      case 'curve_ellipse':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <ellipse cx="50" cy="50" rx="38" ry="24" className={`${fillShape} ${strokeActive} stroke-[1.5]`} />
            <line x1="12" y1="50" x2="88" y2="50" className="stroke-indigo-300/40 stroke-[1] stroke-dashed" />
            <line x1="50" y1="26" x2="50" y2="74" className="stroke-indigo-300/40 stroke-[1] stroke-dashed" />
            <line x1="50" y1="50" x2="88" y2="50" className={`${strokeHelper} stroke-[1.5]`} />
            <line x1="50" y1="50" x2="50" y2="26" className="stroke-teal-400 stroke-[1.5]" />
            <circle cx="50" cy="50" r="2" className="fill-slate-100" />
            <text x="66" y="44" className="text-[7px] font-mono fill-pink-300">a</text>
            <text x="53" y="38" className="text-[7px] font-mono fill-teal-300">b</text>
          </svg>
        );
      case 'solid_cube':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <line x1="38" y1="26" x2="38" y2="58" className="stroke-dashed stroke-indigo-400/30 stroke-[1]" />
            <line x1="16" y1="58" x2="38" y2="58" className="stroke-dashed stroke-indigo-400/30 stroke-[1]" />
            <line x1="38" y1="58" x2="60" y2="58" className="stroke-dashed stroke-indigo-400/30 stroke-[1]" />
            <rect x="16" y="42" width="44" height="32" className="fill-none stroke-indigo-400 stroke-[1.5]" />
            <polygon points="16,42 38,26 82,26 60,42" className="fill-indigo-500/5 stroke-indigo-400 stroke-[1.5]" />
            <polygon points="60,42 82,26 82,58 60,74" className="fill-indigo-500/5 stroke-indigo-400 stroke-[1.5]" />
            <line x1="16" y1="74" x2="38" y2="58" className="stroke-dashed stroke-indigo-400/20" />
            <line x1="16" y1="74" x2="82" y2="26" className="stroke-dashed stroke-pink-400 stroke-[1.2]" />
            <text x="50" y="21" className="text-[7px] font-mono fill-slate-350">s</text>
            <text x="11" y="58" className="text-[7px] font-mono fill-slate-350">s</text>
            <text x="44" y="50" className="text-[7px] font-mono fill-pink-300">d</text>
            <circle cx="16" cy="74" r="1.5" className="fill-pink-400" />
            <circle cx="82" cy="26" r="1.5" className="fill-pink-400" />
          </svg>
        );
      case 'solid_cuboid':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <line x1="32" y1="28" x2="32" y2="58" className="stroke-dashed stroke-indigo-400/30 stroke-[1]" />
            <line x1="14" y1="58" x2="32" y2="58" className="stroke-dashed stroke-indigo-400/30 stroke-[1]" />
            <rect x="14" y="42" width="54" height="30" className="fill-none stroke-indigo-400 stroke-[1.5]" />
            <polygon points="14,42 32,28 86,28 68,42" className="fill-indigo-500/5 stroke-indigo-400 stroke-[1.5]" />
            <polygon points="68,42 86,28 86,58 68,72" className="fill-indigo-500/5 stroke-indigo-400 stroke-[1.5]" />
            <line x1="14" y1="72" x2="32" y2="58" className="stroke-dashed stroke-indigo-400/20" />
            <text x="41" y="78" className="text-[7px] font-mono fill-slate-400">l</text>
            <text x="8" y="56" className="text-[7px] font-mono fill-slate-400">h</text>
            <text x="76" y="36" className="text-[7px] font-mono fill-slate-400">w</text>
          </svg>
        );
      case 'solid_triprism':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <polygon points="30,30 50,15 70,30" className="fill-indigo-500/5 stroke-indigo-400 stroke-[1.2]" />
            <polygon points="30,75 50,60 70,75" className="fill-indigo-500/5 stroke-indigo-400 stroke-[1.2]" />
            <line x1="30" y1="30" x2="30" y2="75" className="stroke-indigo-400 stroke-[1.5]" />
            <line x1="50" y1="15" x2="50" y2="60" className="stroke-dashed stroke-indigo-400/30 stroke-[1]" />
            <line x1="70" y1="30" x2="70" y2="75" className="stroke-indigo-400 stroke-[1.5]" />
            <text x="50" y="10" className="text-[7px] font-mono fill-slate-400 text-center">a</text>
            <text x="75" y="52" className="text-[7px] font-mono fill-pink-300">h (L)</text>
          </svg>
        );
      case 'solid_pyramid':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <polygon points="25,75 75,75 88,60 38,60" className="fill-none stroke-dashed stroke-indigo-400/30" />
            <polygon points="25,75 75,75 50,25" className="fill-indigo-500/5 stroke-indigo-400 stroke-[1.5]" />
            <polygon points="75,75 88,60 50,25" className="fill-indigo-500/5 stroke-indigo-400 stroke-[1.5]" />
            <line x1="25" y1="75" x2="50" y2="25" className="stroke-indigo-400 stroke-[1.5]" />
            <line x1="38" y1="60" x2="50" y2="25" className="stroke-dashed stroke-indigo-400/30 stroke-[1]" />
            <line x1="50" y1="25" x2="50" y2="67" className={`${strokeHelper} stroke-[1] stroke-dashed`} />
            <line x1="50" y1="25" x2="62.5" y2="75" className="stroke-emerald-400 stroke-[1.2] stroke-dashed" />
            <text x="50" y="82" className="text-[7px] font-mono fill-slate-350">a</text>
            <text x="44" y="46" className="text-[7px] font-mono fill-pink-300">h</text>
            <text x="58" y="46" className="text-[6.5px] font-mono fill-emerald-300">slant</text>
          </svg>
        );
      case 'solid_sphere':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <circle cx="50" cy="50" r="32" className={`${fillShape} ${strokeActive} stroke-[1.5]`} />
            <ellipse cx="50" cy="50" rx="32" ry="8" className="fill-none stroke-dashed stroke-indigo-300/40" />
            <ellipse cx="50" cy="50" rx="8" ry="32" className="fill-none stroke-dashed stroke-indigo-300/20" />
            <line x1="50" y1="50" x2="82" y2="50" className={`${strokeHelper} stroke-[1.5]`} />
            <circle cx="50" cy="50" r="1.5" className="fill-slate-100" />
            <text x="64" y="44" className="text-[7px] font-mono fill-pink-300">r</text>
          </svg>
        );
      case 'solid_cylinder':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <path d="M 25 75 A 25 7 0 0 0 75 75" fill="none" className="stroke-dashed stroke-indigo-400/40 stroke-[1.5]" />
            <path d="M 25 75 A 25 7 0 0 1 75 75" fill="none" className="stroke-indigo-400 stroke-[1.5]" />
            <line x1="25" y1="25" x2="25" y2="75" className="stroke-indigo-400 stroke-[1.5]" />
            <line x1="75" y1="25" x2="75" y2="75" className="stroke-indigo-400 stroke-[1.5]" />
            <ellipse cx="50" cy="25" rx="25" ry="7" className="fill-indigo-500/5 stroke-indigo-400 stroke-[1.5]" />
            <line x1="50" y1="25" x2="50" y2="75" className="stroke-dashed stroke-slate-500 stroke-[1]" />
            <line x1="50" y1="25" x2="75" y2="25" className="stroke-pink-400 stroke-[1.2]" />
            <text x="62" y="21" className="text-[7px] font-mono fill-pink-300">r</text>
            <text x="42" y="52" className="text-[7px] font-mono fill-slate-350">h</text>
          </svg>
        );
      case 'solid_cone':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <path d="M 25 75 A 25 7 0 0 0 75 75" fill="none" className="stroke-dashed stroke-indigo-400/40 stroke-[1.5]" />
            <path d="M 25 75 A 25 7 0 0 1 75 75" fill="none" className="stroke-indigo-400 stroke-[1.5]" />
            <line x1="25" y1="75" x2="50" y2="25" className="stroke-indigo-400 stroke-[1.5]" />
            <line x1="75" y1="75" x2="50" y2="25" className="stroke-indigo-400 stroke-[1.5]" />
            <line x1="50" y1="25" x2="50" y2="75" className="stroke-dashed stroke-indigo-300/40 stroke-[1]" />
            <line x1="50" y1="75" x2="75" y2="75" className="stroke-pink-400 stroke-[1.2]" />
            <text x="62" y="72" className="text-[7px] font-mono fill-pink-300">r</text>
            <text x="42" y="50" className="text-[7px] font-mono fill-slate-350">h</text>
            <text x="64" y="44" className="text-[6px] font-mono fill-emerald-300">l (slant)</text>
          </svg>
        );
      case 'solid_torus':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <ellipse cx="50" cy="50" rx="38" ry="20" className="fill-none stroke-indigo-400 stroke-[1.5]" />
            <ellipse cx="50" cy="50" rx="22" ry="11" className="fill-none stroke-indigo-400 stroke-[1.2]" />
            <ellipse cx="50" cy="50" rx="30" ry="15.5" className="fill-none stroke-dashed stroke-pink-400/30" />
            <line x1="50" y1="50" x2="80" y2="50" className={`${strokeHelper} stroke-[1] stroke-dashed`} />
            <circle cx="50" cy="50" r="1.5" className="fill-slate-100" />
            <text x="66" y="44" className="text-[6.5px] font-mono fill-pink-300">R</text>
            <text x="73" y="58" className="text-[6.5px] font-mono fill-slate-350">r</text>
          </svg>
        );
      case 'plat_tetrahedron':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <polygon points="50,15 15,75 85,75" className="fill-indigo-500/5 stroke-indigo-400 stroke-[1.5]" />
            <line x1="50" y1="15" x2="50" y2="50" className="stroke-indigo-400 stroke-[1.2]" />
            <line x1="15" y1="75" x2="50" y2="50" className="stroke-indigo-400 stroke-[1.2]" />
            <line x1="85" y1="75" x2="50" y2="50" className="stroke-indigo-400 stroke-[1.2]" />
            <text x="50" y="82" className="text-[7px] font-mono fill-slate-350 text-center">a</text>
            <text x="25" y="44" className="text-[7px] font-mono fill-pink-300">a</text>
          </svg>
        );
      case 'plat_octahedron':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <polygon points="50,15 25,50 50,85" className="fill-indigo-500/5 stroke-indigo-400/40 stroke-[1.2]" />
            <polygon points="50,15 75,50 50,85" className="fill-indigo-500/5 stroke-indigo-400/40 stroke-[1.2]" />
            <polygon points="25,50 75,50 50,30" className="fill-none stroke-dashed stroke-indigo-300/30" />
            <line x1="50" y1="15" x2="50" y2="85" className="stroke-indigo-400 stroke-[1.5]" />
            <line x1="25" y1="50" x2="75" y2="50" className="stroke-indigo-400 stroke-[1.5]" />
            <text x="64" y="32" className="text-[7px] font-mono fill-slate-350">a</text>
            <text x="42" y="55" className="text-[6.5px] font-mono fill-pink-300">diag</text>
          </svg>
        );
      case 'plat_icosahedron':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <polygon points="50,15 80,40 68,75 32,75 20,40" className="fill-indigo-500/5 stroke-indigo-400 stroke-[1.5]" />
            <polygon points="50,15 50,48 20,40" className="fill-none stroke-indigo-300/40 stroke-[1]" />
            <polygon points="50,15 50,48 80,40" className="fill-none stroke-indigo-300/40 stroke-[1]" />
            <polygon points="32,75 50,48 68,75" className="fill-none stroke-indigo-300/40 stroke-[1]" />
            <line x1="20" y1="40" x2="32" y2="75" className="stroke-indigo-300/40 text-dashed" />
            <line x1="80" y1="40" x2="68" y2="75" className="stroke-indigo-300/40 text-dashed" />
            <text x="50" y="82" className="text-[7px] font-mono fill-slate-350 text-center">a</text>
          </svg>
        );
      case 'plat_dodecahedron':
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <polygon points="50,15 80,35 68,75 32,75 20,35" className="fill-indigo-500/5 stroke-indigo-400 stroke-[1.5]" />
            <polygon points="50,28 68,41 60,65 40,65 32,41" className="fill-none stroke-indigo-450 stroke-[1]" />
            <line x1="50" y1="15" x2="50" y2="28" className="stroke-indigo-400" />
            <line x1="80" y1="35" x2="68" y2="41" className="stroke-indigo-400" />
            <line x1="68" y1="75" x2="60" y2="65" className="stroke-indigo-400" />
            <line x1="32" y1="75" x2="40" y2="65" className="stroke-indigo-400" />
            <line x1="20" y1="35" x2="32" y2="41" className="stroke-indigo-400" />
            <text x="50" y="82" className="text-[7px] font-mono fill-slate-350 text-center">a</text>
          </svg>
        );
      
      default:
        return (
          <svg viewBox="0 0 100 100" className="w-full h-full max-h-[190px]">
            <rect x="25" y="25" width="50" height="50" rx="4" className="fill-indigo-500/10 stroke-indigo-400" />
            <circle cx="50" cy="50" r="1.5" className="fill-slate-100" />
          </svg>
        );
    }
  };

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden group">
      
      {/* Background radial gradients for styling */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/5 rounded-full blur-[80px] pointer-events-none" />
      <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-pink-500/5 rounded-full blur-[80px] pointer-events-none" />

      <div className="flex flex-col gap-6 relative z-10">
        
        {/* Top Header section containing Navigation Tabs */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800/80 pb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-100 tracking-tight flex items-center gap-2">
                <span>Integrated Mathematics Formula Manual</span>
                <span className="text-[9px] font-mono font-bold tracking-wider text-pink-400 bg-pink-500/10 px-2 py-0.5 rounded border border-pink-500/10 uppercase">
                  Cas Reference Board
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Explore comprehensive lists of Geometric, Algebraic and Trigonometric identities with live interactive calculators.
              </p>
            </div>
          </div>
        </div>

        {/* Global tab segments: Geometry, Algebra, Trigonometry */}
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none border-b border-slate-800/40 pb-3">
          <button
            onClick={() => setActiveTab('geometry')}
            className={`flex items-center gap-2 text-xs font-bold px-4 py-2.5 rounded-xl border transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'geometry'
                ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-300'
                : 'bg-[#0a0f1d] border-slate-800/60 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-indigo-400" />
            <span>Geometry Solver (31 Shapes)</span>
          </button>
          <button
            onClick={() => setActiveTab('algebra')}
            className={`flex items-center gap-2 text-xs font-bold px-4 py-2.5 rounded-xl border transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'algebra'
                ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-300'
                : 'bg-[#0a0f1d] border-slate-800/60 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-pink-400" />
            <span>Algebraic Indicies ({ALGEBRA_FORMULAS.reduce((acc, cat) => acc + cat.items.length, 0)} Formulas)</span>
          </button>
          <button
            onClick={() => setActiveTab('trigonometry')}
            className={`flex items-center gap-2 text-xs font-bold px-4 py-2.5 rounded-xl border transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'trigonometry'
                ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-300'
                : 'bg-[#0a0f1d] border-slate-800/60 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Compass className="w-3.5 h-3.5 text-emerald-400" />
            <span>Trigonometric Identities & Unit Circle</span>
          </button>
        </div>

        {/* ----------------------------------------------------
            TAB 1: GEOMETRY ENGINE
            ---------------------------------------------------- */}
        {activeTab === 'geometry' && (
          <div className="space-y-6">
            {/* Filter pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider font-bold mr-2 shrink-0">
                Shape Subtypes:
              </span>
              {subCategories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategoryFilter(cat)}
                  className={`text-xs font-semibold px-3 py-1.5 rounded-lg border transition-all whitespace-nowrap cursor-pointer ${
                    activeCategoryFilter === cat
                      ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-300'
                      : 'bg-slate-900/40 border-slate-800/80 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Shape list dashboard */}
            <div className="space-y-2">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block font-bold">
                Select Geometrical Figure ({filteredShapes.length} shown)
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 max-h-[175px] overflow-y-auto pr-1.5 scrollbar-thin">
                {filteredShapes.map((shape) => {
                  const isSelected = shape.id === selectedShapeId;
                  return (
                    <button
                      key={shape.id}
                      onClick={() => setSelectedShapeId(shape.id)}
                      id={`shape_selector_${shape.id}`}
                      className={`p-2.5 rounded-xl border text-left flex flex-col justify-between h-[74px] transition-all relative overflow-hidden cursor-pointer group/btn ${
                        isSelected
                          ? 'bg-gradient-to-br from-[#1e1b4b]/80 to-[#10172a] border-indigo-500 shadow-md shadow-indigo-500/5'
                          : 'bg-[#0a0f1d] border-slate-800/80 hover:border-slate-700 text-slate-400 hover:text-slate-100 hover:bg-slate-900/45'
                      }`}
                    >
                      <span className={`text-[9px] font-mono uppercase tracking-wider ${isSelected ? 'text-indigo-400' : 'text-slate-500'}`}>
                        {shape.subCategory.split(' ')[0]}
                      </span>
                      <div className="flex items-center justify-between mt-1 gap-1">
                        <span className="text-xs font-bold leading-tight font-sans truncate pr-1">
                          {shape.name}
                        </span>
                        {isSelected && (
                          <Check className="w-3 h-3 text-indigo-400 shrink-0" />
                        )}
                      </div>
                      {isSelected && (
                        <div className="absolute right-0 bottom-0 w-12 h-1 bg-gradient-to-r from-pink-500 to-indigo-500 animate-pulse" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Inputs & Vector visualizers */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-2">
              
              {/* Left inputs */}
              <div className="lg:col-span-7 flex flex-col gap-5">
                <div className="bg-[#0a0f1d]/50 border border-slate-800 p-5 rounded-2xl space-y-4">
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block font-bold">
                    Configure Spatial Dimensions
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    {activeShape.inputs.map((inp) => (
                      <div key={inp.key} className="bg-[#020617] border border-slate-800/50 rounded-xl p-3 flex items-center justify-between hover:border-slate-755 transition-colors">
                        <div className="flex items-center gap-2.5">
                          <div className="text-base font-serif font-bold italic text-indigo-300 w-6 text-center">
                            {inp.symbol}
                          </div>
                          <div className="leading-tight">
                            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider block">
                              {inp.label}
                            </span>
                            <span className="text-[8px] text-slate-500 font-mono block animate-pulse">
                              Variable ({inp.symbol})
                            </span>
                          </div>
                        </div>
                        <input
                          type="number"
                          id={`shape_input_${inp.key}`}
                          value={formValues[inp.key] ?? ''}
                          onChange={(e) => handleInputChange(inp.key, e.target.value)}
                          placeholder={inp.placeholder}
                          className="w-24 bg-[#0a0f1d] border border-indigo-900/40 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-lg px-2 py-1.5 text-xs text-slate-100 font-mono text-right outline-none transition-all text-white font-bold"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Dropdown pivot key */}
                <div className="relative" ref={dropdownRef}>
                  <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider font-bold block mb-1.5">
                    Select Target Dimension to Solve for
                  </span>
                  <button
                    onClick={() => setIsSolveForDropdownOpen(!isSolveForDropdownOpen)}
                    id="solve_for_dropdown_trigger"
                    className="w-full flex items-center justify-between bg-gradient-to-r from-slate-900 to-[#101729] border border-indigo-905/60 hover:border-indigo-500/50 rounded-xl px-4 py-3 text-left transition-colors font-sans text-sm cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <Calculator className="w-4 h-4 text-indigo-400" />
                      <div className="leading-tight">
                        <span className="text-xs font-bold text-slate-250">
                          Solve for: {availableCalculations.find((c) => c.key === selectedCalcKey)?.name || 'Select Metirc...'}
                        </span>
                        <span className="text-[10px] text-slate-450 block font-mono">
                          {availableCalculations.find((c) => c.key === selectedCalcKey)?.desc || ''}
                        </span>
                      </div>
                    </div>
                    <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isSolveForDropdownOpen ? 'rotate-180' : ''}`} />
                  </button>

                  {isSolveForDropdownOpen && (
                    <div className="absolute left-0 right-0 mt-1 bg-slate-950 border border-slate-850 rounded-xl shadow-2xl z-20 max-h-[220px] overflow-y-auto scrollbar-thin">
                      <div className="p-1.5 grid grid-cols-1 gap-0.5">
                        {availableCalculations.map((calc) => {
                          const isSel = calc.key === selectedCalcKey;
                          return (
                            <button
                              key={calc.key}
                              onClick={() => {
                                setSelectedCalcKey(calc.key);
                                setIsSolveForDropdownOpen(false);
                              }}
                              className={`w-full text-left p-2.5 rounded-lg flex items-center justify-between text-xs transition-colors cursor-pointer ${
                                isSel
                                  ? 'bg-indigo-600/10 border border-indigo-500/20 text-indigo-300'
                                  : 'hover:bg-slate-900 text-slate-400 hover:text-slate-200'
                              }`}
                            >
                              <div>
                                <span className="font-bold block">{calc.name}</span>
                                <span className="text-[9px] text-slate-500 font-mono block">{calc.desc}</span>
                              </div>
                              {isSel && <Check className="w-3.5 h-3.5 text-indigo-400 shrink-0" />}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Graphical wireframe output vector */}
              <div className="lg:col-span-5 bg-[#020617]/50 border border-slate-800/60 rounded-2xl p-5 flex flex-col items-center justify-between min-h-[200px] relative overflow-hidden">
                <div className="absolute top-0 right-0 bg-[#0F172A] border-l border-b border-indigo-900/40 rounded-bl-xl px-2.5 py-1 text-[8px] font-mono text-indigo-400 tracking-wider font-bold">
                  PROJECTOR WIRE
                </div>
                <div className="w-full text-left mb-2">
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">
                    Interactive structural schema
                  </span>
                  <span className="text-xs font-semibold text-slate-300 leading-tight">
                    {activeShape.name} Projection
                  </span>
                </div>
                
                <div className="w-full flex items-center justify-center py-4">
                  {renderInteractiveSVG()}
                </div>

                <div className="w-full text-center text-[10px] font-mono text-slate-500">
                  Dynamic variables reflect instantly on vertices
                </div>
              </div>

            </div>

            {/* Results, exact formula mathematical representations, and steps */}
            <div className="border-t border-slate-800/80 mt-6 pt-5 grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              <div className="lg:col-span-5 bg-indigo-950/20 border border-indigo-900/30 rounded-2xl p-5 flex flex-col justify-between gap-5">
                <div>
                  <span className="text-[9px] font-mono text-indigo-400 uppercase tracking-widest font-bold block mb-1">
                    Formula Definition Used
                  </span>
                  <div className="bg-[#020617] border border-slate-900 rounded-xl p-4 flex flex-col items-center justify-center text-center py-5 shadow-inner overflow-x-auto relative group">
                    <button
                      onClick={() => handleCopyText(calculationResult.formulaTex, 'geom_copy')}
                      className="absolute right-2.5 top-2.5 p-1.5 rounded-lg bg-slate-900/80 border border-slate-800 hover:text-white text-slate-400 transition-colors cursor-pointer"
                      title="Copy LaTeX formula"
                    >
                      {copiedId === 'geom_copy' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                    <span className="text-base font-bold tracking-wide block leading-relaxed text-indigo-200 font-serif px-2">
                      {formatFormulaToHuman(calculationResult.formulaTex)}
                    </span>
                    <span className="text-[8px] font-mono text-slate-500 uppercase tracking-widest mt-2 block">
                      TeX: <code className="text-indigo-400/50">{calculationResult.formulaTex}</code>
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-[9px] font-mono text-slate-400 uppercase tracking-widest block mb-1">
                    Calculated CAS Area/Volume Output
                  </span>
                  <span className="text-3xl font-black font-mono tracking-tight text-white select-all break-all block">
                    {calculationResult.result.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 6 })}
                  </span>
                </div>
              </div>

              {/* Computational analytical steps */}
              <div className="lg:col-span-7 space-y-2 max-h-[178px] overflow-y-auto pr-1 scrollbar-thin">
                <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest font-bold block mb-1 sticky top-0 bg-[#0b1329] py-1">
                  Derivation steps logs
                </span>
                {calculationResult.steps.map((st, idx) => (
                  <div key={idx} className="bg-slate-955/40 border border-slate-900/80 p-3 rounded-xl flex items-start gap-3 hover:border-slate-800/80 transition-colors">
                    <div className="w-5 h-5 bg-indigo-500/10 rounded-full flex items-center justify-center text-[10px] font-mono text-indigo-400 font-bold shrink-0 mt-0.5 border border-indigo-500/10">
                      {idx + 1}
                    </div>
                    <div>
                      <h4 className="text-[9px] font-mono text-slate-450 uppercase tracking-wider font-bold">
                        {st.title}
                      </h4>
                      <p className="text-xs text-slate-300 mt-0.5 font-mono leading-relaxed">
                        {st.detail}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

            </div>

            <div className="bg-[#020617]/40 border border-slate-800/60 rounded-xl p-4 text-[10px] font-mono text-slate-400 space-y-1.5 leading-relaxed">
              <h4 className="text-slate-200 font-sans font-medium flex items-center gap-1.5 text-xs mb-1">
                <HelpCircle className="w-3.5 h-3.5 text-slate-400" /> Interactive Geometry Foundations
              </h4>
              <p>
                • <strong>Calculative Tool:</strong> Change input values in real time to instantly compute Area, Perimeter, Diagonal, Apothem, Centroid, Moment of Inertia, and more.
              </p>
              <p>
                • <strong>Platonic Solids Edge Integrals:</strong> Solid models (Tetrahedron, Octahedron, Icosahedron, Dodecahedron) solve precise modular space volume coordinates using exact golden-ratio formulations (phi = (1 + √5) / 2).
              </p>
            </div>
          </div>
        )}

        {/* ----------------------------------------------------
            TAB 2: ALGEBRAIC FORMULAS INDEX & SOLVER WIDGET
            ---------------------------------------------------- */}
        {activeTab === 'algebra' && (
          <div className="space-y-6">
            
            {/* Live Interactive Quadratic Equation solver widget */}
            <div className="bg-gradient-to-br from-indigo-950/15 to-[#020617]/80 border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-indigo-950/50 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-pink-500/10 border border-pink-500/20 flex items-center justify-center">
                    <Calculator className="w-4 h-4 text-pink-400 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-200">Interactive Quadratic Equation CAD Resolver</h3>
                    <p className="text-[10px] text-slate-400 font-mono">Solve any ax² + bx + c = 0 in real-time</p>
                  </div>
                </div>
                <div className="text-[8px] font-mono bg-pink-500/10 text-pink-400 border border-pink-500/10 rounded px-2 py-0.5 font-bold uppercase tracking-widest">
                  Live Equation solver
                </div>
              </div>

              {/* Coefficients Inputs */}
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-1 bg-slate-950/60 border border-slate-900 p-2.5 rounded-xl">
                  <label className="text-[9px] font-mono text-slate-400 uppercase font-black block">Coeff. a</label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      step="any"
                      value={quadA}
                      onChange={(e) => setQuadA(e.target.value)}
                      className="w-full bg-transparent text-sm font-mono text-indigo-400 outline-none font-bold text-white"
                      placeholder="a"
                    />
                    <span className="text-[10px] font-semibold text-slate-500 font-mono">x²</span>
                  </div>
                </div>
                <div className="space-y-1 bg-slate-950/60 border border-slate-900 p-2.5 rounded-xl">
                  <label className="text-[9px] font-mono text-slate-400 uppercase font-black block">Coeff. b</label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      step="any"
                      value={quadB}
                      onChange={(e) => setQuadB(e.target.value)}
                      className="w-full bg-transparent text-sm font-mono text-indigo-400 outline-none font-bold text-white"
                      placeholder="b"
                    />
                    <span className="text-[10px] font-semibold text-slate-500 font-mono">x</span>
                  </div>
                </div>
                <div className="space-y-1 bg-slate-950/60 border border-slate-900 p-2.5 rounded-xl">
                  <label className="text-[9px] font-mono text-slate-400 uppercase font-black block">Coeff. c</label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      step="any"
                      value={quadC}
                      onChange={(e) => setQuadC(e.target.value)}
                      className="w-full bg-transparent text-sm font-mono text-indigo-400 outline-none font-bold text-white"
                      placeholder="c"
                    />
                    <span className="text-[10px] font-semibold text-slate-500 font-mono">= 0</span>
                  </div>
                </div>
              </div>

              {/* Equation preview */}
              <div className="text-center font-mono py-2 bg-[#020617] border border-slate-900 rounded-xl relative">
                <span className="text-[9px] text-slate-500 uppercase font-bold absolute left-3.5 top-2 tracking-wider">Formula Preview:</span>
                <span className="text-sm font-bold text-slate-200">
                  {parseFloat(quadA) || 0}x² {parseFloat(quadB) >= 0 ? ` + ${parseFloat(quadB)}` : ` - ${Math.abs(parseFloat(quadB))}`}x {parseFloat(quadC) >= 0 ? ` + ${parseFloat(quadC)}` : ` - ${Math.abs(parseFloat(quadC))}`} = 0
                </span>
              </div>

              {/* Solution feedback */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                
                {/* LHS Quick result */}
                <div className="md:col-span-5 bg-indigo-950/20 border border-indigo-900/30 p-4 rounded-xl flex flex-col justify-center">
                  <span className="text-[8px] font-mono text-slate-400 uppercase tracking-widest block font-bold mb-1">
                    Roots Resolved:
                  </span>
                  {quadSolution.error ? (
                    <span className="text-xs text-rose-400 font-semibold">{quadSolution.error}</span>
                  ) : (
                    <div className="space-y-1.5">
                      <span className="text-lg font-black font-mono text-emerald-400 select-all block break-all">
                        {quadSolution.resultString}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono block">
                        Discriminant Δ = <span className="text-indigo-300 font-bold">{quadSolution.disc}</span>
                      </span>
                    </div>
                  )}
                </div>

                {/* RHS Steps list */}
                <div className="md:col-span-7 max-h-[110px] overflow-y-auto scrollbar-thin space-y-1.5 text-xs text-slate-300 pr-1 select-all font-mono">
                  {quadSolution.steps.map((st, i) => (
                    <div key={i} className="flex gap-2 items-start py-1 border-b border-indigo-950/20 leading-relaxed text-[11px]">
                      <span className="text-pink-400 font-bold shrink-0">➜</span>
                      <span>{st}</span>
                    </div>
                  ))}
                </div>

              </div>
            </div>

            {/* Live algebraic directories index filter search */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
              
              {/* Search bar */}
              <div className="md:col-span-6 relative">
                <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  value={algebraSearch}
                  onChange={(e) => setAlgebraSearch(e.target.value)}
                  placeholder="Search algebra identities (e.g. binomial, product, AP)..."
                  className="w-full bg-[#020617] border border-slate-800 focus:border-indigo-500/80 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-200 outline-none font-medium focus:ring-1 focus:ring-indigo-500/20 text-white"
                />
              </div>

              {/* Horizontal scroll select category filter */}
              <div className="md:col-span-6 flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1">
                <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest font-black shrink-0">Filter:</span>
                {algebraCategories.map((name) => (
                  <button
                    key={name}
                    onClick={() => setActiveAlgebraCategory(name)}
                    className={`text-[10px] font-bold px-2.5 py-1.5 rounded-lg border transition-all whitespace-nowrap cursor-pointer ${
                      activeAlgebraCategory === name
                        ? 'bg-pink-500/10 border-pink-500/40 text-pink-300 font-extrabold'
                        : 'bg-slate-900/40 border-slate-800 text-slate-400 hover:text-slate-250'
                    }`}
                  >
                    {name.split(' ')[0]}
                  </button>
                ))}
              </div>

            </div>

            {/* Output cards grid */}
            <div className="space-y-5">
              {filteredAlgebraFormulas.length === 0 ? (
                <div className="text-center py-10 bg-[#020617]/50 border border-slate-850 rounded-2xl font-mono text-xs text-slate-450">
                  No algebraic formula identities match "{algebraSearch}" in current constraints.
                </div>
              ) : (
                filteredAlgebraFormulas.map((cat) => (
                  <div key={cat.categoryName} className="space-y-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-pink-500/50" />
                      <h4 className="text-xs font-black font-sans text-slate-200 tracking-wide uppercase">
                        {cat.categoryName}
                      </h4>
                    </div>
                    <p className="text-[10.5px] text-slate-400 font-mono leading-relaxed pl-4 pb-1">
                      {cat.description}
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {cat.items.map((item) => (
                        <div
                          key={item.id}
                          className="bg-[#020617]/60 border border-slate-800/80 hover:border-slate-700/80 rounded-xl p-4.5 space-y-3 transition-all relative overflow-hidden group/card"
                        >
                          {/* Top row copy key */}
                          <div className="flex justify-between items-start">
                            <span className="text-[11px] font-bold text-indigo-300 font-sans tracking-tight">
                              {item.name}
                            </span>
                            <button
                              onClick={() => handleCopyText(item.formula, item.id)}
                              className="p-1 rounded bg-slate-900 border border-slate-800 hover:text-white text-slate-400 transition-colors cursor-pointer"
                              title="Copy algebraic LaTeX notation"
                            >
                              {copiedId === item.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                            </button>
                          </div>

                          {/* Beautiful math display and expansion keys */}
                          <div className="bg-[#020617] p-3 rounded-lg border border-slate-900 flex flex-col items-center justify-center text-center">
                            <span className="text-sm font-black font-serif text-pink-300 tracking-wide">
                              {formatFormulaToHuman(item.formula)}
                            </span>
                            <span className="text-[8.5px] font-mono text-slate-500 mt-1 block">
                              Latex: <code className="text-indigo-400/40 select-all">{item.formula}</code>
                            </span>
                          </div>

                          {/* Example */}
                          <div className="bg-slate-900/40 p-2.5 rounded-lg border border-slate-850 leading-relaxed font-mono text-[10.5px]">
                            <span className="text-[8px] font-mono text-pink-400 uppercase tracking-widest font-black block mb-1">Applying steps:</span>
                            <p className="text-slate-400 font-medium">{item.example}</p>
                          </div>

                        </div>
                      ))}
                    </div>

                  </div>
                ))
              )}
            </div>

          </div>
        )}

        {/* ----------------------------------------------------
            TAB 3: TRIGONOMETRIC IDENTITIES & UNIT CIRCLE EXPLORER
            ---------------------------------------------------- */}
        {activeTab === 'trigonometry' && (
          <div className="space-y-6">
            
            {/* Live Interactive Unit Circle SVG Slider widget */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              
              {/* LHS SVG canvas representation */}
              <div className="lg:col-span-5 bg-[#020617]/80 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between items-center relative overflow-hidden min-h-[290px]">
                <div className="absolute top-0 right-0 bg-[#0F172A] border-l border-b border-indigo-900/40 rounded-bl-xl px-2.5 py-1 text-[8px] font-mono text-indigo-400 tracking-wider font-bold">
                  LIVE UNIT CIRCLE
                </div>
                
                <div className="w-full text-left">
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Interactive Projection</span>
                  <span className="text-xs font-extrabold text-slate-300 font-sans tracking-tight block">
                    θ = {trigAngle}° ({unitCircleValues.rad} rad)
                  </span>
                </div>

                {/* Core animated trig circle vector */}
                <div className="w-full flex items-center justify-center py-2 relative">
                  <svg viewBox="0 0 100 100" className="w-[190px] h-[190px]">
                    {/* Circle perimeter */}
                    <circle cx="50" cy="50" r="32" className="fill-indigo-500/5 stroke-slate-500 stroke-[1.5]" />
                    
                    {/* XY axes */}
                    <line x1="8" y1="50" x2="92" y2="50" className="stroke-slate-700/60 stroke-[0.8] stroke-dashed" />
                    <line x1="50" y1="8" x2="50" y2="92" className="stroke-slate-700/60 stroke-[0.8] stroke-dashed" />

                    {/* Cosine horizontal line segment (X direction) */}
                    <line x1="50" y1="50" x2={unitCircleValues.x} y2="50" className="stroke-teal-400 stroke-[2]" />
                    
                    {/* Sine vertical line segment (Y direction) */}
                    <line x1={unitCircleValues.x} y1="50" x2={unitCircleValues.x} y2={unitCircleValues.y} className="stroke-pink-400 stroke-[2]" />

                    {/* Radius hypotenuse sweep line */}
                    <line x1="50" y1="50" x2={unitCircleValues.x} y2={unitCircleValues.y} className="stroke-indigo-400 stroke-[1.5]" />

                    {/* Angle arc representation */}
                    <path
                      d={`M 58 50 A 8 8 0 0 ${trigAngle > 180 ? 0 : 0} ${50 + 8 * Math.cos((trigAngle * Math.PI) / 180)} ${50 - 8 * Math.sin((trigAngle * Math.PI) / 180)}`}
                      fill="none"
                      className="stroke-amber-400 stroke-[1]"
                    />

                    {/* Target coordination point dot */}
                    <circle cx={unitCircleValues.x} cy={unitCircleValues.y} r="2.5" className="fill-slate-100 ring-2 ring-indigo-500 animate-pulse" />
                    
                    {/* Coords label */}
                    <text x="52" y="94" className="text-[5.5px] font-mono fill-slate-500">Center (0,0)</text>
                    <text x={unitCircleValues.x + 3} y={unitCircleValues.y - 3} className="text-[6.5px] font-mono fill-amber-300 font-extrabold pb-1">
                      ({unitCircleValues.cos}, {unitCircleValues.sin})
                    </text>
                  </svg>
                </div>

                {/* Range Slider handle control */}
                <div className="w-full space-y-1.5">
                  <div className="flex justify-between items-center text-[10px] font-mono text-slate-400">
                    <span className="font-bold">Angle (θ) Selection:</span>
                    <span className="text-indigo-400 font-black">{trigAngle}° / 360°</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="360"
                    value={trigAngle}
                    onChange={(e) => setTrigAngle(parseInt(e.target.value))}
                    className="w-full accent-indigo-500 h-1 rounded bg-slate-900 cursor-pointer outline-none"
                  />
                  <div className="flex justify-between text-[8px] font-mono text-slate-600 uppercase font-black">
                    <span>0°</span>
                    <span>90°</span>
                    <span>180°</span>
                    <span>270°</span>
                    <span>360°</span>
                  </div>
                </div>

              </div>

              {/* RHS Calculations matrix */}
              <div className="lg:col-span-7 bg-[#020617]/50 border border-slate-800 p-5 rounded-2xl flex flex-col justify-between gap-4">
                <div>
                  <span className="text-[9px] font-mono text-slate-400 uppercase tracking-widest font-black block mb-2">Unit circle evaluation index</span>
                  <p className="text-xs text-slate-350 font-mono leading-relaxed pb-3">
                    Calculated standard values mapping the exact Cartesian coordinate vectors to trigonometric functions:
                  </p>
                  
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    
                    <div className="bg-[#020617] border border-slate-900 p-3 rounded-xl flex items-center justify-between">
                      <div className="font-mono">
                        <span className="text-[8px] font-black uppercase text-pink-400 block">Sine (Y-Axis)</span>
                        <span className="text-[10px] text-slate-450 block text-[9.5px]">sin(θ)</span>
                      </div>
                      <span className="text-sm font-mono font-black text-white">{unitCircleValues.sin}</span>
                    </div>

                    <div className="bg-[#020617] border border-slate-900 p-3 rounded-xl flex items-center justify-between">
                      <div className="font-mono">
                        <span className="text-[8px] font-black uppercase text-teal-400 block">Cosine (X-Axis)</span>
                        <span className="text-[10px] text-slate-450 block text-[9.5px]">cos(θ)</span>
                      </div>
                      <span className="text-sm font-mono font-black text-white">{unitCircleValues.cos}</span>
                    </div>

                    <div className="bg-[#020617] border border-slate-900 p-3 rounded-xl flex items-center justify-between">
                      <div className="font-mono">
                        <span className="text-[8px] font-black uppercase text-indigo-400 block">Tangent</span>
                        <span className="text-[10px] text-slate-450 block text-[9.5px]">sin(θ)/cos(θ)</span>
                      </div>
                      <span className="text-xs font-mono font-black text-indigo-300 truncate max-w-[70px]" title={unitCircleValues.tan}>
                        {unitCircleValues.tan}
                      </span>
                    </div>

                    <div className="bg-[#020617] border border-slate-900 p-3 rounded-xl flex items-center justify-between">
                      <div className="font-mono">
                        <span className="text-[8px] font-black uppercase text-slate-450 block">Cosecant</span>
                        <span className="text-[10px] text-slate-500 block text-[9.5px]">1/sin(θ)</span>
                      </div>
                      <span className="text-xs font-mono font-bold text-slate-300 truncate max-w-[70px]" title={unitCircleValues.csc}>
                        {unitCircleValues.csc}
                      </span>
                    </div>

                    <div className="bg-[#020617] border border-slate-900 p-3 rounded-xl flex items-center justify-between">
                      <div className="font-mono">
                        <span className="text-[8px] font-black uppercase text-slate-450 block">Secant</span>
                        <span className="text-[10px] text-slate-500 block text-[9.5px]">1/cos(θ)</span>
                      </div>
                      <span className="text-xs font-mono font-bold text-slate-300 truncate max-w-[70px]" title={unitCircleValues.sec}>
                        {unitCircleValues.sec}
                      </span>
                    </div>

                    <div className="bg-[#020617] border border-slate-900 p-3 rounded-xl flex items-center justify-between">
                      <div className="font-mono">
                        <span className="text-[8px] font-black uppercase text-slate-450 block">Cotangent</span>
                        <span className="text-[10px] text-slate-500 block text-[9.5px]">cos(θ)/sin(θ)</span>
                      </div>
                      <span className="text-xs font-mono font-bold text-slate-300 truncate max-w-[70px]" title={unitCircleValues.cot}>
                        {unitCircleValues.cot}
                      </span>
                    </div>

                  </div>
                </div>

                <div className="bg-amber-500/5 border border-amber-500/10 p-3 rounded-xl leading-relaxed text-[10px] text-amber-400 font-mono">
                  <span className="font-extrabold uppercase block mb-0.5">💡 Geometrical Interpretation:</span>
                  The coordinate point represents standard cosine and sine. The radius is exactly 1.0 forming right triangle with legs: base = {unitCircleValues.cos} and height = {unitCircleValues.sin} satisfying pythagoras theorem: {unitCircleValues.cos}² + {unitCircleValues.sin}² = 1.0000!
                </div>
              </div>

            </div>

            {/* Special Trig standard values reference matrix lookup */}
            <div className="space-y-2">
              <span className="text-xs font-mono font-bold text-slate-350 flex items-center gap-1.5 uppercase">
                <Sliders className="w-4 h-4 text-emerald-400" /> Special angles algebraic indices (Quick Lookup)
              </span>
              <div className="bg-[#020617]/50 border border-slate-800 rounded-xl overflow-x-auto pr-1">
                <table className="w-full border-collapse font-mono text-[10.5px] text-slate-300 min-w-[550px]">
                  <thead>
                    <tr className="bg-[#020617] border-b border-slate-800 text-[9px] text-slate-450 uppercase uppercase tracking-widest text-left font-black">
                      <th className="p-2.5">Angle °</th>
                      <th className="p-2.5">Radians</th>
                      <th className="p-2.5 text-pink-400">sin(θ)</th>
                      <th className="p-2.5 text-teal-400">cos(θ)</th>
                      <th className="p-2.5 text-indigo-400">tan(θ)</th>
                      <th className="p-2.5 text-slate-500">csc(θ)</th>
                      <th className="p-2.5 text-slate-500">sec(θ)</th>
                      <th className="p-2.5 text-slate-500">cot(θ)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {SPECIAL_TRIG_VALUES.map((row) => (
                      <tr
                        key={row.deg}
                        onClick={() => setTrigAngle(row.deg)}
                        className={`border-b border-slate-900 hover:bg-indigo-950/10 transition-colors cursor-pointer ${
                          trigAngle === row.deg ? 'bg-[#1a1b40]/50 font-bold text-slate-150' : ''
                        }`}
                      >
                        <td className="p-2.5 font-sans font-bold">{row.deg}°</td>
                        <td className="p-2.5 text-indigo-300/80">{row.rad}</td>
                        <td className="p-2.5 text-pink-400 font-bold">{row.sin}</td>
                        <td className="p-2.5 text-teal-400 font-bold">{row.cos}</td>
                        <td className="p-2.5 text-indigo-400">{row.tan}</td>
                        <td className="p-2.5 text-slate-450">{row.csc}</td>
                        <td className="p-2.5 text-slate-450">{row.sec}</td>
                        <td className="p-2.5 text-slate-450">{row.cot}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Identities Directory Search & Filter list */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center pt-2">
              <div className="md:col-span-6 relative">
                <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  value={trigSearch}
                  onChange={(e) => setTrigSearch(e.target.value)}
                  placeholder="Search identities (e.g. pythagorean, half-angle, cosines)..."
                  className="w-full bg-[#020617] border border-slate-800 focus:border-indigo-500/80 rounded-xl pl-10 pr-4 py-3 text-xs text-slate-200 outline-none font-medium focus:ring-1 focus:ring-indigo-500/20 text-white"
                />
              </div>

              <div className="md:col-span-6 flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1">
                <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest font-black shrink-0">Filter:</span>
                {trigCategories.map((name) => (
                  <button
                    key={name}
                    onClick={() => setActiveTrigCategory(name)}
                    className={`text-[10px] font-bold px-2.5 py-1.5 rounded-lg border transition-all whitespace-nowrap cursor-pointer ${
                      activeTrigCategory === name
                        ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300 font-extrabold'
                        : 'bg-slate-900/40 border-slate-800 text-slate-400 hover:text-slate-250'
                    }`}
                  >
                    {name.split(' ')[0]}
                  </button>
                ))}
              </div>
            </div>

            {/* Trigonometric list cards output */}
            <div className="space-y-5">
              {filteredTrigFormulas.length === 0 ? (
                <div className="text-center py-10 bg-[#020617]/50 border border-slate-850 rounded-2xl font-mono text-xs text-slate-450">
                  No trigonometric identities match "{trigSearch}" in current constraints.
                </div>
              ) : (
                filteredTrigFormulas.map((cat) => (
                  <div key={cat.categoryName} className="space-y-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/50" />
                      <h4 className="text-xs font-black font-sans text-slate-200 tracking-wide uppercase">
                        {cat.categoryName}
                      </h4>
                    </div>
                    <p className="text-[10.5px] text-slate-400 font-mono leading-relaxed pl-4 pb-1">
                      {cat.description}
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {cat.items.map((item) => (
                        <div
                          key={item.id}
                          className="bg-[#020617]/60 border border-slate-800/80 hover:border-slate-700/80 rounded-xl p-4.5 space-y-3 transition-all relative overflow-hidden group/card"
                        >
                          <div className="flex justify-between items-start">
                            <span className="text-[11px] font-bold text-emerald-300 font-sans tracking-tight">
                              {item.name}
                            </span>
                            <button
                              onClick={() => handleCopyText(item.formula, item.id)}
                              className="p-1 rounded bg-slate-900 border border-slate-800 hover:text-white text-slate-400 transition-colors cursor-pointer"
                              title="Copy trigonometric LaTeX notation"
                            >
                              {copiedId === item.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                            </button>
                          </div>

                          <div className="bg-[#020617] p-3 rounded-lg border border-slate-900 flex flex-col items-center justify-center text-center">
                            <span className="text-sm font-black font-serif text-teal-300 tracking-wide leading-relaxed">
                              {formatFormulaToHuman(item.formula)}
                            </span>
                            <span className="text-[8.5px] font-mono text-slate-500 mt-1 block">
                              Latex: <code className="text-indigo-400/40 select-all">{item.formula}</code>
                            </span>
                          </div>

                          <div className="bg-slate-900/40 p-2.5 rounded-lg border border-slate-850 leading-relaxed font-mono text-[10.5px]">
                            <span className="text-[8px] font-mono text-emerald-400 uppercase tracking-widest font-black block mb-1">Applying steps:</span>
                            <p className="text-slate-400 font-medium">{item.example}</p>
                          </div>

                        </div>
                      ))}
                    </div>

                  </div>
                ))
              )}
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
