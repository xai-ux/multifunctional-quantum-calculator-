import { HistoryItem } from '../types';
import { Trash2, Copy, History, ArrowLeftRight, Check } from 'lucide-react';
import { useState, MouseEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface HistorySidebarProps {
  history: HistoryItem[];
  onSelect: (item: HistoryItem) => void;
  onClear: () => void;
}

export default function HistorySidebar({ history, onSelect, onClear }: HistorySidebarProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (e: MouseEvent, text: string, id: string) => {
    e.stopPropagation();

    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  return (
    <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-4 flex flex-col h-full shadow-2.5xl text-gray-200">
      <div className="flex items-center justify-between pb-3.5 mb-3 border-b border-slate-800">
        <h3 className="font-semibold text-sm text-slate-200 flex items-center gap-2 font-sans tracking-tight">
          <History className="w-4 h-4 text-[#6366F1]" />
          <span>Calculation History</span>
        </h3>
        {history.length > 0 && (
          <button
            onClick={onClear}
            className="flex items-center gap-1.5 text-xs text-rose-400 hover:text-rose-350 hover:bg-rose-500/10 px-2.5 py-1 rounded-lg transition-transform hover:scale-102"
            id="clear_history_btn"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear</span>
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto pr-1 space-y-2.5 max-h-[460px] scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
        <AnimatePresence initial={false}>
          {history.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-12 text-center text-slate-500 space-y-2"
            >
              <History className="w-8 h-8 opacity-30 stroke-[1.5]" />
              <p className="text-xs font-mono">No previous equations</p>
              <p className="text-[10px] text-slate-600 max-w-[200px]">Expressions parsed in standard calculation state appear here</p>
            </motion.div>
          ) : (
            history.map((item) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -10 }}
                whileHover={{ scale: 1.01 }}
                onClick={() => onSelect(item)}
                className="group relative bg-[#020617]/50 hover:bg-[#020617]/80 border border-slate-800 hover:border-slate-700 rounded-xl p-3 cursor-pointer text-left transition-all"
                id={`history_item_${item.id}`}
              >
                {/* Formulas top row */}
                <div className="text-xs font-mono text-slate-400 break-all pr-8 leading-snug">
                  {item.expression}
                </div>
                {/* Result value line */}
                <div className="mt-1.5 text-sm font-semibold font-mono text-slate-200 break-all flex items-center justify-between">
                  <span className="text-[#6366F1] font-normal mr-1.5 text-xs">=</span>
                  <span>{item.result}</span>
                </div>

                {/* Subtitle Timestamp */}
                <div className="mt-2 text-[9px] font-mono text-slate-600 flex justify-between items-center">
                  <span>{item.timestamp}</span>
                  <span className="text-[10px] text-[#6366F1] opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                    <ArrowLeftRight className="w-2.5 h-2.5" /> Restore
                  </span>
                </div>

                {/* Direct quick action: Copy */}
                <button
                  onClick={(e) => handleCopy(e, item.result, item.id)}
                  className="absolute right-2 top-2 p-1.5 text-slate-500 hover:text-slate-300 hover:bg-slate-900 rounded-md transition-all opacity-0 group-hover:opacity-100"
                  title="Copy result"
                  id={`copy_history_${item.id}`}
                >
                  {copiedId === item.id ? (
                    <Check className="w-3.5 h-3.5 text-green-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
