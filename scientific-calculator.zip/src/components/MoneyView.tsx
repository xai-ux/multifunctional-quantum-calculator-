import { useState, useMemo } from 'react';
import {
  TrendingUp,
  Coins,
  DollarSign,
  Calendar,
  Percent,
  PiggyBank,
  CreditCard,
  Layers,
  FileText,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  Sliders,
  HelpCircle,
  ArrowDownRight,
} from 'lucide-react';

type MoneySubMode = 'emi' | 'sip' | 'swp' | 'roi';

interface AmortizationYear {
  year: number;
  openingBalance: number;
  payment: number;
  principal: number;
  interest: number;
  closingBalance: number;
  totalWithdrawn?: number;
  accumulatedWithdrawn?: number;
}

export default function MoneyView() {
  const [subMode, setSubMode] = useState<MoneySubMode>('emi');
  const [showSchedule, setShowSchedule] = useState<boolean>(true);
  const [currencySymbol, setCurrencySymbol] = useState<string>('$');

  // ----------------------------------------------------
  // EMI STATE
  // ----------------------------------------------------
  const [emiPrincipal, setEmiPrincipal] = useState<number>(50000);
  const [emiRate, setEmiRate] = useState<number>(8.5);
  const [emiTenure, setEmiTenure] = useState<number>(15); // years

  // ----------------------------------------------------
  // SIP STATE
  // ----------------------------------------------------
  const [sipMonthly, setSipMonthly] = useState<number>(500);
  const [sipRate, setSipRate] = useState<number>(12);
  const [sipTenure, setSipTenure] = useState<number>(10); // years

  // ----------------------------------------------------
  // SWP STATE
  // ----------------------------------------------------
  const [swpInvestment, setSwpInvestment] = useState<number>(100000);
  const [swpWithdrawal, setSwpWithdrawal] = useState<number>(800);
  const [swpRate, setSwpRate] = useState<number>(8);
  const [swpTenure, setSwpTenure] = useState<number>(15); // years

  // ----------------------------------------------------
  // ROI STATE
  // ----------------------------------------------------
  const [roiType, setRoiType] = useState<'lumpsum' | 'sip'>('lumpsum');
  const [roiAmount, setRoiAmount] = useState<number>(20000);
  const [roiRate, setRoiRate] = useState<number>(11.5);
  const [roiTenure, setRoiTenure] = useState<number>(5); // years

  // ----------------------------------------------------
  // 1. EMI CALCULATIVE ENGINE
  // ----------------------------------------------------
  const emiResult = useMemo(() => {
    const P = emiPrincipal;
    const annualR = emiRate;
    const Y = emiTenure;

    const r = annualR / 12 / 100;
    const n = Y * 12;

    let emiVal = 0;
    if (annualR === 0) {
      emiVal = P / n;
    } else {
      emiVal = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    }

    const totalPayment = emiVal * n;
    const totalInterest = totalPayment - P;

    // Calculate annual amortization schedule
    let currentBalance = P;
    const schedule: AmortizationYear[] = [];

    for (let year = 1; year <= Y; year++) {
      const opening = currentBalance;
      let yrPrincipal = 0;
      let yrInterest = 0;

      for (let month = 1; month <= 12; month++) {
        const intr = currentBalance * r;
        const princ = emiVal - intr;
        yrInterest += intr;
        yrPrincipal += princ;
        currentBalance -= princ;
        if (currentBalance < 0) currentBalance = 0;
      }

      schedule.push({
        year,
        openingBalance: opening,
        payment: emiVal * 12,
        principal: yrPrincipal,
        interest: yrInterest,
        closingBalance: currentBalance,
      });
    }

    return {
      monthlyEmi: emiVal,
      totalPayment,
      totalInterest,
      principalPercent: (P / totalPayment) * 100,
      interestPercent: (totalInterest / totalPayment) * 100,
      schedule,
    };
  }, [emiPrincipal, emiRate, emiTenure]);

  // ----------------------------------------------------
  // 2. SIP CALCULATIVE ENGINE
  // ----------------------------------------------------
  const sipResult = useMemo(() => {
    const P = sipMonthly;
    const annualR = sipRate;
    const Y = sipTenure;

    const i = annualR / 12 / 100;
    const n = Y * 12;

    let totalValue = 0;
    if (annualR === 0) {
      totalValue = P * n;
    } else {
      totalValue = P * ((Math.pow(1 + i, n) - 1) / i) * (1 + i);
    }

    const totalInvested = P * n;
    const estReturns = totalValue - totalInvested;

    // Year-by-year schedule
    const schedule: AmortizationYear[] = [];
    for (let year = 1; year <= Y; year++) {
      const yrMonths = year * 12;
      const yrInvested = P * yrMonths;
      let yrValue = 0;
      if (annualR === 0) {
        yrValue = P * yrMonths;
      } else {
        yrValue = P * ((Math.pow(1 + i, yrMonths) - 1) / i) * (1 + i);
      }

      const prevYearValue = year === 1 ? 0 : schedule[year - 2].closingBalance;
      const yrPayments = P * 12;

      schedule.push({
        year,
        openingBalance: prevYearValue,
        payment: yrPayments,
        principal: yrPayments, // in investment, principal added this year is the payment
        interest: yrValue - prevYearValue - yrPayments, // growth / returns added this year
        closingBalance: yrValue,
      });
    }

    return {
      totalInvested,
      estReturns,
      totalValue,
      investedPercent: (totalInvested / totalValue) * 100,
      returnsPercent: (estReturns / totalValue) * 100,
      schedule,
    };
  }, [sipMonthly, sipRate, sipTenure]);

  // ----------------------------------------------------
  // 3. SWP CALCULATIVE ENGINE
  // ----------------------------------------------------
  const swpResult = useMemo(() => {
    const lumpsum = swpInvestment;
    const monthlyW = swpWithdrawal;
    const annualR = swpRate;
    const Y = swpTenure;

    const i = annualR / 12 / 100;
    const n = Y * 12;

    let currentBalance = lumpsum;
    let totalWithdrawn = 0;
    let totalInterestEarned = 0;
    const schedule: AmortizationYear[] = [];

    // Let's model month-by-month for Y years
    for (let year = 1; year <= Y; year++) {
      const yearOpening = currentBalance;
      let yrWithdrawn = 0;
      let yrInterest = 0;

      for (let month = 1; month <= 12; month++) {
        if (currentBalance <= 0) {
          currentBalance = 0;
          continue;
        }

        // Apply interest first (Standard SWP calculations)
        const interestEarned = currentBalance * i;
        yrInterest += interestEarned;
        totalInterestEarned += interestEarned;

        // Add interest to balance
        currentBalance += interestEarned;

        // Perform withdrawal
        if (currentBalance >= monthlyW) {
          currentBalance -= monthlyW;
          yrWithdrawn += monthlyW;
          totalWithdrawn += monthlyW;
        } else {
          yrWithdrawn += currentBalance;
          totalWithdrawn += currentBalance;
          currentBalance = 0;
        }
      }

      schedule.push({
        year,
        openingBalance: yearOpening,
        payment: yrWithdrawn, // Amount systematically removed from initial capital
        principal: Math.max(0, yearOpening - currentBalance + yrInterest), // Capital degradation
        interest: yrInterest, // Interest earned this year
        closingBalance: currentBalance,
        totalWithdrawn: yrWithdrawn,
        accumulatedWithdrawn: totalWithdrawn,
      });
    }

    return {
      totalInvested: lumpsum,
      totalWithdrawn,
      closingBalance: currentBalance,
      totalInterestEarned,
      withdrawnPercent: (totalWithdrawn / (lumpsum + totalInterestEarned)) * 100,
      balancePercent: (currentBalance / (lumpsum + totalInterestEarned)) * 100,
      schedule,
    };
  }, [swpInvestment, swpWithdrawal, swpRate, swpTenure]);

  // ----------------------------------------------------
  // 4. MUTUAL FUND ROI CALCULATIVE ENGINE
  // ----------------------------------------------------
  const roiResult = useMemo(() => {
    const rate = roiRate;
    const tenure = roiTenure;
    const sumAmount = roiAmount;

    let totalValue = 0;
    let investedAmount = 0;

    if (roiType === 'lumpsum') {
      investedAmount = sumAmount;
      totalValue = sumAmount * Math.pow(1 + rate / 100, tenure);
    } else {
      // SIP ROI Type
      const P = sumAmount; // Monthly Investment
      const i = rate / 12 / 100;
      const n = tenure * 12;
      investedAmount = P * n;
      if (rate === 0) {
        totalValue = investedAmount;
      } else {
        totalValue = P * ((Math.pow(1 + i, n) - 1) / i) * (1 + i);
      }
    }

    const estGain = totalValue - investedAmount;
    const absoluteReturn = investedAmount > 0 ? (estGain / investedAmount) * 100 : 0;
    
    // CAGR is the interest rate itself because that's the compound growth parameter
    const CAGR = rate;

    // Year-by-year schedule
    const schedule: AmortizationYear[] = [];
    for (let year = 1; year <= tenure; year++) {
      let yrInvested = 0;
      let yrValue = 0;

      if (roiType === 'lumpsum') {
        yrInvested = sumAmount;
        yrValue = sumAmount * Math.pow(1 + rate / 100, year);
      } else {
        const P = sumAmount;
        const i = rate / 12 / 100;
        const yrMonths = year * 12;
        yrInvested = P * yrMonths;
        if (rate === 0) {
          yrValue = yrInvested;
        } else {
          yrValue = P * ((Math.pow(1 + i, yrMonths) - 1) / i) * (1 + i);
        }
      }

      const prevYearValue = year === 1 ? 0 : schedule[year - 2].closingBalance;
      const yearAddition = roiType === 'lumpsum' ? (year === 1 ? sumAmount : 0) : sumAmount * 12;

      schedule.push({
        year,
        openingBalance: prevYearValue,
        payment: yearAddition,
        principal: yearAddition,
        interest: yrValue - prevYearValue - yearAddition,
        closingBalance: yrValue,
      });
    }

    return {
      investedAmount,
      estGain,
      totalValue,
      absoluteReturn,
      CAGR,
      investedPercent: (investedAmount / totalValue) * 100,
      returnsPercent: (estGain / totalValue) * 100,
      schedule,
    };
  }, [roiType, roiAmount, roiRate, roiTenure]);

  // Helper component for styled SVG Donut Chart
  const renderDonutChart = (perc1: number, perc2: number, color1: string, color2: string, label1: string, label2: string, value1Str: string, value2Str: string) => {
    // Circumference of radius 159 is ~1000 for easy dasharray
    const radius = 50;
    const strokeWidth = 14;
    const circum = 2 * Math.PI * radius; // 314.159
    const offset1 = circum;
    
    // Values cap
    const p1 = isNaN(perc1) ? 50 : Math.max(0, Math.min(100, perc1));
    const p2 = 100 - p1;

    const strokeDash1 = (p1 / 100) * circum;
    const strokeDash2 = circum - strokeDash1;

    return (
      <div className="flex flex-col items-center justify-center p-3 bg-slate-900/30 border border-slate-800/40 rounded-2xl">
        <div className="relative w-40 h-40">
          <svg viewBox="0 0 120 120" className="w-full h-full transform -rotate-90">
            {/* Background tracking track circle */}
            <circle
              cx="60"
              cy="60"
              r={radius}
              className="fill-none stroke-slate-800/50"
              strokeWidth={strokeWidth}
            />
            {/* Sector 1: Bottom Layer/Representing Principal */}
            <circle
              cx="60"
              cy="60"
              r={radius}
              className="fill-none transition-all duration-700 ease-out"
              strokeWidth={strokeWidth}
              stroke={color1}
              strokeDasharray={`${strokeDash1} ${circum}`}
              strokeDashoffset={0}
              strokeLinecap="round"
            />
            {/* Sector 2: Top Layer/Representing Interest Accumulated */}
            <circle
              cx="60"
              cy="60"
              r={radius}
              className="fill-none transition-all duration-700 ease-out"
              strokeWidth={strokeWidth}
              stroke={color2}
              strokeDasharray={`${strokeDash2} ${circum}`}
              strokeDashoffset={-strokeDash1}
              strokeLinecap="round"
            />
          </svg>
          {/* Centered overall breakdown tag info */}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center font-mono select-none">
            <span className="text-[10px] text-slate-400 capitalize">Ratio Distribution</span>
            <span className="text-sm font-bold text-slate-100">{p1.toFixed(1)}%</span>
            <span className="text-[8px] text-slate-500 font-black tracking-wider uppercase">to {p2.toFixed(1)}%</span>
          </div>
        </div>

        {/* Custom Legend details with clean values */}
        <div className="w-full mt-4 grid grid-cols-2 gap-4 text-left border-t border-slate-800/60 pt-3 text-[11px] font-mono leading-tight">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ backgroundColor: color1 }} />
              <span className="text-slate-400 whitespace-nowrap">{label1}</span>
            </div>
            <p className="font-sans font-bold text-slate-200 pl-4">{value1Str}</p>
            <p className="text-[9px] text-slate-500 pl-4">({p1.toFixed(1)}%)</p>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ backgroundColor: color2 }} />
              <span className="text-slate-400 whitespace-nowrap">{label2}</span>
            </div>
            <p className="font-sans font-bold text-slate-250 pl-4">{value2Str}</p>
            <p className="text-[9px] text-slate-500 pl-4">({p2.toFixed(1)}%)</p>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6" id="money_section_wrapper">
      {/* Upper Mode Pill Segment Select bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800/40 pb-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 font-sans tracking-tight flex items-center gap-2">
            <Coins className="w-4.5 h-4.5 text-[#6366F1]" />
            <span>Money Section & Banking Calculators</span>
          </h2>
          <p className="text-[11px] text-slate-400 font-mono mt-0.5 leading-relaxed">
            Highly accurate algorithms for interest amortization, monthly periodic assets tracking, and wealth projections.
          </p>
        </div>

        {/* Banking Mode Pill selectors */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Optional Currency Unit Selector */}
          <div className="flex items-center gap-1.5 bg-[#030712] border border-slate-800 px-3 py-1.5 rounded-xl text-[10px] font-mono shadow-sm">
            <span className="text-slate-404 font-semibold">Currency:</span>
            <select
              value={currencySymbol}
              onChange={(e) => setCurrencySymbol(e.target.value)}
              className="bg-transparent border-none text-indigo-300 outline-none cursor-pointer font-bold focus:ring-0 text-xs py-0 px-1 font-sans"
              id="currency_symbol_selector"
            >
              <option value="$" className="bg-[#0c1024] text-slate-200">USD ($)</option>
              <option value="₹" className="bg-[#0c1024] text-slate-200">INR (₹)</option>
              <option value="€" className="bg-[#0c1024] text-slate-200">EUR (€)</option>
              <option value="£" className="bg-[#0c1024] text-slate-200">GBP (£)</option>
              <option value="¥" className="bg-[#0c1024] text-slate-200">JPY (¥)</option>
              <option value="₪" className="bg-[#0c1024] text-slate-200">ILS (₪)</option>
              <option value="₩" className="bg-[#0c1024] text-slate-200 font-sans">KRW (₩)</option>
              <option value="" className="bg-[#0c1024] text-slate-200 font-sans">None (Raw)</option>
            </select>
          </div>

          <div className="flex bg-[#030712] border border-slate-800 p-1 rounded-xl gap-1">
            {[
              { id: 'emi', label: 'EMI Calculator', icon: CreditCard },
              { id: 'sip', label: 'SIP Future Value', icon: PiggyBank },
              { id: 'swp', label: 'SWP Remaining Capitals', icon: ArrowDownRight },
              { id: 'roi', label: 'Mutual Fund ROI', icon: TrendingUp },
            ].map((item) => {
              const Icon = item.icon;
              const isActive = subMode === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setSubMode(item.id as MoneySubMode)}
                  className={`flex items-center gap-1.5 text-[10px] font-bold px-3 py-2 rounded-lg transition-all cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-[#1e293b] text-slate-100 shadow border border-slate-700/80 shadow-[#6366F1]/10'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-[#0f172a]/30'
                  }`}
                  id={`money_submode_select_${item.id}`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-indigo-400' : 'text-slate-500'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Primary Calculator Layout with inputs & dynamic SVG side panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Columns - Parameters Sliders Fields */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-[#090d1f]/40 border border-slate-800/60 rounded-2xl p-5 space-y-5">
            <div className="flex items-center gap-2 border-b border-slate-800/40 pb-3">
              <Sliders className="w-4 h-4 text-slate-450 animate-pulse" />
              <h3 className="text-xs font-black font-sans uppercase tracking-wider text-slate-205">
                {subMode === 'emi' && 'Mortgage EMI Inputs'}
                {subMode === 'sip' && 'SIP Investments Config'}
                {subMode === 'swp' && 'SWP Withdrawal Parameters'}
                {subMode === 'roi' && 'Mutual Fund ROI Parameters'}
              </h3>
            </div>

            {/* Render dynamic Input controls based on selected subMode */}
            {subMode === 'emi' && (
              <div className="space-y-4">
                {/* 1. Principal Loan Amount */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-slate-400">Total Loan Amount (P)</span>
                    <span className="text-indigo-300 font-bold flex items-center">
                      {currencySymbol && <span className="font-sans text-xs text-indigo-400 mr-0.5">{currencySymbol}</span>}
                      {emiPrincipal.toLocaleString('en-US')}
                    </span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <input
                      type="range"
                      min="5000"
                      max="1000000"
                      step="5000"
                      value={emiPrincipal}
                      onChange={(e) => setEmiPrincipal(Number(e.target.value))}
                      className="flex-1 accent-indigo-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <input
                      type="number"
                      min="1000"
                      value={emiPrincipal}
                      onChange={(e) => setEmiPrincipal(Math.max(0, Number(e.target.value)))}
                      className="w-24 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-100 text-right focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                {/* 2. Annual Interest Rate */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-slate-405">Annual Interest Rate (R)</span>
                    <span className="text-indigo-300 font-bold flex items-center">
                      {emiRate} <Percent className="w-3 h-3 text-indigo-400 ml-0.5" />
                    </span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <input
                      type="range"
                      min="1"
                      max="30"
                      step="0.05"
                      value={emiRate}
                      onChange={(e) => setEmiRate(Number(e.target.value))}
                      className="flex-1 accent-indigo-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <input
                      type="number"
                      step="0.1"
                      min="0.1"
                      value={emiRate}
                      onChange={(e) => setEmiRate(Math.max(0.1, Number(e.target.value)))}
                      className="w-24 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-100 text-right focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                {/* 3. Loan Tenure */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-slate-400">Loan Tenure</span>
                    <span className="text-indigo-300 font-bold flex items-center">
                      {emiTenure} Years <Calendar className="w-3 h-3 text-indigo-400 ml-1.5" />
                    </span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <input
                      type="range"
                      min="1"
                      max="40"
                      step="1"
                      value={emiTenure}
                      onChange={(e) => setEmiTenure(Number(e.target.value))}
                      className="flex-1 accent-indigo-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <input
                      type="number"
                      min="1"
                      value={emiTenure}
                      onChange={(e) => setEmiTenure(Math.max(1, Number(e.target.value)))}
                      className="w-24 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-100 text-right focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>
              </div>
            )}

            {subMode === 'sip' && (
              <div className="space-y-4">
                {/* 1. Monthly Savings (P) */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-slate-400">Monthly Investment Amount</span>
                    <span className="text-emerald-300 font-bold flex items-center">
                      {currencySymbol && <span className="font-sans text-xs text-emerald-400 mr-0.5">{currencySymbol}</span>}
                      {sipMonthly.toLocaleString('en-US')}
                    </span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <input
                      type="range"
                      min="10"
                      max="20000"
                      step="50"
                      value={sipMonthly}
                      onChange={(e) => setSipMonthly(Number(e.target.value))}
                      className="flex-1 accent-emerald-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <input
                      type="number"
                      min="1"
                      value={sipMonthly}
                      onChange={(e) => setSipMonthly(Math.max(0, Number(e.target.value)))}
                      className="w-24 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-100 text-right focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                {/* 2. Expected Returns Rate (R) */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-slate-400">Expected Annual Return Rate</span>
                    <span className="text-emerald-300 font-bold flex items-center">
                      {sipRate} <Percent className="w-3 h-3 text-emerald-400 ml-0.5" />
                    </span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <input
                      type="range"
                      min="1"
                      max="40"
                      step="0.1"
                      value={sipRate}
                      onChange={(e) => setSipRate(Number(e.target.value))}
                      className="flex-1 accent-emerald-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <input
                      type="number"
                      step="0.1"
                      min="0.1"
                      value={sipRate}
                      onChange={(e) => setSipRate(Math.max(0.1, Number(e.target.value)))}
                      className="w-24 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-100 text-right focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                {/* 3. Expected Investment Duration */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-slate-400">Investment Period</span>
                    <span className="text-emerald-300 font-bold flex items-center">
                      {sipTenure} Years <Calendar className="w-3 h-3 text-emerald-400 ml-1.5" />
                    </span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <input
                      type="range"
                      min="1"
                      max="50"
                      step="1"
                      value={sipTenure}
                      onChange={(e) => setSipTenure(Number(e.target.value))}
                      className="flex-1 accent-emerald-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <input
                      type="number"
                      min="1"
                      value={sipTenure}
                      onChange={(e) => setSipTenure(Math.max(1, Number(e.target.value)))}
                      className="w-24 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-100 text-right focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              </div>
            )}

            {subMode === 'swp' && (
              <div className="space-y-4">
                {/* 1. Capital deposited */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-slate-400">Initial General Capital (Lumpsum)</span>
                    <span className="text-rose-300 font-bold flex items-center">
                      {currencySymbol && <span className="font-sans text-xs text-rose-455 mr-0.5">{currencySymbol}</span>}
                      {swpInvestment.toLocaleString('en-US')}
                    </span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <input
                      type="range"
                      min="5000"
                      max="1500000"
                      step="5000"
                      value={swpInvestment}
                      onChange={(e) => setSwpInvestment(Number(e.target.value))}
                      className="flex-1 accent-rose-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <input
                      type="number"
                      min="1"
                      value={swpInvestment}
                      onChange={(e) => setSwpInvestment(Math.max(0, Number(e.target.value)))}
                      className="w-24 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-100 text-right focus:outline-none focus:border-rose-500"
                    />
                  </div>
                </div>

                {/* 2. Monthly Systematic Withdrawal */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-slate-400">Desired Monthly Withdrawal</span>
                    <span className="text-rose-300 font-bold flex items-center">
                      {currencySymbol && <span className="font-sans text-xs text-rose-455 mr-0.5">{currencySymbol}</span>}
                      {swpWithdrawal.toLocaleString('en-US')}
                    </span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <input
                      type="range"
                      min="50"
                      max="15000"
                      step="50"
                      value={swpWithdrawal}
                      onChange={(e) => setSwpWithdrawal(Number(e.target.value))}
                      className="flex-1 accent-rose-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <input
                      type="number"
                      min="1"
                      value={swpWithdrawal}
                      onChange={(e) => setSwpWithdrawal(Math.max(0, Number(e.target.value)))}
                      className="w-24 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-100 text-right focus:outline-none focus:border-rose-500"
                    />
                  </div>
                </div>

                {/* 3. Interest rate expected */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-slate-400">Expected Interest Return (p.a.)</span>
                    <span className="text-rose-300 font-bold flex items-center">
                      {swpRate} <Percent className="w-3 h-3 text-rose-400 ml-0.5" />
                    </span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <input
                      type="range"
                      min="1"
                      max="30"
                      step="0.1"
                      value={swpRate}
                      onChange={(e) => setSwpRate(Number(e.target.value))}
                      className="flex-1 accent-rose-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <input
                      type="number"
                      step="0.1"
                      min="0.1"
                      value={swpRate}
                      onChange={(e) => setSwpRate(Math.max(0.1, Number(e.target.value)))}
                      className="w-24 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-100 text-right focus:outline-none focus:border-rose-500"
                    />
                  </div>
                </div>

                {/* 4. Tenure years */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-slate-400">Withdrawal Period Duration</span>
                    <span className="text-rose-300 font-bold flex items-center">
                      {swpTenure} Years <Calendar className="w-3 h-3 text-rose-400 ml-1.5" />
                    </span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <input
                      type="range"
                      min="1"
                      max="30"
                      step="1"
                      value={swpTenure}
                      onChange={(e) => setSwpTenure(Number(e.target.value))}
                      className="flex-1 accent-rose-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <input
                      type="number"
                      min="1"
                      value={swpTenure}
                      onChange={(e) => setSwpTenure(Math.max(1, Number(e.target.value)))}
                      className="w-24 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-100 text-right focus:outline-none focus:border-rose-500"
                    />
                  </div>
                </div>
              </div>
            )}

            {subMode === 'roi' && (
              <div className="space-y-4">
                {/* Lumpsum vs SIP selector */}
                <div className="flex items-center gap-2 mb-2 p-1.5 bg-slate-900 border border-slate-850 rounded-xl">
                  <button
                    onClick={() => setRoiType('lumpsum')}
                    className={`flex-1 py-1.5 text-[10px] font-bold font-mono text-center rounded-lg cursor-pointer transition-all ${
                      roiType === 'lumpsum'
                        ? 'bg-slate-800 border border-slate-700 text-pink-300'
                        : 'text-slate-450 hover:text-slate-200'
                    }`}
                  >
                    Lumpsum Investment
                  </button>
                  <button
                    onClick={() => setRoiType('sip')}
                    className={`flex-1 py-1.5 text-[10px] font-bold font-mono text-center rounded-lg cursor-pointer transition-all ${
                      roiType === 'sip'
                        ? 'bg-slate-800 border border-slate-700 text-pink-300'
                        : 'text-slate-450 hover:text-slate-200'
                    }`}
                  >
                    Monthly SIP Plan
                  </button>
                </div>

                {/* 1. Value inputs */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-slate-450">
                      {roiType === 'lumpsum' ? 'Lumpsum Invested Capital' : 'Monthly Savings Allocation'}
                    </span>
                    <span className="text-pink-300 font-bold flex items-center">
                      {currencySymbol && <span className="font-sans text-xs text-pink-400 mr-0.5">{currencySymbol}</span>}
                      {roiAmount.toLocaleString('en-US')}
                    </span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <input
                      type="range"
                      min={roiType === 'lumpsum' ? 1000 : 50}
                      max={roiType === 'lumpsum' ? 500000 : 15000}
                      step={roiType === 'lumpsum' ? 1000 : 50}
                      value={roiAmount}
                      onChange={(e) => setRoiAmount(Number(e.target.value))}
                      className="flex-1 accent-pink-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <input
                      type="number"
                      min="1"
                      value={roiAmount}
                      onChange={(e) => setRoiAmount(Math.max(1, Number(e.target.value)))}
                      className="w-24 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-100 text-right focus:outline-none focus:border-pink-500"
                    />
                  </div>
                </div>

                {/* 2. ROI Yield Rate */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-slate-400">Annual Return (p.a.)</span>
                    <span className="text-pink-300 font-bold flex items-center">
                      {roiRate} <Percent className="w-3 h-3 text-pink-400 ml-0.5" />
                    </span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <input
                      type="range"
                      min="1"
                      max="40"
                      step="0.1"
                      value={roiRate}
                      onChange={(e) => setRoiRate(Number(e.target.value))}
                      className="flex-1 accent-pink-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <input
                      type="number"
                      step="0.1"
                      min="0.1"
                      value={roiRate}
                      onChange={(e) => setRoiRate(Math.max(0.1, Number(e.target.value)))}
                      className="w-24 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-100 text-right focus:outline-none focus:border-pink-500"
                    />
                  </div>
                </div>

                {/* 3. Tenure period */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-[11px]">
                    <span className="text-slate-400">Growth Tenure Period</span>
                    <span className="text-pink-300 font-bold flex items-center">
                      {roiTenure} Years <Calendar className="w-3 h-3 text-pink-400 ml-1.5" />
                    </span>
                  </div>
                  <div className="flex gap-4 items-center">
                    <input
                      type="range"
                      min="1"
                      max="40"
                      step="1"
                      value={roiTenure}
                      onChange={(e) => setRoiTenure(Number(e.target.value))}
                      className="flex-1 accent-pink-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <input
                      type="number"
                      min="1"
                      value={roiTenure}
                      onChange={(e) => setRoiTenure(Math.max(1, Number(e.target.value)))}
                      className="w-24 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-100 text-right focus:outline-none focus:border-pink-500"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Quick Informational Notice on exact formulas */}
          <div className="bg-[#020617]/40 border border-slate-800/60 rounded-xl p-4 text-[10px] font-mono text-slate-400 space-y-1.5 leading-relaxed">
            <h4 className="text-slate-200 font-sans font-medium flex items-center gap-1.5 text-xs mb-1">
              <HelpCircle className="w-3.5 h-3.5 text-slate-400" /> Clean Verified Formula Rules
            </h4>
            {subMode === 'emi' && (
              <p>
                • Uses the standard compound amortization formula: <strong>E = P · r · (1+r)ⁿ / ((1+r)ⁿ - 1)</strong>, where "r" is the monthly rate and "n" is the total payment months.
              </p>
            )}
            {subMode === 'sip' && (
              <p>
                • Uses the regular mutual fund systematic investment equation: <strong>M = P · [((1 + i)ⁿ - 1) / i] · (1 + i)</strong>, where "i" is the periodic monthly yield rate and "n" is the months count.
              </p>
            )}
            {subMode === 'swp' && (
              <p>
                • Applies the capital degradation rate: Each month <strong>B_new = B_old · (1 + i) - Withdrawal</strong>, compounding remaining balances iteratively until capital depletion.
              </p>
            )}
            {subMode === 'roi' && (
              <p>
                • Supports compound investments: Lumpsum yields <strong>FV = PV · (1 + R/100)ⁿ</strong>, compounded annually. Monthly option utilizes continuous compound growth.
              </p>
            )}
          </div>
        </div>

        {/* Right Columns - Output Projection Display Panel */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-5">
            <h3 className="text-xs font-black font-sans uppercase tracking-wider text-slate-200 border-b border-slate-800 pb-3">
              Calculation Breakdown
            </h3>

            {/* Calculations summaries with different themes */}
            {subMode === 'emi' && (
              <div className="space-y-4">
                <div className="p-4 bg-slate-950/80 border border-slate-850 rounded-xl text-center">
                  <span className="text-[10px] font-mono text-slate-450 uppercase tracking-widest font-bold block mb-1">Estimated Monthly EMI</span>
                  <div className="text-2xl font-bold font-sans text-indigo-300">
                    {currencySymbol}{emiResult.monthlyEmi.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 font-mono text-[11px]">
                  <div className="p-3 bg-slate-900/40 border border-slate-850 rounded-xl">
                    <span className="text-slate-500 block mb-1 text-[9px] uppercase font-bold tracking-wider">Principal Amount</span>
                    <span className="text-slate-200 text-sm font-sans font-bold">{currencySymbol}{emiPrincipal.toLocaleString('en-US')}</span>
                  </div>
                  <div className="p-3 bg-slate-900/40 border border-slate-850 rounded-xl">
                    <span className="text-slate-500 block mb-1 text-[9px] uppercase font-bold tracking-wider">Total Interest</span>
                    <span className="text-slate-205 text-sm font-sans font-bold">{currencySymbol}{emiResult.totalInterest.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
                  </div>
                </div>

                <div className="p-3.5 bg-indigo-500/5 border border-indigo-500/10 rounded-xl flex justify-between items-center font-mono text-[11px]">
                  <span className="text-indigo-400 font-bold">Total Cumulative Cost</span>
                  <span className="text-indigo-200 text-base font-sans font-semibold">{currencySymbol}{emiResult.totalPayment.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
                </div>

                {renderDonutChart(
                  emiResult.principalPercent,
                  emiResult.interestPercent,
                  'rgba(99, 102, 241, 0.9)', // indigo base
                  'rgba(236, 72, 153, 0.9)',  // pink accent
                  'Principal Loan',
                  'Total Interest Paid',
                  `${currencySymbol}${emiPrincipal.toLocaleString('en-US')}`,
                  `${currencySymbol}${emiResult.totalInterest.toLocaleString('en-US', { maximumFractionDigits: 0 })}`
                )}
              </div>
            )}

            {subMode === 'sip' && (
              <div className="space-y-4">
                <div className="p-4 bg-slate-950/80 border border-slate-850 rounded-xl text-center">
                  <span className="text-[10px] font-mono text-slate-450 uppercase tracking-widest font-bold block mb-1">Maturity Future Value</span>
                  <div className="text-2xl font-bold font-sans text-emerald-300">
                    {currencySymbol}{sipResult.totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 font-mono text-[11px]">
                  <div className="p-3 bg-slate-900/40 border border-slate-850 rounded-xl">
                    <span className="text-slate-500 block mb-1 text-[9px] uppercase font-bold tracking-wider">Total Invested</span>
                    <span className="text-slate-200 text-sm font-sans font-bold">{currencySymbol}{sipResult.totalInvested.toLocaleString('en-US')}</span>
                  </div>
                  <div className="p-3 bg-slate-900/40 border border-slate-850 rounded-xl">
                    <span className="text-slate-500 block mb-1 text-[9px] uppercase font-bold tracking-wider">Wealth Return Gains</span>
                    <span className="text-slate-205 text-sm font-sans font-bold">{currencySymbol}{sipResult.estReturns.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
                  </div>
                </div>

                {renderDonutChart(
                  sipResult.investedPercent,
                  sipResult.returnsPercent,
                  'rgba(16, 185, 129, 0.9)', // emerald base
                  'rgba(99, 102, 241, 0.9)',  // indigo accent
                  'Invested Principal',
                  'Return Value Gain',
                  `${currencySymbol}${sipResult.totalInvested.toLocaleString('en-US')}`,
                  `${currencySymbol}${sipResult.estReturns.toLocaleString('en-US', { maximumFractionDigits: 0 })}`
                )}
              </div>
            )}

            {subMode === 'swp' && (
              <div className="space-y-4">
                <div className="p-4 bg-slate-950/80 border border-slate-850 rounded-xl text-center">
                  <span className="text-[10px] font-mono text-slate-450 uppercase tracking-widest font-bold block mb-1">Capital Remaining</span>
                  <div className="text-2xl font-bold font-sans text-rose-300">
                    {currencySymbol}{swpResult.closingBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 font-mono text-[11px]">
                  <div className="p-3 bg-slate-900/40 border border-slate-850 rounded-xl">
                    <span className="text-slate-500 block mb-1 text-[9px] uppercase font-bold tracking-wider">Total Withdrawn Assets</span>
                    <span className="text-slate-200 text-sm font-sans font-bold">{currencySymbol}{swpResult.totalWithdrawn.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
                  </div>
                  <div className="p-3 bg-slate-900/40 border border-slate-850 rounded-xl">
                    <span className="text-slate-500 block mb-1 text-[9px] uppercase font-bold tracking-wider">Interest Earnings Added</span>
                    <span className="text-slate-205 text-sm font-sans font-bold">{currencySymbol}{swpResult.totalInterestEarned.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
                  </div>
                </div>

                {renderDonutChart(
                  swpResult.withdrawnPercent,
                  swpResult.balancePercent,
                  'rgba(239, 68, 68, 0.9)', // rose base
                  'rgba(16, 185, 129, 0.9)', // emerald accent
                  'Withdrawn Assets',
                  'Remaining Balance',
                  `${currencySymbol}${swpResult.totalWithdrawn.toLocaleString('en-US', { maximumFractionDigits: 0 })}`,
                  `${currencySymbol}${swpResult.closingBalance.toLocaleString('en-US', { maximumFractionDigits: 0 })}`
                )}
              </div>
            )}

            {subMode === 'roi' && (
              <div className="space-y-4">
                <div className="p-4 bg-slate-950/80 border border-slate-850 rounded-xl text-center">
                  <span className="text-[10px] font-mono text-slate-450 uppercase tracking-widest font-bold block mb-1">Maturity Yield Value</span>
                  <div className="text-2xl font-bold font-sans text-pink-300">
                    {currencySymbol}{roiResult.totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 font-mono text-[10px] text-center">
                  <div className="p-2.5 bg-slate-900/40 border border-slate-850 rounded-xl">
                    <span className="text-slate-500 block mb-1 uppercase font-bold tracking-wider">Invested Capital</span>
                    <span className="text-slate-200 text-xs font-sans font-bold">{currencySymbol}{roiResult.investedAmount.toLocaleString('en-US')}</span>
                  </div>
                  <div className="p-2.5 bg-slate-900/40 border border-slate-850 rounded-xl">
                    <span className="text-slate-500 block mb-1 uppercase font-bold tracking-wider">Calculated Absolute Return</span>
                    <span className="text-pink-300 text-xs font-sans font-bold">+{roiResult.absoluteReturn.toFixed(1)}%</span>
                  </div>
                  <div className="p-2.5 bg-slate-900/40 border border-slate-855 rounded-xl">
                    <span className="text-slate-500 block mb-1 uppercase font-bold tracking-wider">Compounded CAGR</span>
                    <span className="text-slate-200 text-xs font-sans font-bold">{roiResult.CAGR}%</span>
                  </div>
                </div>

                {renderDonutChart(
                  roiResult.investedPercent,
                  roiResult.returnsPercent,
                  'rgba(236, 72, 153, 0.9)', // pink
                  'rgba(16, 185, 129, 0.9)',  // emerald
                  'Initial Capital',
                  'Compounded Yield Gain',
                  `${currencySymbol}${roiResult.investedAmount.toLocaleString('en-US')}`,
                  `${currencySymbol}${roiResult.estGain.toLocaleString('en-US', { maximumFractionDigits: 0 })}`
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Year-by-Year Schedule Detailed List Grid Section */}
      <div className="bg-[#090d1f]/40 border border-slate-800/60 rounded-2xl p-5" id="finance_detailed_table">
        <button
          onClick={() => setShowSchedule(!showSchedule)}
          className="w-full flex items-center justify-between font-sans text-xs font-black tracking-wider text-slate-200 uppercase cursor-pointer"
        >
          <span className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-indigo-400" />
            <span>Interactive {subMode.toUpperCase()} Amortization & Progression Table</span>
          </span>
          {showSchedule ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
        </button>

        {showSchedule && (
          <div className="mt-4 overflow-x-auto scrollbar-thin">
            <table className="w-full text-left border-collapse text-[11px] font-mono leading-tight">
              <thead>
                <tr className="border-b border-slate-800/80 text-slate-400">
                  <th className="py-2.5 px-3">Year</th>
                  <th className="py-2.5 px-3 text-right">Opening Capital</th>
                  {subMode === 'swp' ? (
                    <th className="py-2.5 px-3 text-right">Withdrawn Cash</th>
                  ) : (
                    <th className="py-2.5 px-3 text-right">Added Payment</th>
                  )}
                  <th className="py-2.5 px-3 text-right">Interest / Yield Added</th>
                  <th className="py-2.5 px-3 text-right">Capital Out (Repaid) / Growth</th>
                  <th className="py-2.5 px-3 text-right">Closing Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850/60 text-slate-205">
                {(subMode === 'emi' ? emiResult : subMode === 'sip' ? sipResult : subMode === 'swp' ? swpResult : roiResult).schedule.map((row) => (
                  <tr key={row.year} className="hover:bg-slate-900/20">
                    <td className="py-2.5 px-3 text-slate-400 font-bold">Year {row.year}</td>
                    <td className="py-2.5 px-3 text-right">{currencySymbol}{row.openingBalance.toLocaleString('en-US', { maximumFractionDigits: 0 })}</td>
                    <td className="py-2.5 px-3 text-right">{currencySymbol}{row.payment.toLocaleString('en-US', { maximumFractionDigits: 0 })}</td>
                    <td className="py-2.5 px-3 text-right text-emerald-400/90">+{currencySymbol}{row.interest.toLocaleString('en-US', { maximumFractionDigits: 0 })}</td>
                    <td className="py-2.5 px-3 text-right text-indigo-300">
                      {currencySymbol}{subMode === 'emi' ? row.principal.toLocaleString('en-US', { maximumFractionDigits: 0 }) : (row.closingBalance - row.openingBalance).toLocaleString('en-US', { maximumFractionDigits: 0 })}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-slate-200">{currencySymbol}{row.closingBalance.toLocaleString('en-US', { maximumFractionDigits: 0 })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
