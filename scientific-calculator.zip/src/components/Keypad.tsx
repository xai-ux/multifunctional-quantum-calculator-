import { useState } from 'react';
import { CalcKeyConfig, CalcKeyType } from '../types';
import { Delete, ArrowUpDown, Info } from 'lucide-react';
import { motion } from 'motion/react';

interface KeypadProps {
  onKeyPress: (value: string, type: CalcKeyType) => void;
  isDegrees: boolean;
  onToggleDegRad: () => void;
  memory: number | null;
  onMemoryAction: (action: string) => void;
}

export default function Keypad({
  onKeyPress,
  isDegrees,
  onToggleDegRad,
  memory,
  onMemoryAction,
}: KeypadProps) {
  const [isShiftActive, setIsShiftActive] = useState(false);

  // Define scientific and standard keyboard grids
  // Alternate display functions for shift operations
  const keyGrid: CalcKeyConfig[] = [
    // Trigonometry / Functions (Primary and Alternates with Shift)
    { value: isShiftActive ? 'asin(' : 'sin(', display: isShiftActive ? 'sin⁻¹' : 'sin', type: 'function', tooltip: 'Sine / Inverse Sine' },
    { value: isShiftActive ? 'acos(' : 'cos(', display: isShiftActive ? 'cos⁻¹' : 'cos', type: 'function', tooltip: 'Cosine / Inverse Cosine' },
    { value: isShiftActive ? 'atan(' : 'tan(', display: isShiftActive ? 'tan⁻¹' : 'tan', type: 'function', tooltip: 'Tangent / Inverse Tangent' },
    { value: 'pow', display: '^', type: 'operator', tooltip: 'Power (x^y)' },
    
    { value: isShiftActive ? 'sinh(' : 'ln(', display: isShiftActive ? 'sinh' : 'ln', type: 'function', tooltip: 'Natural Logarithm / Hyperbolic Sine' },
    { value: isShiftActive ? 'cosh(' : 'log(', display: isShiftActive ? 'cosh' : 'log', type: 'function', tooltip: 'Base 10 Logarithm / Hyperbolic Cosine' },
    { value: isShiftActive ? 'tanh(' : 'sqrt(', display: isShiftActive ? 'tanh' : '√', type: 'function', tooltip: 'Square Root / Hyperbolic Tangent' },
    { value: '!', display: '!', type: 'function', tooltip: 'Factorial (n!)' },

    { value: isShiftActive ? 'ncr(' : 'pi', display: isShiftActive ? 'nCr' : 'π', type: isShiftActive ? 'function' : 'constant', tooltip: 'Pi Constant (3.14159...) / Combinations nCr(n,r)' },
    { value: isShiftActive ? 'npr(' : 'e', display: isShiftActive ? 'nPr' : 'e', type: isShiftActive ? 'function' : 'constant', tooltip: 'Euler Constant (2.71828...) / Permutations nPr(n,r)' },
    { value: '(', display: '(', type: 'action', tooltip: 'Open Parenthesis' },
    { value: ')', display: ')', type: 'action', tooltip: 'Close Parenthesis' },

    { value: 'x', display: 'x', type: 'constant', tooltip: 'Variable x' },
    { value: 'y', display: 'y', type: 'constant', tooltip: 'Variable y' },
    { value: 'CALC_INTEGRAL', display: '∫ dx / f', type: 'action', tooltip: 'Definite Integration [f]' },
    { value: 'CALC_DERIVATIVE', display: 'd/dx / dv', type: 'action', tooltip: 'Numerical Derivation [dv]' },
  ];

  const standardGrid: CalcKeyConfig[] = [
    // Standard keys (AC, Clear, Del, Operators etc)
    { value: 'AC', display: 'AC', type: 'action', tooltip: 'Clear All' },
    { value: 'BACKSPACE', display: '⌫', type: 'action', tooltip: 'Delete last character' },
    { value: '%', display: '%', type: 'operator', tooltip: 'Modulo / Percentage' },
    { value: '/', display: '÷', type: 'operator', tooltip: 'Divide' },

    { value: '7', display: '7', type: 'number' },
    { value: '8', display: '8', type: 'number' },
    { value: '9', display: '9', type: 'number' },
    { value: '*', display: '×', type: 'operator', tooltip: 'Multiply' },

    { value: '4', display: '4', type: 'number' },
    { value: '5', display: '5', type: 'number' },
    { value: '6', display: '6', type: 'number' },
    { value: '-', display: '−', type: 'operator', tooltip: 'Subtract' },

    { value: '1', display: '1', type: 'number' },
    { value: '2', display: '2', type: 'number' },
    { value: '3', display: '3', type: 'number' },
    { value: '+', display: '+', type: 'operator', tooltip: 'Add' },

    { value: '0', display: '0', type: 'number', span: 2 },
    { value: '.', display: '.', type: 'number' },
    { value: '=', display: '=', type: 'action' },
  ];

  // Map key categories to beautiful Tailwind CSS backgrounds with Geometric Balance values
  const getKeyStyle = (key: CalcKeyConfig) => {
    let base = 'relative text-xs font-mono font-medium rounded-xl flex items-center justify-center select-none transition-all py-3.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 ';
    
    // Spans
    if (key.span === 2) {
      base += 'col-span-2 ';
    }

    if (key.type === 'number') {
      base += 'bg-[#1E293B] hover:bg-[#334155]/40 active:bg-slate-850 text-slate-100 border border-[#0F172A] shadow-sm';
    } else if (key.type === 'operator') {
      base += 'bg-[#334155]/95 hover:bg-[#334155] active:bg-slate-800 text-indigo-300 font-semibold border border-slate-700 shadow-sm';
    } else if (key.type === 'function') {
      base += 'bg-[#0F172A] hover:bg-[#1E293B] active:bg-[#0F172A] text-indigo-400 font-bold border border-style border-slate-800';
    } else if (key.type === 'constant') {
      base += 'bg-[#0F172A] hover:bg-[#1E293B] text-indigo-400 font-bold border border-slate-800 font-mono';
    } else if (key.type === 'action') {
      if (key.value === '=') {
        base += 'bg-[#6366F1] hover:bg-[#4f52d9] active:bg-[#4f52d9] text-white font-bold text-sm border border-indigo-500 shadow-md';
      } else if (key.value === 'CALC_INTEGRAL') {
        base += 'bg-[#6366F1]/15 hover:bg-[#6366F1]/25 text-indigo-300 font-bold border border-indigo-500/40 shadow-sm shadow-[#6366F1]/10';
      } else if (key.value === 'CALC_DERIVATIVE') {
        base += 'bg-[#ec4899]/15 hover:bg-[#ec4899]/25 text-pink-300 font-bold border border-pink-500/40 shadow-sm shadow-[#ec4899]/10';
      } else if (key.value === 'AC' || key.value === 'BACKSPACE') {
        base += 'bg-[#1E293B] hover:bg-slate-800 text-rose-400 font-bold border border-slate-700';
      } else {
        base += 'bg-[#0F172A] hover:bg-[#1E293B] text-indigo-300 border border-slate-800';
      }
    }
    return base;
  };

  return (
    <div className="flex flex-col gap-3">
      {/* Dynamic state indicators & Utility control row */}
      <div className="flex justify-between items-center gap-2 bg-[#0F172A]/80 py-2.5 px-3.5 rounded-xl border border-slate-800">
        {/* Toggle Radians/Degrees Mode */}
        <button
          onClick={onToggleDegRad}
          className="text-[10px] font-mono font-semibold uppercase tracking-wider bg-[#1E293B] hover:bg-slate-800 active:bg-slate-700 text-indigo-400 px-3 py-1.5 rounded-lg border border-slate-700 transition-colors flex items-center gap-1.5"
          title="Toggle trigonometry calculation unit input"
          id="toggle_deg_rad_btn"
        >
          <ArrowUpDown className="w-3 h-3" />
          <span>{isDegrees ? 'Degrees (Deg)' : 'Radians (Rad)'}</span>
        </button>

        {/* Shift function mode */}
        <div className="flex items-center gap-2">
          {memory !== null && (
            <span className="text-[10px] font-mono bg-[#1E293B] px-2 py-1 rounded border border-slate-800 text-emerald-400">
              M = {Number(memory.toFixed(4))}
            </span>
          )}
          <button
            onClick={() => setIsShiftActive(!isShiftActive)}
            className={`text-[10px] font-mono font-semibold uppercase tracking-wider px-3 py-1.5 rounded-lg border transition-all ${
              isShiftActive
                ? 'bg-[#6366F1]/10 border-indigo-500/50 text-[#6366F1] scale-102 font-bold'
                : 'bg-[#1E293B] hover:bg-slate-800 border-slate-750 text-slate-400'
            }`}
            id="shift_toggle_btn"
          >
            Shift
          </button>
        </div>
      </div>

      {/* Memory operation toolbar */}
      <div className="grid grid-cols-5 gap-1.5 px-0.5">
        {['MC', 'MR', 'M+', 'M-', 'MS'].map((item) => (
          <button
            key={item}
            onClick={() => onMemoryAction(item)}
            className="py-1.5 bg-[#0F172A]/50 hover:bg-[#1E293B] text-[10px] font-mono font-medium text-slate-400 hover:text-slate-200 border border-slate-800/60 rounded-lg transition-colors"
            title={`${item} operation`}
            id={`mem_btn_${item}`}
          >
            {item}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-3.5">
        {/* Scientific Grid: takes 5 cols on lg sizes */}
        <div className="md:col-span-12 lg:col-span-5 grid grid-cols-4 gap-1.5">
          {keyGrid.map((key, idx) => (
            <motion.button
              key={idx}
              whileTap={{ scale: 0.94 }}
              onClick={() => onKeyPress(key.value, key.type)}
              className={getKeyStyle(key)}
              title={key.tooltip}
              id={`sci_btn_${key.display}`}
            >
              <span>{key.display}</span>
            </motion.button>
          ))}
        </div>

        {/* Divider for screen spacing */}
        <div className="hidden lg:block w-[1px] bg-slate-850 self-stretch my-2"></div>

        {/* Standard Keyboard Grid: takes 6-7 cols on lg sizes */}
        <div className="md:col-span-12 lg:col-span-6 grid grid-cols-4 gap-1.5 flex-1">
          {standardGrid.map((key, idx) => (
            <motion.button
              key={idx}
              whileTap={{ scale: 0.94 }}
              onClick={() => onKeyPress(key.value, key.type)}
              className={getKeyStyle(key)}
              title={key.tooltip}
              id={`std_btn_${key.display}`}
            >
              {key.value === 'BACKSPACE' ? <Delete className="w-4 h-4" /> : <span>{key.display}</span>}
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}
