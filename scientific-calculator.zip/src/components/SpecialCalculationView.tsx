import { useState, useEffect, useRef, useMemo } from 'react';
import { MathParser } from '../utils/parser';
import {
  HelpCircle,
  AlertTriangle,
  Play,
  RotateCcw,
  Sigma,
  TrendingUp,
  Info,
  Layers,
  Sparkles,
  Shuffle,
  Binary,
  ArrowRight,
  Calculator,
  Compass,
  ChevronDown,
  Dot
} from 'lucide-react';
import { motion } from 'motion/react';

interface SpecialCalculationViewProps {
  initialFormula?: string;
  initialOption?: 'derivation_integration' | 'permutation_combinational' | 'ap_gp';
  initialSubOption?: 'derivation' | 'integration' | 'permutation' | 'combination' | 'ap' | 'gp';
}

export default function SpecialCalculationView({
  initialFormula,
  initialOption = 'derivation_integration',
  initialSubOption
}: SpecialCalculationViewProps) {
  // Main Category tab: derivation_integration | permutation_combinational | ap_gp
  const [activeTab, setActiveTab] = useState<'derivation_integration' | 'permutation_combinational' | 'ap_gp'>(
    initialOption
  );

  // ----------------------------------------------------
  // SUB-TAB STATES
  // ----------------------------------------------------
  const [calcType, setCalcType] = useState<'derivative' | 'integral'>('derivative');
  const [combinatoricsType, setCombinatoricsType] = useState<'permutation' | 'combination'>('combination');
  const [progressionType, setProgressionType] = useState<'ap' | 'gp'>('ap');

  // Synchronize initial selections on external triggers
  useEffect(() => {
    if (initialOption) {
      setActiveTab(initialOption);
    }
    if (initialSubOption) {
      if (initialSubOption === 'derivation') setCalcType('derivative');
      else if (initialSubOption === 'integration') setCalcType('integral');
      else if (initialSubOption === 'permutation') setCombinatoricsType('permutation');
      else if (initialSubOption === 'combination') setCombinatoricsType('combination');
      else if (initialSubOption === 'ap') setProgressionType('ap');
      else if (initialSubOption === 'gp') setProgressionType('gp');
    }
  }, [initialOption, initialSubOption]);

  // ----------------------------------------------------
  // ENGINE 1: CALCULUS STATES
  // ----------------------------------------------------
  const [formula, setFormula] = useState<string>(initialFormula || 'x * sin(x)');
  useEffect(() => {
    if (initialFormula !== undefined && initialFormula.trim() !== '') {
      setFormula(initialFormula);
    }
  }, [initialFormula]);

  const [derivX, setDerivX] = useState<string>('2');
  const [derivOrder, setDerivOrder] = useState<1 | 2>(1);
  const [intA, setIntA] = useState<string>('0');
  const [intB, setIntB] = useState<string>('3.14159');
  const [intervals, setIntervals] = useState<number>(1000);

  const [derivResult, setDerivResult] = useState<number | null>(null);
  const [derivTangent, setDerivTangent] = useState<{ m: number; c: number; y0: number } | null>(null);
  const [integralResult, setIntegralResult] = useState<number | null>(null);
  const [calculusError, setCalculusError] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const canvasContainerRef = useRef<HTMLDivElement>(null);

  // ----------------------------------------------------
  // ENGINE 2: COMBINATORICS STATES
  // ----------------------------------------------------
  const [nInput, setNInput] = useState<string>('5');
  const [rInput, setRInput] = useState<string>('2');

  // ----------------------------------------------------
  // ENGINE 3: AP & GP STATES
  // ----------------------------------------------------
  const [progA, setProgA] = useState<string>('2'); // First term (a)
  const [progDiffRatio, setProgDiffRatio] = useState<string>('3'); // d (AP) or r (GP)
  const [progN, setProgN] = useState<string>('10'); // Number of terms (n)

  // ----------------------------------------------------
  // CALCULUS ENGINE LOGIC
  // ----------------------------------------------------
  const runCalculusCalculation = () => {
    setCalculusError(null);
    if (!formula.trim()) {
      setCalculusError('Formula is empty');
      return;
    }

    try {
      if (calcType === 'derivative') {
        const xVal = parseFloat(derivX);
        if (isNaN(xVal)) {
          throw new Error('Invalid evaluate point x');
        }

        const h = 0.0001;
        const f = (val: number) => {
          try {
            const res = new MathParser({ xValue: val }).evaluate(formula);
            return Number.isFinite(res) && !isNaN(res) ? res : 0;
          } catch {
            return 0;
          }
        };

        const y0 = f(xVal);

        if (derivOrder === 1) {
          const dy = (-f(xVal + 2 * h) + 8 * f(xVal + h) - 8 * f(xVal - h) + f(xVal - 2 * h)) / (12 * h);
          setDerivResult(dy);
          const c = y0 - dy * xVal;
          setDerivTangent({ m: dy, c, y0 });
        } else {
          const d2y = (-f(xVal + 2 * h) + 16 * f(xVal + h) - 30 * f(xVal) + 16 * f(xVal - h) - f(xVal - 2 * h)) / (12 * h * h);
          setDerivResult(d2y);
          setDerivTangent(null);
        }
      } else {
        const aVal = parseFloat(intA);
        const bVal = parseFloat(intB);
        if (isNaN(aVal) || isNaN(bVal)) {
          throw new Error('Lower or upper limit is not a valid number');
        }

        let currentIntervals = intervals;
        if (intervals % 2 !== 0 && intervals !== 1) {
          currentIntervals = intervals + 1;
        }

        const f = (val: number) => {
          const res = new MathParser({ xValue: val }).evaluate(formula);
          if (!Number.isFinite(res) || isNaN(res)) {
            throw new Error(`Integrand not defined or continuous at point x = ${val}`);
          }
          return res;
        };

        const n = currentIntervals;
        const h = (bVal - aVal) / n;
        let sum = f(aVal) + f(bVal);

        for (let i = 1; i < n; i++) {
          const x = aVal + i * h;
          if (i % 2 === 0) {
            sum += 2 * f(x);
          } else {
            sum += 4 * f(x);
          }
        }

        const finalArea = (h / 3) * sum;
        if (isNaN(finalArea) || !Number.isFinite(finalArea)) {
          throw new Error('Definite integral diverged or domain bounds contain singularities/discontinuities');
        }
        setIntegralResult(finalArea);
      }
    } catch (err: any) {
      setCalculusError(err?.message || 'Calculation failed due to numerical evaluation bounds');
    }
  };

  useEffect(() => {
    if (activeTab === 'derivation_integration') {
      runCalculusCalculation();
    }
  }, [formula, calcType, derivX, derivOrder, intA, intB, intervals, activeTab]);

  // Calculus plot rendering
  const drawCalculusPlot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    ctx.clearRect(0, 0, width, height);

    let xMin = -10;
    let xMax = 10;
    let yMin = -10;
    let yMax = 10;

    if (calcType === 'derivative') {
      const xPivot = parseFloat(derivX);
      if (!isNaN(xPivot)) {
        xMin = xPivot - 5;
        xMax = xPivot + 5;
      }
    } else {
      const a = parseFloat(intA);
      const b = parseFloat(intB);
      if (!isNaN(a) && !isNaN(b)) {
        const minVal = Math.min(a, b);
        const maxVal = Math.max(a, b);
        const span = Math.max(1, maxVal - minVal);
        xMin = minVal - span * 0.4;
        xMax = maxVal + span * 0.4;
      }
    }

    const toScreenX = (x: number) => ((x - xMin) / (xMax - xMin)) * width;
    const toScreenY = (y: number) => height - ((y - yMin) / (yMax - yMin)) * height;
    const toMathX = (sx: number) => xMin + (sx / width) * (xMax - xMin);

    const parser = new MathParser();
    const ySamples: number[] = [];
    for (let sx = 0; sx <= width; sx += 5) {
      const xVal = toMathX(sx);
      try {
        const yVal = parser.evaluate(formula === '' ? '0' : formula.replace(/x/g, `(${xVal})`));
        if (Number.isFinite(yVal) && !isNaN(yVal)) {
          ySamples.push(yVal);
        }
      } catch {}
    }

    if (ySamples.length > 0) {
      const minSampleVal = Math.min(...ySamples);
      const maxSampleVal = Math.max(...ySamples);
      const span = Math.max(0.1, maxSampleVal - minSampleVal);
      yMin = minSampleVal - span * 0.25;
      yMax = maxSampleVal + span * 0.25;
      if (yMin > 0) yMin = -1;
      if (yMax < 0) yMax = 1;
    }

    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 0.5;
    ctx.fillStyle = '#64748b';
    ctx.font = '9px JetBrains Mono';

    const countTicks = 10;
    const xStep = (xMax - xMin) / countTicks;
    for (let i = 0; i <= countTicks; i++) {
      const val = xMin + i * xStep;
      const sx = toScreenX(val);
      ctx.beginPath();
      ctx.moveTo(sx, 0);
      ctx.lineTo(sx, height);
      ctx.stroke();
      ctx.fillText(val.toFixed(2), sx + 2, height - 6);
    }

    const yStep = (yMax - yMin) / countTicks;
    for (let i = 0; i <= countTicks; i++) {
      const val = yMin + i * yStep;
      const sy = toScreenY(val);
      ctx.beginPath();
      ctx.moveTo(0, sy);
      ctx.lineTo(width, sy);
      ctx.stroke();
      ctx.fillText(val.toFixed(2), 4, sy - 2);
    }

    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1.25;
    const screenY0 = toScreenY(0);
    if (screenY0 >= 0 && screenY0 <= height) {
      ctx.beginPath();
      ctx.moveTo(0, screenY0);
      ctx.lineTo(width, screenY0);
      ctx.stroke();
    }
    const screenX0 = toScreenX(0);
    if (screenX0 >= 0 && screenX0 <= width) {
      ctx.beginPath();
      ctx.moveTo(screenX0, 0);
      ctx.lineTo(screenX0, height);
      ctx.stroke();
    }

    if (calcType === 'integral') {
      const a = parseFloat(intA);
      const b = parseFloat(intB);
      if (!isNaN(a) && !isNaN(b)) {
        const startX = Math.min(a, b);
        const endX = Math.max(a, b);
        const startSx = Math.max(0, Math.min(width, toScreenX(startX)));
        const endSx = Math.max(0, Math.min(width, toScreenX(endX)));

        ctx.fillStyle = 'rgba(99, 102, 241, 0.12)';
        ctx.beginPath();
        let firstPos = true;

        for (let sx = startSx; sx <= endSx; sx++) {
          const xVal = toMathX(sx);
          try {
            const yVal = parser.evaluate(formula.replace(/x/g, `(${xVal})`));
            if (Number.isFinite(yVal)) {
              const syVal = toScreenY(yVal);
              if (firstPos) {
                ctx.moveTo(sx, toScreenY(0));
                ctx.lineTo(sx, syVal);
                firstPos = false;
              } else {
                ctx.lineTo(sx, syVal);
              }
            }
          } catch {}
        }
        ctx.lineTo(endSx, toScreenY(0));
        ctx.closePath();
        ctx.fill();

        ctx.strokeStyle = 'rgba(99, 102, 241, 0.35)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(toScreenX(a), toScreenY(0));
        try {
          ctx.lineTo(toScreenX(a), toScreenY(parser.evaluate(formula.replace(/x/g, `(${a})`))));
        } catch {}
        ctx.moveTo(toScreenX(b), toScreenY(0));
        try {
          ctx.lineTo(toScreenX(b), toScreenY(parser.evaluate(formula.replace(/x/g, `(${b})`))));
        } catch {}
        ctx.stroke();
      }
    }

    ctx.strokeStyle = '#6366f1';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    let inPath = false;

    for (let sx = 0; sx <= width; sx += 2) {
      const xVal = toMathX(sx);
      try {
        const yVal = parser.evaluate(formula.replace(/x/g, `(${xVal})`));
        if (Number.isFinite(yVal) && !isNaN(yVal)) {
          const sy = toScreenY(yVal);
          if (sy >= -50 && sy <= height + 50) {
            if (!inPath) {
              ctx.moveTo(sx, sy);
              inPath = true;
            } else {
              ctx.lineTo(sx, sy);
            }
          } else {
            inPath = false;
          }
        } else {
          inPath = false;
        }
      } catch {
        inPath = false;
      }
    }
    ctx.stroke();

    if (calcType === 'derivative' && derivOrder === 1 && derivTangent) {
      const xPivot = parseFloat(derivX);
      if (!isNaN(xPivot)) {
        ctx.strokeStyle = '#ec4899';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();

        const yStart = derivTangent.m * xMin + derivTangent.c;
        const yEnd = derivTangent.m * xMax + derivTangent.c;

        ctx.moveTo(0, toScreenY(yStart));
        ctx.lineTo(width, toScreenY(yEnd));
        ctx.stroke();
        ctx.setLineDash([]);

        const pivotSx = toScreenX(xPivot);
        const pivotSy = toScreenY(derivTangent.y0);

        ctx.fillStyle = '#ec4899';
        ctx.beginPath();
        ctx.arc(pivotSx, pivotSy, 5, 0, 2 * Math.PI);
        ctx.fill();

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(pivotSx, pivotSy, 2.5, 0, 2 * Math.PI);
        ctx.stroke();
      }
    }
  };

  const handleResize = () => {
    const container = canvasContainerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const rect = container.getBoundingClientRect();
    canvas.width = rect.width;
    canvas.height = Math.max(240, rect.width * 0.4);
    drawCalculusPlot();
  };

  useEffect(() => {
    if (activeTab === 'derivation_integration') {
      drawCalculusPlot();
    }
  }, [formula, calcType, derivX, derivOrder, intA, intB, derivTangent, activeTab]);

  useEffect(() => {
    if (activeTab === 'derivation_integration') {
      handleResize();
      const observer = new ResizeObserver(() => handleResize());
      if (canvasContainerRef.current) observer.observe(canvasContainerRef.current);
      return () => observer.disconnect();
    }
  }, [activeTab]);

  // ----------------------------------------------------
  // COMBINATORICS ENGINE LOGIC
  // ----------------------------------------------------
  const combN = useMemo(() => {
    const parsed = parseInt(nInput);
    return isNaN(parsed) || parsed < 0 ? 0 : parsed;
  }, [nInput]);

  const combR = useMemo(() => {
    const parsed = parseInt(rInput);
    return isNaN(parsed) || parsed < 0 ? 0 : parsed;
  }, [rInput]);

  const combinatoricsError = useMemo(() => {
    if (combN < 0 || combR < 0) {
      return 'Inputs must be positive integers.';
    }
    if (combR > combN) {
      return 'Subset size (r) cannot exceed total elements count (n).';
    }
    if (combN > 1000) {
      return 'Total elements count (n) is limited to 1000 to prevent numerical calculation lag.';
    }
    return null;
  }, [combN, combR]);

  const combinatoricsResult = useMemo(() => {
    if (combinatoricsError) return null;

    let result = 0;
    let stepsMarkdown = '';

    if (combinatoricsType === 'combination') {
      if (combR === 0 || combR === combN) {
        result = 1;
        stepsMarkdown = `\nC(${combN}, ${combR}) = 1\nSince selecting ${combR} elements out of ${combN} has exactly 1 possibility.`;
      } else {
        const actualR = combR > combN / 2 ? combN - combR : combR;
        let numerator = 1;
        let denominator = 1;
        const numeratorFactors: number[] = [];
        const denominatorFactors: number[] = [];

        for (let i = 1; i <= actualR; i++) {
          numerator *= (combN - actualR + i);
          denominator *= i;
          numeratorFactors.unshift(combN - actualR + i);
          denominatorFactors.unshift(i);
        }

        result = Math.round(numerator / denominator);
        stepsMarkdown = `
**Formula:**
C(n, r) = n! / (r! × (n-r)!)

**Substitution:**
C(${combN}, ${combR}) = ${combN}! / (${combR}! × (${combN}-${combR})!) = ${combN}! / (${combR}! × ${combN - combR}!)

**Factorial Cancellation Steps:**
To prevent huge numbers, common factors cancel out perfectly:
[${numeratorFactors.join(' × ')}] / [${denominatorFactors.reverse().join(' × ')}]
= ${numerator.toLocaleString()} / ${denominator.toLocaleString()}
= ${result.toLocaleString()}
        `;
      }
    } else {
      if (combR === 0) {
        result = 1;
        stepsMarkdown = `\nP(${combN}, 0) = 1\nArranging 0 elements from ${combN} elements has exactly 1 way.`;
      } else {
        let permResult = 1;
        const factors: number[] = [];
        for (let i = combN - combR + 1; i <= combN; i++) {
          permResult *= i;
          factors.unshift(i);
        }
        result = permResult;
        stepsMarkdown = `
**Formula:**
P(n, r) = n! / (n-r)!

**Substitution:**
P(${combN}, ${combR}) = ${combN}! / (${combN}-${combR})! = ${combN}! / ${combN - combR}!

**Factorial Cancellation Steps:**
The common denominator terms cancel out completely:
P(${combN}, ${combR}) = ${factors.join(' × ')}
= ${result.toLocaleString()}
        `;
      }
    }

    return { result, steps: stepsMarkdown };
  }, [combN, combR, combinatoricsType, combinatoricsError]);

  const combVisualizer = useMemo(() => {
    if (combinatoricsError || combN > 12) return null;

    const baseItems = Array.from({ length: combN }, (_, i) => String.fromCharCode(65 + i));

    const getCombinations = (arr: string[], k: number): string[][] => {
      const results: string[][] = [];
      const helper = (start: number, combo: string[]) => {
        if (combo.length === k) {
          results.push([...combo]);
          return;
        }
        for (let i = start; i < arr.length; i++) {
          combo.push(arr[i]);
          helper(i + 1, combo);
          combo.pop();
        }
      };
      helper(0, []);
      return results;
    };

    const getPermutations = (arr: string[], k: number): string[][] => {
      const results: string[][] = [];
      const used = new Array(arr.length).fill(false);
      const helper = (combo: string[]) => {
        if (combo.length === k) {
          results.push([...combo]);
          return;
        }
        for (let i = 0; i < arr.length; i++) {
          if (!used[i]) {
            used[i] = true;
            combo.push(arr[i]);
            helper(combo);
            combo.pop();
            used[i] = false;
          }
        }
      };
      helper([]);
      return results;
    };

    const totalCalculated = combinatoricsResult?.result ?? 0;
    if (totalCalculated > 400) {
      return {
        items: [],
        overflowed: true,
        message: `There are ${totalCalculated.toLocaleString()} outcomes. List visualization is hidden to keep page performance responsive.`,
        baseItems,
      };
    }

    const items =
      combinatoricsType === 'combination'
        ? getCombinations(baseItems, combR)
        : getPermutations(baseItems, combR);

    return {
      items,
      overflowed: false,
      baseItems,
    };
  }, [combN, combR, combinatoricsType, combinatoricsError, combinatoricsResult]);

  // ----------------------------------------------------
  // SEQUENCES (AP / GP) ENGINE LOGIC
  // ----------------------------------------------------
  const apG_a = useMemo(() => parseFloat(progA), [progA]);
  const apG_diff_ratio = useMemo(() => parseFloat(progDiffRatio), [progDiffRatio]);
  const apG_n = useMemo(() => {
    const parsed = parseInt(progN);
    return isNaN(parsed) || parsed < 1 ? 1 : parsed;
  }, [progN]);

  const progressionError = useMemo(() => {
    if (isNaN(apG_a)) return 'First term (a) must be a valid number.';
    if (isNaN(apG_diff_ratio)) {
      return progressionType === 'ap'
        ? 'Common difference (d) must be a valid number.'
        : 'Common ratio (r) must be a valid number.';
    }
    if (isNaN(apG_n) || apG_n < 1) return 'Number of terms (n) must be an integer >= 1.';
    if (apG_n > 1000000) return 'Terms count (n) is capped at 1,000,000 to avoid computational overflow.';
    return null;
  }, [apG_a, apG_diff_ratio, apG_n, progressionType]);

  const progressionResult = useMemo(() => {
    if (progressionError) return null;

    const firstTerm = apG_a;
    const diffOrRatio = apG_diff_ratio;
    const n = apG_n;

    let nthTerm = 0;
    let sumN = 0;
    let sumInfinity: string | number = 'N/A';
    let steps: string[] = [];
    const listTerms: number[] = [];

    if (progressionType === 'ap') {
      // AP Laws:
      // a_n = a + (n-1)*d
      // S_n = n/2 * (2a + (n-1)*d)
      nthTerm = firstTerm + (n - 1) * diffOrRatio;
      sumN = (n / 2) * (2 * firstTerm + (n - 1) * diffOrRatio);

      steps = [
        `Identify the variables: First Term (a) = ${firstTerm}, Common Difference (d) = ${diffOrRatio}, Number of terms (n) = ${n}.`,
        `Apply the Nth Term formula: a_n = a + (n - 1) * d`,
        `Substitute into Nth Term: a_${n} = ${firstTerm} + (${n} - 1) * ${diffOrRatio} = ${firstTerm} + ${n - 1} * ${diffOrRatio} = ${nthTerm}`,
        `Apply the Sum of First N Terms formula: S_n = (n / 2) * [2a + (n - 1) * d]`,
        `Substitute into Sum: S_${n} = (${n} / 2) * [2*(${firstTerm}) + (${n} - 1) * ${diffOrRatio}] = ${n / 2} * [${2 * firstTerm} + ${n - 1 * diffOrRatio}] = ${sumN}`
      ];

      // Generate first 10 preview terms
      for (let i = 1; i <= Math.min(10, n); i++) {
        listTerms.push(firstTerm + (i - 1) * diffOrRatio);
      }
    } else {
      // GP Laws:
      // a_n = a * r^(n-1)
      // S_n = a * (1 - r^n) / (1 - r) (if r != 1) or n * a (if r == 1)
      nthTerm = firstTerm * Math.pow(diffOrRatio, n - 1);

      if (diffOrRatio === 1) {
        sumN = n * firstTerm;
      } else {
        sumN = firstTerm * (1 - Math.pow(diffOrRatio, n)) / (1 - diffOrRatio);
      }

      steps = [
        `Identify the variables: First Term (a) = ${firstTerm}, Common Ratio (r) = ${diffOrRatio}, Number of terms (n) = ${n}.`,
        `Apply the Nth Term formula: a_n = a * r^(n - 1)`,
        `Substitute into Nth Term: a_${n} = ${firstTerm} * (${diffOrRatio})^(${n} - 1) = ${firstTerm} * (${diffOrRatio})^(${n - 1}) = ${nthTerm}`
      ];

      if (diffOrRatio === 1) {
        steps.push(
          `Since the common ratio r is exactly 1, the terms are identical.`,
          `S_n = n * a = ${n} * ${firstTerm} = ${sumN}`
        );
      } else {
        steps.push(
          `Apply the Sum of First N Terms formula: S_n = a * (1 - r^n) / (1 - r)`,
          `Substitute into Sum: S_${n} = ${firstTerm} * (1 - (${diffOrRatio})^${n}) / (1 - ${diffOrRatio}) = ${sumN}`
        );
      }

      // Sum to infinity if |r| < 1
      if (Math.abs(diffOrRatio) < 1) {
        const infSum = firstTerm / (1 - diffOrRatio);
        sumInfinity = infSum;
        steps.push(
          `Determine convergence: Since the common ratio |r| = |${diffOrRatio}| < 1, the series converges to a finite limit at infinity.`,
          `Apply Sum to Infinity formula: S_∞ = a / (1 - r)`,
          `Substitute into S_∞: S_∞ = ${firstTerm} / (1 - ${diffOrRatio}) = ${infSum}`
        );
      } else {
        sumInfinity = 'Divergent (|r| ≥ 1)';
        steps.push(`Determine convergence: Since |r| = |${diffOrRatio}| ≥ 1, the series is divergent. The sum to infinity is unbounded (∞).`);
      }

      // Generate first 10 preview terms
      for (let i = 1; i <= Math.min(10, n); i++) {
        listTerms.push(firstTerm * Math.pow(diffOrRatio, i - 1));
      }
    }

    return {
      nthTerm,
      sumN,
      sumInfinity,
      steps,
      listTerms,
    };
  }, [apG_a, apG_diff_ratio, apG_n, progressionType, progressionError]);

  return (
    <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden group">
      {/* Decorative backdrop blobs */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/5 rounded-full blur-[90px] pointer-events-none" />
      <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-pink-500/5 rounded-full blur-[90px] pointer-events-none" />

      <div className="flex flex-col gap-6 relative z-10">
        {/* Top Header Title */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-indigo-400 animate-pulse" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-100 tracking-tight flex items-center gap-2">
                <span>Specialized Computational Solver</span>
                <span className="text-[10px] font-mono font-bold tracking-wider text-pink-400 bg-pink-500/10 px-2 py-0.5 rounded border border-pink-500/10 uppercase">
                  Extended Math Core
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                A single professional environment coordinating calculus analysis, discrete selection states, and sequence progressions.
              </p>
            </div>
          </div>
        </div>

        {/* Triple selection tab pills */}
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none border-b border-slate-800/60 pb-3">
          <button
            onClick={() => setActiveTab('derivation_integration')}
            className={`flex items-center gap-2 text-xs font-bold px-4 py-2.5 rounded-xl border transition-all whitespace-nowrap ${
              activeTab === 'derivation_integration'
                ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-300'
                : 'bg-slate-900/40 border-slate-850 text-slate-400 hover:text-slate-205'
            }`}
          >
            <Sigma className="w-3.5 h-3.5 text-indigo-400" />
            <span>Derivation & Integration</span>
          </button>
          <button
            onClick={() => setActiveTab('permutation_combinational')}
            className={`flex items-center gap-2 text-xs font-bold px-4 py-2.5 rounded-xl border transition-all whitespace-nowrap ${
              activeTab === 'permutation_combinational'
                ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-300'
                : 'bg-slate-900/40 border-slate-850 text-slate-400 hover:text-slate-205'
            }`}
          >
            <Binary className="w-3.5 h-3.5 text-pink-400" />
            <span>Permutations & Combinations</span>
          </button>
          <button
            onClick={() => setActiveTab('ap_gp')}
            className={`flex items-center gap-2 text-xs font-bold px-4 py-2.5 rounded-xl border transition-all whitespace-nowrap ${
              activeTab === 'ap_gp'
                ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-300'
                : 'bg-slate-900/40 border-slate-850 text-slate-400 hover:text-slate-205'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            <span>AP & GP Progressions</span>
          </button>
        </div>

        {/* ----------------------------------------------------
            TAB 1: INTEGRATION & DERIVATION SECTION
            ---------------------------------------------------- */}
        {activeTab === 'derivation_integration' && (
          <div className="space-y-5">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">
                Calculus Solver Node
              </span>
              <div className="flex items-center gap-1 bg-[#020617] p-1 rounded-xl border border-slate-850 self-start sm:self-auto">
                <button
                  onClick={() => setCalcType('derivative')}
                  className={`text-xs font-semibold px-3.5 py-1.5 rounded-lg transition-all ${
                    calcType === 'derivative'
                      ? 'bg-indigo-500/15 text-indigo-200 border border-indigo-500/20'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Derivative d/dx
                </button>
                <button
                  onClick={() => setCalcType('integral')}
                  className={`text-xs font-semibold px-3.5 py-1.5 rounded-lg transition-all ${
                    calcType === 'integral'
                      ? 'bg-indigo-500/15 text-indigo-200 border border-indigo-500/20'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Integration ∫ dx
                </button>
              </div>
            </div>

            {/* Formula Input */}
            <div className="space-y-2">
              <label className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block font-bold">
                Formula Expression f(x):
              </label>
              <div className="relative">
                <span className="absolute left-4 top-3 font-mono text-sm text-indigo-400 font-semibold">f(x) =</span>
                <input
                  type="text"
                  value={formula}
                  onChange={(e) => setFormula(e.target.value)}
                  className="w-full bg-[#020617] border border-slate-805 focus:border-indigo-500 rounded-xl pl-16 pr-4 py-2.5 text-xs font-mono text-slate-200 outline-none transition-all text-white border-l-2 border-l-indigo-500"
                  placeholder="e.g. x * sin(x) + e^(-x)"
                />
              </div>
            </div>

            {/* Main Interactive Dual Dividers */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Controls Column */}
              <div className="lg:col-span-5 space-y-4">
                {calcType === 'derivative' ? (
                  <div className="bg-[#020617]/50 border border-slate-800 p-4 rounded-2xl space-y-3.5 flex-1 select-none">
                    <div className="flex justify-between items-center border-b border-slate-800/65 pb-2">
                      <span className="text-xs font-mono text-slate-300 font-bold uppercase tracking-wider">
                        Parameters Setup
                      </span>
                      <div className="flex bg-slate-950 p-0.5 rounded-lg text-[9px] font-mono border border-slate-850">
                        <button
                          onClick={() => setDerivOrder(1)}
                          className={`px-2 py-1 rounded ${derivOrder === 1 ? 'bg-indigo-600/20 text-indigo-300 font-bold' : 'text-slate-500'}`}
                        >
                          1st f'(x)
                        </button>
                        <button
                          onClick={() => setDerivOrder(2)}
                          className={`px-2 py-1 rounded ${derivOrder === 2 ? 'bg-indigo-600/20 text-indigo-300 font-bold' : 'text-slate-500'}`}
                        >
                          2nd f''(x)
                        </button>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-mono text-slate-400 block">Evaluate position point x₀</label>
                        <input
                          type="number"
                          value={derivX}
                          onChange={(e) => setDerivX(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-200 outline-none text-white focus:border-indigo-500"
                        />
                      </div>

                      {/* Derivative details */}
                      <div className="bg-indigo-950/10 border border-indigo-900/20 rounded-xl p-4 space-y-2">
                        <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">
                          {derivOrder === 1 ? "Computed Tangent Slope m" : "Second Derivative f''(x₀)"}
                        </span>
                        <div className="text-2.5xl font-mono font-extrabold text-indigo-300 break-all leading-tight">
                          {derivResult !== null ? Number(derivResult.toFixed(7)).toLocaleString() : 'N/A'}
                        </div>
                        {derivOrder === 1 && derivTangent && (
                          <div className="pt-2 border-t border-slate-800/10 mt-1">
                            <span className="text-[9px] font-mono text-slate-550 block">Approximated Tangent Line:</span>
                            <code className="text-xs font-mono text-rose-450 font-bold block mt-0.5">
                              y = {Number(derivTangent.m.toFixed(4))}x {derivTangent.c >= 0 ? '+' : '-'} {Math.abs(Number(derivTangent.c.toFixed(4)))}
                            </code>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-[#020617]/50 border border-slate-800 p-4 rounded-2xl space-y-3.5 flex-1 select-none">
                    <div className="border-b border-slate-800/65 pb-2">
                      <span className="text-xs font-mono text-slate-300 font-bold uppercase tracking-wider block">
                        Definite Integration bounds
                      </span>
                    </div>

                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-mono text-slate-400 block">Lower Bound (a)</label>
                          <input
                            type="text"
                            value={intA}
                            onChange={(e) => setIntA(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs font-mono text-slate-200 outline-none focus:border-indigo-500"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-mono text-slate-400 block">Upper Bound (b)</label>
                          <input
                            type="text"
                            value={intB}
                            onChange={(e) => setIntB(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs font-mono text-slate-200 outline-none focus:border-indigo-500"
                          />
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[10px] font-mono text-slate-400 flex justify-between">
                          <span>Riemann Steps / Intervals:</span>
                          <span className="text-pink-400 font-bold">{intervals} terms</span>
                        </label>
                        <input
                          type="range"
                          min="10"
                          max="2000"
                          step="10"
                          value={intervals}
                          onChange={(e) => setIntervals(parseInt(e.target.value))}
                          className="w-full h-1 accent-indigo-500 bg-slate-800 cursor-pointer rounded-lg"
                        />
                      </div>

                      <div className="bg-indigo-950/10 border border-indigo-900/20 rounded-xl p-4 space-y-1.5">
                        <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">
                          Calculated Area (Simpson's Approximation)
                        </span>
                        <div className="text-2.5xl font-mono font-extrabold text-indigo-300 break-all leading-tight">
                          {integralResult !== null ? Number(integralResult.toFixed(7)).toLocaleString() : 'N/A'}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Graphics Plotting Canvas Column */}
              <div className="lg:col-span-7 flex flex-col justify-between">
                <div ref={canvasContainerRef} className="relative bg-[#020617] border border-slate-800/80 rounded-2xl overflow-hidden shadow-inner flex-1 flex items-center justify-center min-h-[220px]">
                  <canvas ref={canvasRef} className="block w-full" />
                  <div className="absolute right-3.5 bottom-3 bg-slate-950/80 backdrop-blur border border-slate-850 rounded px-2 py-0.5 text-[8.5px] font-mono text-indigo-400 font-semibold tracking-wide">
                    {calcType === 'derivative' ? 'Tangent Slope Stencil' : 'Continuous Riemann Curve Graph'}
                  </div>
                </div>
              </div>
            </div>

            {calculusError && (
              <div className="flex items-start gap-2 bg-rose-500/5 border border-rose-500/10 text-rose-350 p-3.5 rounded-xl font-mono text-xs">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-450" />
                <span>{calculusError}</span>
              </div>
            )}
          </div>
        )}

        {/* ----------------------------------------------------
            TAB 2: PERMUTATIONS & COMBINATIONS SECTION
            ---------------------------------------------------- */}
        {activeTab === 'permutation_combinational' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">
                Combinatorial CAS Core
              </span>
              <div className="flex items-center gap-1 bg-[#020617] p-1 rounded-xl border border-slate-850 self-start sm:self-auto">
                <button
                  onClick={() => setCombinatoricsType('combination')}
                  className={`text-xs font-semibold px-3.5 py-1.5 rounded-lg transition-all ${
                    combinatoricsType === 'combination'
                      ? 'bg-indigo-500/15 text-indigo-200 border border-indigo-500/20'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Combination (nCr)
                </button>
                <button
                  onClick={() => setCombinatoricsType('permutation')}
                  className={`text-xs font-semibold px-3.5 py-1.5 rounded-lg transition-all ${
                    combinatoricsType === 'permutation'
                      ? 'bg-indigo-500/15 text-indigo-200 border border-indigo-500/20'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Permutation (nPr)
                </button>
              </div>
            </div>

            {/* Inputs Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block font-bold">
                  Total items in universe (n)
                </label>
                <input
                  type="number"
                  min="0"
                  max="1000"
                  value={nInput}
                  onChange={(e) => setNInput(e.target.value)}
                  className="w-full bg-[#020617] border border-slate-805 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none transition-all text-white border-l-2 border-l-indigo-500"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block font-bold">
                  Subset selection count (r)
                </label>
                <input
                  type="number"
                  min="0"
                  max="1000"
                  value={rInput}
                  onChange={(e) => setRInput(e.target.value)}
                  className="w-full bg-[#020617] border border-slate-805 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none transition-all text-white border-l-2 border-l-pink-500"
                />
              </div>
            </div>

            {combinatoricsError && (
              <div className="flex items-start gap-2 bg-rose-500/5 border border-rose-500/10 text-rose-350 p-3 rounded-xl font-mono text-xs">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-450" />
                <span>{combinatoricsError}</span>
              </div>
            )}

            {!combinatoricsError && combinatoricsResult && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-2">
                <div className="lg:col-span-5 bg-[#020617]/50 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between space-y-4">
                  <div>
                    <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block font-semibold mb-1">
                      {combinatoricsType === 'combination' ? 'Combinations Count (ⁿCᵣ)' : 'Permutations Count (ⁿPᵣ)'}
                    </span>
                    <span className="text-[10px] font-mono text-indigo-400 block mb-2">
                      {combinatoricsType === 'combination' ? `C(${combN}, ${combR})` : `P(${combN}, ${combR})`}
                    </span>
                    <div className="text-3.5xl font-extrabold font-mono text-slate-100 tracking-tight break-all">
                      {combinatoricsResult.result.toLocaleString()}
                    </div>
                  </div>

                  <div className="text-xs text-slate-400 leading-relaxed space-y-1.5 border-t border-slate-900 pt-3">
                    <div className="flex items-center gap-1.5 font-bold text-slate-300">
                      <Info className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Rule parameters:</span>
                    </div>
                    {combinatoricsType === 'combination' ? (
                      <p>
                        <strong>Order is irrelevant:</strong> Grouping subsets {`{A, B}`} is identical to {`{B, A}`}. Useful for teams, hands of cards, or item packages.
                      </p>
                    ) : (
                      <p>
                        <strong>Order is critical:</strong> Rearranging ordered list AB is distinct from BA. Useful for pins, scheduling, passwords, or podium ordering.
                      </p>
                    )}
                  </div>
                </div>

                {/* Steps detail */}
                <div className="lg:col-span-7 bg-[#020617]/40 border border-slate-800 rounded-2xl p-4 space-y-3 flex flex-col justify-between">
                  <div>
                    <span className="text-xs font-mono text-slate-300 font-bold uppercase tracking-wider block mb-2 border-b border-slate-900 pb-2">
                      Factorial Formulation & Derivation steps
                    </span>
                    <div className="font-mono text-xs text-slate-350 space-y-2 whitespace-pre-wrap">
                      {combinatoricsResult.steps.split('\n\n').map((block, idx) => {
                        if (!block.trim()) return null;
                        const hasFormula = block.includes('C(n, r)') || block.includes('P(n, r)') || block.includes('C(') || block.includes('P(') || block.includes(' / ');
                        return (
                          <div
                            key={idx}
                            className={`py-1.5 ${hasFormula ? 'bg-slate-900/60 p-2.5 rounded border border-slate-800/40 text-indigo-300' : ''}`}
                          >
                            {block.replace(/\*\*(.*?)\*\*/g, '$1')}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Visual Lists representation */}
            {!combinatoricsError && combVisualizer && (
              <div className="bg-[#020617]/20 border border-slate-800 p-4 rounded-xl space-y-3">
                <span className="text-xs font-mono text-slate-300 font-bold uppercase tracking-wider block flex items-center gap-1">
                  <Layers className="w-3.5 h-3.5 text-indigo-400" /> Group Subset Listings & Combinatorial Visualization
                </span>
                {combVisualizer.overflowed ? (
                  <p className="text-[11px] font-mono text-slate-400 block bg-slate-950 p-3 rounded border border-slate-900 leading-relaxed">
                    {combVisualizer.message}
                  </p>
                ) : (
                  <div className="space-y-3 font-mono text-xs text-slate-300">
                    <p>
                      Assuming a set of {combN} elements: <code className="text-indigo-400 bg-indigo-500/10 px-1.5 py-0.5 rounded">[{combVisualizer.baseItems.join(', ')}]</code>, here are all the calculated permutations:
                    </p>
                    <div className="max-h-52 overflow-y-auto border border-slate-850 bg-[#020617] rounded-xl p-3 grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-2.5 scrollbar-thin">
                      {combVisualizer.items.map((itVec, i) => (
                        <div
                          key={i}
                          className="bg-slate-950/80 border border-slate-850 hover:border-indigo-500/30 text-indigo-200 text-center py-1.5 rounded-lg text-[10.5px] select-all font-semibold"
                        >
                          <span className="text-slate-550 mr-1 font-normal text-[9px]">#{i + 1}</span>
                          {itVec.join('')}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ----------------------------------------------------
            TAB 3: AP & GP PROGRESSIONS SECTION
            ---------------------------------------------------- */}
        {activeTab === 'ap_gp' && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">
                Analytical Sequences Engine
              </span>
              <div className="flex items-center gap-1 bg-[#020617] p-1 rounded-xl border border-slate-850 self-start sm:self-auto">
                <button
                  onClick={() => setProgressionType('ap')}
                  className={`text-xs font-semibold px-3.5 py-1.5 rounded-lg transition-all ${
                    progressionType === 'ap'
                      ? 'bg-indigo-500/15 text-indigo-200 border border-indigo-500/20'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Arithmetic (AP)
                </button>
                <button
                  onClick={() => setProgressionType('gp')}
                  className={`text-xs font-semibold px-3.5 py-1.5 rounded-lg transition-all ${
                    progressionType === 'gp'
                      ? 'bg-indigo-500/15 text-indigo-200 border border-indigo-500/20'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Geometric (GP)
                </button>
              </div>
            </div>

            {/* Inputs Area */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-405 uppercase tracking-wider block font-bold">
                  First Term (a)
                </label>
                <input
                  type="number"
                  value={progA}
                  onChange={(e) => setProgA(e.target.value)}
                  className="w-full bg-[#020617] border border-slate-805 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none transition-all text-white border-l-2 border-l-indigo-500"
                  placeholder="e.g. 2"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-405 uppercase tracking-wider block font-bold">
                  {progressionType === 'ap' ? 'Common Difference (d)' : 'Common Ratio (r)'}
                </label>
                <input
                  type="number"
                  value={progDiffRatio}
                  onChange={(e) => setProgDiffRatio(e.target.value)}
                  className="w-full bg-[#020617] border border-slate-805 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none transition-all text-white border-l-2 border-l-pink-500"
                  placeholder={progressionType === 'ap' ? 'e.g. 3' : 'e.g. 2'}
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono text-slate-405 uppercase tracking-wider block font-bold">
                  Terms limit quantity (n)
                </label>
                <input
                  type="number"
                  min="1"
                  max="1000000"
                  value={progN}
                  onChange={(e) => setProgN(e.target.value)}
                  className="w-full bg-[#020617] border border-slate-805 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 outline-none transition-all text-white border-l-2 border-l-emerald-500"
                  placeholder="e.g. 10"
                />
              </div>
            </div>

            {progressionError && (
              <div className="flex items-start gap-2 bg-rose-500/5 border border-rose-500/10 text-rose-350 p-3 rounded-xl font-mono text-xs">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-450" />
                <span>{progressionError}</span>
              </div>
            )}

            {!progressionError && progressionResult && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-2">
                {/* Result side card */}
                <div className="lg:col-span-5 flex flex-col gap-4">
                  {/* Cards stack */}
                  <div className="bg-[#020617]/50 border border-slate-800 rounded-2xl p-4 space-y-3.5 shadow-inner">
                    <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest block font-bold">
                      Sequence outputs
                    </span>

                    <div className="space-y-4">
                      <div className="border-b border-slate-900 pb-3">
                        <span className="text-[10px] font-mono text-slate-500 block">
                          Nth term (a_{apG_n})
                        </span>
                        <div className="text-2.5xl font-mono font-extrabold text-emerald-400 break-all leading-tight">
                          {progressionResult.nthTerm.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                        </div>
                      </div>

                      <div className="border-b border-[#020617] pb-3">
                        <span className="text-[10px] font-mono text-slate-500 block">
                          Sum of first {apG_n} terms (S_{apG_n})
                        </span>
                        <div className="text-2.5xl font-mono font-extrabold text-[#6366f1] break-all leading-tight">
                          {progressionResult.sumN.toLocaleString(undefined, { maximumFractionDigits: 5 })}
                        </div>
                      </div>

                      {progressionType === 'gp' && (
                        <div>
                          <span className="text-[10px] font-mono text-slate-500 block">
                            Sum to infinity (S_∞)
                          </span>
                          <div className="text-xl font-mono font-bold text-pink-400 break-all leading-tight">
                            {typeof progressionResult.sumInfinity === 'number'
                              ? progressionResult.sumInfinity.toLocaleString(undefined, { maximumFractionDigits: 5 })
                              : progressionResult.sumInfinity}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Step-by-Step reasoning log column */}
                <div className="lg:col-span-7 bg-[#020617]/40 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between">
                  <div className="space-y-3">
                    <span className="text-xs font-mono text-slate-300 font-bold uppercase tracking-wider block border-b border-slate-900 pb-2 flex items-center gap-1.5">
                      <Calculator className="w-4 h-4 text-emerald-450" /> Walkthrough & Mathematical Derivation
                    </span>

                    <div className="space-y-3 text-xs font-mono text-slate-350">
                      {progressionResult.steps.map((step, idx) => (
                        <div key={idx} className="flex gap-2.5 items-start">
                          <span className="w-5 h-5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/10 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                            {idx + 1}
                          </span>
                          <p className="leading-relaxed py-0.5 text-slate-300">
                            {step}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Sequence visualization chart / terms preview */}
            {!progressionError && progressionResult && (
              <div className="bg-[#020617]/30 border border-slate-800 p-4 rounded-xl space-y-4">
                <span className="text-xs font-mono text-slate-300 font-bold uppercase tracking-wider block flex items-center gap-1">
                  <Layers className="w-3.5 h-3.5 text-emerald-400" /> Progression trend and terms representation list
                </span>

                <div className="space-y-4">
                  <div className="text-xs font-mono text-slate-400">
                    Terms sequence output (first {Math.min(10, apG_n)} terms):
                  </div>

                  {/* Horizontal boxes representing terms */}
                  <div className="flex flex-wrap gap-2">
                    {progressionResult.listTerms.map((term, i) => (
                      <div
                        key={i}
                        className="bg-slate-900/80 border border-slate-850 hover:border-emerald-500/30 text-center px-3 py-2 rounded-xl text-xs flex flex-col justify-center min-w-[75px]"
                      >
                        <span className="text-slate-500 text-[9px] block mb-0.5">a_{i + 1}</span>
                        <span className="font-semibold text-emerald-300 break-all font-mono">
                          {term.toLocaleString(undefined, { maximumFractionDigits: 4 })}
                        </span>
                      </div>
                    ))}
                    {apG_n > 10 && (
                      <div className="border border-dashed border-slate-800 text-slate-500 text-xs px-4 py-2 rounded-xl flex items-center justify-center">
                        ... and can generate more terms up to {apG_n.toLocaleString()}
                      </div>
                    )}
                  </div>

                  {/* High Quality Simple Growth scale preview representation of growth */}
                  <div className="border-t border-slate-900 pt-4 flex flex-col gap-2">
                    <span className="text-[10px] font-mono text-slate-550 block">Sequence value growth gradient visualization:</span>
                    <div className="h-16 flex items-end justify-between bg-slate-950/60 rounded-xl p-3 border border-slate-900/60 gap-1.5">
                      {progressionResult.listTerms.map((term, i) => {
                        // Compute scaled height percentage
                        const termsVals = progressionResult.listTerms;
                        const minVal = Math.min(...termsVals);
                        const maxVal = Math.max(...termsVals);
                        const diff = maxVal - minVal || 1;
                        const percentage = ((term - minVal) / diff) * 80 + 20; // 20% to 100% range
                        return (
                          <div key={i} className="flex-1 flex flex-col items-center gap-1 group">
                            <div
                              className="w-full bg-gradient-to-t from-emerald-500/10 to-emerald-400/90 rounded-t transition-all group-hover:to-emerald-300 pointer-events-none"
                              style={{ height: `${percentage}%`, minHeight: '4px' }}
                            />
                            <span className="text-[7.5px] text-slate-550 truncate max-w-full font-mono font-medium">#{i+1}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Foundations guide box */}
      <div className="bg-[#020617]/40 border border-slate-800/60 rounded-xl p-4 mt-6 text-[10px] font-mono text-slate-400 space-y-1.5 leading-relaxed">
        <h4 className="text-slate-200 font-sans font-medium flex items-center gap-1.5 text-xs mb-1">
          <HelpCircle className="w-3.5 h-3.5 text-slate-450" /> Structural Mathematical Foundations
        </h4>
        <p>
          • <strong>Derivation vs Integration:</strong> Stencil derivatives resolve high density gradients around a target point, in comparison to the composite area evaluations of the Simpson rule.
        </p>
        <p>
          • <strong>Factorial Speed:</strong> Standard factorials grow at super-exponential speeds ($n!$). Outward cancellations of identical divisions allow our Combinatorics CAS to evaluate quantities that would lock simpler system runtimes.
        </p>
        <p>
          • <strong>Progression Convergence:</strong> Arithmetic sequences list indefinite scalar increases, whereas Geometric Progressions can converge down of infinite totals to concrete points ($S_\infty$) under active ratios ($|r| &lt; 1$).
        </p>
      </div>
    </div>
  );
}
