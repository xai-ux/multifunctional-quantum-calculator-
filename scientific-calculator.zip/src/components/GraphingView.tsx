import { useState, useEffect, useRef, useMemo, MouseEvent as ReactMouseEvent, WheelEvent as ReactWheelEvent, TouchEvent as ReactTouchEvent } from 'react';
import { MathParser } from '../utils/parser';
import { ZoomIn, ZoomOut, RefreshCw, Move, HelpCircle, AlertTriangle } from 'lucide-react';
import { motion } from 'motion/react';

interface GraphingViewProps {
  initialFormula?: string;
}

export default function GraphingView({ initialFormula = 'x^2' }: GraphingViewProps) {
  const [formula, setFormula] = useState(initialFormula);
  const [error, setError] = useState<string | null>(null);
  
  // Coordinate boundaries
  const [range, setRange] = useState({
    xMin: -10,
    xMax: 10,
    yMin: -10,
    yMax: 10,
  });

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Dragging and interaction states
  const isDraggingRef = useRef(false);
  const dragStartRef = useRef({ x: 0, y: 0 });
  const rangeStartRef = useRef({ ...range });

  // Preset expressions for instant plotting
  const PRESETS = [
    { name: 'Parabola', expr: 'x^2 - 4' },
    { name: 'Sine Wave', expr: 'sin(x)' },
    { name: 'Damped Oscillation', expr: 'exp(-0.2*x) * cos(x)' },
    { name: 'Sigmoid Curve', expr: '1 / (1 + exp(-x))' },
    { name: 'Rational Function', expr: 'x / (x^2 - 1)' },
    { name: 'Cubic polynomial', expr: '0.1 * x^3 - x' }
  ];

  // Canvas drawing logic
  const draw = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Get true pixel values for device pixel ratio support
    const width = canvas.width;
    const height = canvas.height;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Coordinate conversion helpers
    const toScreenX = (x: number) => {
      return ((x - range.xMin) / (range.xMax - range.xMin)) * width;
    };
    const toScreenY = (y: number) => {
      return height - ((y - range.yMin) / (range.yMax - range.yMin)) * height;
    };
    const toMathX = (sx: number) => {
      return range.xMin + (sx / width) * (range.xMax - range.xMin);
    };

    // Draw grid lines
    ctx.strokeStyle = '#2d3748'; // grid lines slate
    ctx.lineWidth = 0.5;
    ctx.fillStyle = '#a0aec0'; // tick label color
    ctx.font = '10px JetBrains Mono, monospace';

    // X-grid & labels
    const xStep = calculateFineStep(range.xMin, range.xMax);
    const firstX = Math.ceil(range.xMin / xStep) * xStep;
    for (let x = firstX; x <= range.xMax; x += xStep) {
      if (Math.abs(x) < 1e-10) continue; // skip axis itself
      const sx = toScreenX(x);
      ctx.beginPath();
      ctx.moveTo(sx, 0);
      ctx.lineTo(sx, height);
      ctx.stroke();

      // Label below axis if possible
      const syAxis = Math.max(15, Math.min(height - 15, toScreenY(0)));
      ctx.fillText(Number(x.toFixed(4)).toString(), sx + 4, syAxis - 4);
    }

    // Y-grid & labels
    const yStep = calculateFineStep(range.yMin, range.yMax);
    const firstY = Math.ceil(range.yMin / yStep) * yStep;
    for (let y = firstY; y <= range.yMax; y += yStep) {
      if (Math.abs(y) < 1e-10) continue; // skip axis
      const sy = toScreenY(y);
      ctx.beginPath();
      ctx.moveTo(0, sy);
      ctx.lineTo(width, sy);
      ctx.stroke();

      const sxAxis = Math.max(10, Math.min(width - 40, toScreenX(0)));
      ctx.fillText(Number(y.toFixed(4)).toString(), sxAxis + 4, sy - 4);
    }

    // Draw main axes (X and Y central lines)
    ctx.strokeStyle = '#4a5568'; // axis line
    ctx.lineWidth = 1.5;

    // X axis (y = 0)
    const y0 = toScreenY(0);
    if (y0 >= 0 && y0 <= height) {
      ctx.beginPath();
      ctx.moveTo(0, y0);
      ctx.lineTo(width, y0);
      ctx.stroke();
    }

    // Y axis (x = 0)
    const x0 = toScreenX(0);
    if (x0 >= 0 && x0 <= width) {
      ctx.beginPath();
      ctx.moveTo(x0, 0);
      ctx.lineTo(x0, height);
      ctx.stroke();
    }

    // Evaluate formula and plot the line!
    const parser = new MathParser();
    ctx.beginPath();
    ctx.strokeStyle = '#6366F1'; // Indigo curve accent
    ctx.lineWidth = 2.5;

    let inPath = false;
    let evalErrorOccurred = false;

    // Sample across screen width for maximum smoothness
    for (let sx = 0; sx <= width; sx += 2) {
      const xVal = toMathX(sx);
      try {
        const yVal = parser.evaluate(formula === '' ? '0' : formula.replace(/x/g, `(${xVal})`));
        if (Number.isFinite(yVal)) {
          const sy = toScreenY(yVal);
          if (sy >= -100 && sy <= height + 100) { // Keep drawn points reasonably bound
            if (!inPath) {
              ctx.moveTo(sx, sy);
              inPath = true;
            } else {
              ctx.lineTo(sx, sy);
            }
          } else {
            inPath = false; // Out of boundary
          }
        } else {
          inPath = false; // Discontinuity
        }
      } catch (err) {
        // Silent catch for values out of domain such as sqrt(-x) or 1/(x-1)
        inPath = false; 
        evalErrorOccurred = true;
      }
    }
    ctx.stroke();

    // Verify formula syntax globally once to feedback to UI
    try {
      // test with dummy 1.0
      parser.evaluate(formula === '' ? '0' : formula.replace(/x/g, '(1.0)'));
      if (error && !evalErrorOccurred) setError(null);
    } catch (err: any) {
      if (!error || error !== err.message) {
        setError(err.message + " (Cannot plot cleanly for all domains, but will visualize active points)");
      }
    }
  };

  // Automatically calculate sensible grid spacing based on viewport width
  const calculateFineStep = (min: number, max: number): number => {
    const span = max - min;
    const rawStep = span / 10;
    const magnitude = Math.pow(10, Math.floor(Math.log10(rawStep)));
    const normalized = rawStep / magnitude;

    let step = magnitude;
    if (normalized > 5) {
      step = 5 * magnitude;
    } else if (normalized > 2) {
      step = 2 * magnitude;
    }
    return step;
  };

  // Adjust canvas size when window or containers resize
  const handleResize = () => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const rect = container.getBoundingClientRect();
    // Maintain a 4:3 or responsive widescreen ratio
    const width = rect.width;
    canvas.width = width;
    canvas.height = Math.max(340, width * 0.55); // beautiful widescreen

    draw();
  };

  // Redraw when boundary or formula changes
  useEffect(() => {
    draw();
  }, [range, formula]);

  // Handle resizing observation
  useEffect(() => {
    handleResize();
    const observer = new ResizeObserver(() => handleResize());
    if (containerRef.current) {
      observer.observe(containerRef.current);
    }
    return () => observer.disconnect();
  }, []);

  // Pan interaction
  const handleMouseDown = (e: ReactMouseEvent<HTMLCanvasElement>) => {
    isDraggingRef.current = true;
    dragStartRef.current = { x: e.clientX, y: e.clientY };
    rangeStartRef.current = { ...range };
  };

  const handleMouseMove = (e: ReactMouseEvent<HTMLCanvasElement>) => {
    if (!isDraggingRef.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const dxPix = e.clientX - dragStartRef.current.x;
    const dyPix = e.clientY - dragStartRef.current.y;

    const xSpan = rangeStartRef.current.xMax - rangeStartRef.current.xMin;
    const ySpan = rangeStartRef.current.yMax - rangeStartRef.current.yMin;

    const mathDx = (dxPix / canvas.width) * xSpan;
    const mathDy = (dyPix / canvas.height) * ySpan;

    setRange({
      xMin: rangeStartRef.current.xMin - mathDx,
      xMax: rangeStartRef.current.xMax - mathDx,
      yMin: rangeStartRef.current.yMin + mathDy,
      yMax: rangeStartRef.current.yMax + mathDy,
    });
  };

  const stopDragging = () => {
    isDraggingRef.current = false;
  };

  // Zooms around the center point of the current view
  const adjustZoom = (factor: number) => {
    const xCenter = (range.xMin + range.xMax) / 2;
    const yCenter = (range.yMin + range.yMax) / 2;
    const xSpan = (range.xMax - range.xMin) * factor;
    const ySpan = (range.yMax - range.yMin) * factor;

    setRange({
      xMin: xCenter - xSpan / 2,
      xMax: xCenter + xSpan / 2,
      yMin: yCenter - ySpan / 2,
      yMax: yCenter + ySpan / 2,
    });
  };

  const resetZoom = () => {
    setRange({
      xMin: -10,
      xMax: 10,
      yMin: -10,
      yMax: 10,
    });
  };

  return (
    <div className="flex flex-col gap-4 text-gray-200">
      <div className="bg-[#0F172A] border border-slate-800 rounded-2xl p-5 shadow-2.5xl">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 mb-4">
          <div>
            <h3 className="text-lg font-semibold text-slate-100 flex items-center gap-2 font-sans tracking-tight">
              <span>Interactive Graphing Tool</span>
              <span className="text-xs font-mono font-medium text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-full">
                Live Rendering
              </span>
            </h3>
            <p className="text-xs text-slate-400">Plot mathematical functions in standard Cartesian coordinates</p>
          </div>
          <div className="flex items-center gap-1.5 self-end sm:self-auto bg-[#020617] p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => adjustZoom(0.8)}
              className="p-2 hover:bg-slate-800 text-slate-300 rounded-lg transition-colors"
              title="Zoom In"
              id="graph_zoom_in"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={() => adjustZoom(1.2)}
              className="p-2 hover:bg-slate-800 text-slate-300 rounded-lg transition-colors"
              title="Zoom Out"
              id="graph_zoom_out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button
              onClick={resetZoom}
              className="p-2 hover:bg-slate-800 text-slate-300 rounded-lg transition-colors"
              title="Reset Zoom"
              id="graph_zoom_reset"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Input formula block */}
        <div className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <span className="absolute left-3.5 top-2.5 font-mono text-sm text-[#6366F1] font-semibold">f(x) =</span>
            <input
              type="text"
              value={formula}
              onChange={(e) => setFormula(e.target.value)}
              className="w-full bg-[#020617] border border-slate-800 hover:border-slate-700 focus:border-indigo-500/50 rounded-xl pl-16 pr-4 py-2 text-sm font-mono text-slate-100 outline-none transition-colors"
              placeholder="e.g. sin(x) + cos(2*x)"
              id="graph_formula_input"
            />
          </div>
        </div>

        {/* Preset quick links */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {PRESETS.map((p, idx) => (
            <button
              key={idx}
              onClick={() => {
                setFormula(p.expr);
                resetZoom();
              }}
              className="text-[11px] font-mono bg-slate-800/60 hover:bg-[#6366F1]/10 hover:text-[#6366F1] text-slate-400 px-2.5 py-1 rounded-lg border border-slate-800/40 transition-all hover:border-[#6366F1]/20"
              id={`preset_${idx}`}
            >
              {p.name}
            </button>
          ))}
        </div>

        {/* Graph canvas container */}
        <div 
          ref={containerRef} 
          className="relative bg-[#020617] border border-slate-800 rounded-xl overflow-hidden cursor-crosshair select-none"
        >
          <canvas
            ref={canvasRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={stopDragging}
            onMouseLeave={stopDragging}
            className="block w-full"
            id="graph_canvas"
          />

          {/* Prompt overlays */}
          <div className="absolute right-3.5 bottom-3 text-[10px] font-mono text-slate-500 flex items-center gap-1.5 bg-[#0F172A]/85 px-2.5 py-1 rounded-md border border-slate-800/50 backdrop-blur-md">
            <Move className="w-3 h-3 text-[#6366F1]" />
            <span>Drag / Pan to explore curves</span>
          </div>

          <div className="absolute left-3.5 bottom-3 text-[10px] font-mono text-slate-500 flex items-center gap-1.5 bg-[#0F172A]/85 px-2.5 py-1 rounded-md border border-slate-800/50 backdrop-blur-md">
            <span>Range: X[{range.xMin.toFixed(1)} to {range.xMax.toFixed(1)}] Y[{range.yMin.toFixed(1)} to {range.yMax.toFixed(1)}]</span>
          </div>
        </div>

        {/* Warning panel */}
        {error && (
          <div className="mt-3.5 flex items-start gap-2.5 bg-yellow-500/5 border border-yellow-500/20 rounded-xl p-3 text-xs text-yellow-250/90 font-mono">
            <AlertTriangle className="w-4 h-4 text-yellow-550 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* Guide section below graph */}
      <div className="bg-[#0F172A]/30 border border-slate-805 rounded-xl p-4 text-xs text-slate-450 font-mono space-y-2">
        <h4 className="text-slate-200 font-sans font-medium flex items-center gap-1.5 text-xs">
          <HelpCircle className="w-3.5 h-3.5 text-slate-400" /> Plot Syntax Reference
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-1.5 ml-1">
          <div>• Exponential power is written as <code className="text-[#6366F1]">^</code> (e.g., <code className="text-slate-300">x^2</code>)</div>
          <div>• Implicit division: can write <code className="text-slate-300">x / (x - 2)</code></div>
          <div>• Trigonometry: support <code className="text-slate-300">sin(...)</code>, <code className="text-slate-300">cos(...)</code>, <code className="text-slate-300">tan(...)</code></div>
          <div>• Natural logarithm: use <code className="text-[#6366F1]">ln(x)</code>, base 10: <code className="text-[#6366F1]">log(x)</code></div>
          <div>• Exponentials: e.g. <code className="text-slate-300">exp(-x)</code> or absolute values: <code className="text-slate-300">abs(x)</code></div>
          <div>• Constants: e.g. <code className="text-slate-300">pi</code> and <code className="text-slate-300">e</code></div>
        </div>
      </div>
    </div>
  );
}
