import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Copy, Check, ExternalLink, Smartphone, Monitor, Apple, Globe, X } from 'lucide-react';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [copiedLink, setCopiedLink] = useState<'shared' | 'dev' | null>(null);

  if (!isOpen) return null;

  const sharedUrl = 'https://ais-pre-pzw3oyqmwsfzlfnvosjtbn-756751993499.asia-southeast1.run.app';
  const devUrl = 'https://ais-dev-pzw3oyqmwsfzlfnvosjtbn-756751993499.asia-southeast1.run.app';

  const copyToClipboard = (text: string, type: 'shared' | 'dev') => {
    navigator.clipboard.writeText(text);
    setCopiedLink(type);
    setTimeout(() => setCopiedLink(null), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg bg-[#0F172A] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#1E293B]/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#6366F1] to-cyan-400 flex items-center justify-center shadow-md">
              <Download className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                Download & Access Platform
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  PWA Ready
                </span>
              </h2>
              <p className="text-xs text-slate-400">Install as native desktop/mobile app or copy web links</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* 1-Click Install Button if installable */}
          {isInstallable && (
            <div className="p-4 rounded-xl bg-gradient-to-r from-indigo-950/60 to-slate-900 border border-indigo-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                  <Monitor className="w-4 h-4 text-indigo-400" />
                  Install Standalone App
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Launch full screen without browser bars, with instant offline caching.
                </p>
              </div>
              <button
                onClick={async () => {
                  await install();
                }}
                className="w-full sm:w-auto px-5 py-2.5 bg-gradient-to-r from-[#6366F1] to-indigo-600 hover:from-indigo-500 hover:to-indigo-700 text-white text-xs font-bold rounded-xl shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-2 transition-all active:scale-95 whitespace-nowrap"
              >
                <Download className="w-4 h-4" />
                Install Now
              </button>
            </div>
          )}

          {isInstalled && (
            <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 flex items-center gap-3 text-xs text-emerald-300">
              <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>Platform is currently running as an installed standalone Progressive Web App!</span>
            </div>
          )}

          {/* Direct Platform Links */}
          <div className="space-y-3">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-2">
              <Globe className="w-3.5 h-3.5 text-indigo-400" />
              Direct Platform Links
            </label>

            {/* Shared Public App URL */}
            <div className="p-3 bg-[#020617] border border-slate-800 rounded-xl space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-slate-300">Shared Application Link</span>
                <span className="text-[10px] text-emerald-400 font-mono bg-emerald-500/10 px-1.5 py-0.5 rounded">Production Ready</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={sharedUrl}
                  className="w-full bg-[#0F172A] border border-slate-700/60 rounded-lg px-3 py-1.5 text-xs text-slate-300 font-mono focus:outline-none select-all"
                />
                <button
                  onClick={() => copyToClipboard(sharedUrl, 'shared')}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg flex items-center gap-1.5 transition-colors whitespace-nowrap border border-slate-700"
                  title="Copy link"
                >
                  {copiedLink === 'shared' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedLink === 'shared' ? 'Copied' : 'Copy'}
                </button>
                <a
                  href={sharedUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 rounded-lg border border-indigo-500/30 transition-colors"
                  title="Open in new tab"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            {/* Development Workspace URL */}
            <div className="p-3 bg-[#020617] border border-slate-800 rounded-xl space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-slate-300">Development Server Link</span>
                <span className="text-[10px] text-indigo-400 font-mono bg-indigo-500/10 px-1.5 py-0.5 rounded">Live Dev</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={devUrl}
                  className="w-full bg-[#0F172A] border border-slate-700/60 rounded-lg px-3 py-1.5 text-xs text-slate-300 font-mono focus:outline-none select-all"
                />
                <button
                  onClick={() => copyToClipboard(devUrl, 'dev')}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg flex items-center gap-1.5 transition-colors whitespace-nowrap border border-slate-700"
                  title="Copy link"
                >
                  {copiedLink === 'dev' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedLink === 'dev' ? 'Copied' : 'Copy'}
                </button>
                <a
                  href={devUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 rounded-lg border border-indigo-500/30 transition-colors"
                  title="Open in new tab"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>

          {/* Installation Instructions by Platform */}
          <div className="space-y-3">
            <label className="text-xs font-semibold text-slate-300">How to Install on Your Device</label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Chrome / Edge (Desktop) */}
              <div className="p-3 bg-[#020617] rounded-xl border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-1.5 text-indigo-400 font-semibold text-xs">
                  <Monitor className="w-3.5 h-3.5" />
                  <span>Desktop (PC/Mac)</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  In Chrome or Edge, click the <strong>Install</strong> icon in the address bar (or menu &gt; <em>Install Quantum Scientific</em>).
                </p>
              </div>

              {/* Android */}
              <div className="p-3 bg-[#020617] rounded-xl border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-1.5 text-emerald-400 font-semibold text-xs">
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Android</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Tap the three dots (⋮) in Chrome, then tap <strong>Add to Home screen</strong> or <strong>Install app</strong>.
                </p>
              </div>

              {/* iOS Safari */}
              <div className="p-3 bg-[#020617] rounded-xl border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-1.5 text-sky-400 font-semibold text-xs">
                  <Apple className="w-3.5 h-3.5" />
                  <span>iPhone / iPad</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Tap the <strong>Share</strong> button (box with arrow) in Safari, scroll down and tap <strong>Add to Home Screen</strong>.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-[#020617] border-t border-slate-800 flex items-center justify-between">
          <span className="text-[11px] text-slate-400">Offline-capable Progressive Web Application</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
