import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download } from 'lucide-react';
import { DownloadModal } from './DownloadModal';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, install } = usePWAInstall();
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => {
          if (isInstallable) {
            install();
          } else {
            setIsModalOpen(true);
          }
        }}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white shadow-md shadow-indigo-500/20 border border-indigo-400/30 transition-all active:scale-95 whitespace-nowrap cursor-pointer"
        title="Download / Install App & Access Links"
      >
        <Download className="w-3.5 h-3.5 text-indigo-100" />
        <span>Download / Install</span>
      </button>

      <DownloadModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
};
