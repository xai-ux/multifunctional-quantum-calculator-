export interface ShapeInfo {
  id: string;
  name: string;
  category: '2d' | '3d';
  subCategory: string;
  inputs: { key: string; label: string; symbol: string; defaultValue: number; placeholder: string }[];
}

export const SHAPES_LIST: ShapeInfo[] = [
  // 2D Shapes (Stanza 1)
  {
    id: 'tri_equilateral',
    name: 'Equilateral Triangle',
    category: '2d',
    subCategory: 'Triangles',
    inputs: [{ key: 'side', label: 'Side Length (a)', symbol: 'a', defaultValue: 6, placeholder: 'Enter side length' }]
  },
  {
    id: 'tri_isosceles',
    name: 'Isosceles Triangle',
    category: '2d',
    subCategory: 'Triangles',
    inputs: [
      { key: 'side', label: 'Equal Side (a)', symbol: 'a', defaultValue: 8, placeholder: 'Equal side side' },
      { key: 'base', label: 'Base Length (b)', symbol: 'b', defaultValue: 10, placeholder: 'Base length' }
    ]
  },
  {
    id: 'tri_scalene',
    name: 'Scalene Triangle',
    category: '2d',
    subCategory: 'Triangles',
    inputs: [
      { key: 'sideA', label: 'Side a', symbol: 'a', defaultValue: 6, placeholder: 'Side a size' },
      { key: 'sideB', label: 'Side b', symbol: 'b', defaultValue: 8, placeholder: 'Side b size' },
      { key: 'sideC', label: 'Side c', symbol: 'c', defaultValue: 10, placeholder: 'Side c size' }
    ]
  },
  {
    id: 'tri_right',
    name: 'Right-Angled Triangle',
    category: '2d',
    subCategory: 'Triangles',
    inputs: [
      { key: 'base', label: 'Base Leg (a)', symbol: 'a', defaultValue: 6, placeholder: 'Base leg' },
      { key: 'height', label: 'Height Leg (b)', symbol: 'b', defaultValue: 8, placeholder: 'Height leg' }
    ]
  },
  {
    id: 'tri_acute',
    name: 'Acute-Angled Triangle',
    category: '2d',
    subCategory: 'Triangles',
    inputs: [
      { key: 'sideA', label: 'Side a', symbol: 'a', defaultValue: 5, placeholder: 'Side a Size' },
      { key: 'sideB', label: 'Side b', symbol: 'b', defaultValue: 6, placeholder: 'Side b Size' },
      { key: 'sideC', label: 'Side c', symbol: 'c', defaultValue: 7, placeholder: 'Side c Size' }
    ]
  },
  {
    id: 'tri_obtuse',
    name: 'Obtuse-Angled Triangle',
    category: '2d',
    subCategory: 'Triangles',
    inputs: [
      { key: 'sideA', label: 'Side a', symbol: 'a', defaultValue: 5, placeholder: 'Side a Size' },
      { key: 'sideB', label: 'Side b', symbol: 'b', defaultValue: 6, placeholder: 'Side b Size' },
      { key: 'sideC', label: 'Side c', symbol: 'c', defaultValue: 10, placeholder: 'Side c Size' }
    ]
  },
  {
    id: 'tri_right_isosceles',
    name: 'Right-Angled Isosceles Triangle',
    category: '2d',
    subCategory: 'Triangles',
    inputs: [
      { key: 'leg', label: 'Equal Leg (a)', symbol: 'a', defaultValue: 5, placeholder: 'Leg size' }
    ]
  },
  {
    id: 'tri_right_scalene',
    name: 'Right-Angled Scalene Triangle',
    category: '2d',
    subCategory: 'Triangles',
    inputs: [
      { key: 'base', label: 'Base Leg (a)', symbol: 'a', defaultValue: 3, placeholder: 'Base leg' },
      { key: 'height', label: 'Height Leg (b)', symbol: 'b', defaultValue: 4, placeholder: 'Height leg' }
    ]
  },
  {
    id: 'quad_square',
    name: 'Square',
    category: '2d',
    subCategory: 'Quadrilaterals',
    inputs: [{ key: 'side', label: 'Side size (s)', symbol: 's', defaultValue: 6, placeholder: 'Side length' }]
  },
  {
    id: 'quad_rectangle',
    name: 'Rectangle',
    category: '2d',
    subCategory: 'Quadrilaterals',
    inputs: [
      { key: 'length', label: 'Length (l)', symbol: 'l', defaultValue: 8, placeholder: 'Length dimension' },
      { key: 'width', label: 'Width (w)', symbol: 'w', defaultValue: 5, placeholder: 'Width dimension' }
    ]
  },
  {
    id: 'quad_parallelogram',
    name: 'Parallelogram',
    category: '2d',
    subCategory: 'Quadrilaterals',
    inputs: [
      { key: 'base', label: 'Base (b)', symbol: 'b', defaultValue: 8, placeholder: 'Base size' },
      { key: 'side', label: 'Slant Side (a)', symbol: 'a', defaultValue: 6, placeholder: 'Slant side' },
      { key: 'theta', label: 'Acute Angle (θ)', symbol: 'θ', defaultValue: 60, placeholder: 'Angle in degrees' }
    ]
  },
  {
    id: 'quad_rhombus',
    name: 'Rhombus',
    category: '2d',
    subCategory: 'Quadrilaterals',
    inputs: [
      { key: 'side', label: 'Side size (s)', symbol: 's', defaultValue: 6, placeholder: 'Rhombus sides' },
      { key: 'theta', label: 'Acute Angle (θ)', symbol: 'θ', defaultValue: 60, placeholder: 'Angle in degrees' }
    ]
  },
  {
    id: 'quad_trapezoid',
    name: 'Trapezoid / Trapezium',
    category: '2d',
    subCategory: 'Quadrilaterals',
    inputs: [
      { key: 'baseA', label: 'Bottom Base (a)', symbol: 'a', defaultValue: 8, placeholder: 'Bottom base limit' },
      { key: 'baseB', label: 'Top Base (b)', symbol: 'b', defaultValue: 5, placeholder: 'Top base limit' },
      { key: 'sideC', label: 'Left Side (c)', symbol: 'c', defaultValue: 4, placeholder: 'Left side size' },
      { key: 'sideD', label: 'Right Side (d)', symbol: 'd', defaultValue: 4, placeholder: 'Right side size' },
      { key: 'height', label: 'Height (h)', symbol: 'h', defaultValue: 3.5, placeholder: 'Altitude bounds' }
    ]
  },
  {
    id: 'quad_kite',
    name: 'Kite',
    category: '2d',
    subCategory: 'Quadrilaterals',
    inputs: [
      { key: 'sideA', label: 'Short Sides (a)', symbol: 'a', defaultValue: 5, placeholder: 'Short side dimension' },
      { key: 'sideB', label: 'Long Sides (b)', symbol: 'b', defaultValue: 8, placeholder: 'Long side dimension' },
      { key: 'diag1', label: 'Horiz Diagonal (d1)', symbol: 'd1', defaultValue: 6, placeholder: 'Horiz diagonal axis' },
      { key: 'diag2', label: 'Vert Diagonal (d2)', symbol: 'd2', defaultValue: 10, placeholder: 'Vert diagonal axis' }
    ]
  },
  {
    id: 'poly_pentagon',
    name: 'Regular Pentagon',
    category: '2d',
    subCategory: 'Higher Polygons',
    inputs: [{ key: 'side', label: 'Side Length (s)', symbol: 's', defaultValue: 6, placeholder: 'Side length' }]
  },
  {
    id: 'poly_hexagon',
    name: 'Regular Hexagon',
    category: '2d',
    subCategory: 'Higher Polygons',
    inputs: [{ key: 'side', label: 'Side Length (s)', symbol: 's', defaultValue: 6, placeholder: 'Side length' }]
  },
  {
    id: 'poly_heptagon',
    name: 'Regular Heptagon',
    category: '2d',
    subCategory: 'Higher Polygons',
    inputs: [{ key: 'side', label: 'Side Length (s)', symbol: 's', defaultValue: 6, placeholder: 'Side length' }]
  },
  {
    id: 'poly_octagon',
    name: 'Regular Octagon',
    category: '2d',
    subCategory: 'Higher Polygons',
    inputs: [{ key: 'side', label: 'Side Length (s)', symbol: 's', defaultValue: 6, placeholder: 'Side length' }]
  },
  {
    id: 'poly_nonagon',
    name: 'Regular Nonagon',
    category: '2d',
    subCategory: 'Higher Polygons',
    inputs: [{ key: 'side', label: 'Side Length (s)', symbol: 's', defaultValue: 6, placeholder: 'Side length' }]
  },
  {
    id: 'poly_decagon',
    name: 'Regular Decagon',
    category: '2d',
    subCategory: 'Higher Polygons',
    inputs: [{ key: 'side', label: 'Side Length (s)', symbol: 's', defaultValue: 6, placeholder: 'Side length' }]
  },
  {
    id: 'curve_circle',
    name: 'Circle',
    category: '2d',
    subCategory: 'Curved 2D Shapes',
    inputs: [{ key: 'radius', label: 'Radius (r)', symbol: 'r', defaultValue: 7, placeholder: 'Radius size' }]
  },
  {
    id: 'curve_semicircle',
    name: 'Semicircle',
    category: '2d',
    subCategory: 'Curved 2D Shapes',
    inputs: [{ key: 'radius', label: 'Radius (r)', symbol: 'r', defaultValue: 7, placeholder: 'Radius size' }]
  },
  {
    id: 'curve_ellipse',
    name: 'Oval / Ellipse',
    category: '2d',
    subCategory: 'Curved 2D Shapes',
    inputs: [
      { key: 'semiA', label: 'Semi-Major axis (a)', symbol: 'a', defaultValue: 8, placeholder: 'Major semi-axis' },
      { key: 'semiB', label: 'Semi-Minor axis (b)', symbol: 'b', defaultValue: 5, placeholder: 'Minor semi-axis' }
    ]
  },
  {
    id: 'curve_parabola',
    name: 'Parabola Curve',
    category: '2d',
    subCategory: 'Curved 2D Shapes',
    inputs: [
      { key: 'paramA', label: 'Curvature (a) [y = ax²]', symbol: 'a', defaultValue: 0.25, placeholder: 'Curvature scale' },
      { key: 'height', label: 'Segment Height (h)', symbol: 'h', defaultValue: 4, placeholder: 'Parabolic segment depth' }
    ]
  },
  {
    id: 'curve_hyperbola',
    name: 'Hyperbola Curve',
    category: '2d',
    subCategory: 'Curved 2D Shapes',
    inputs: [
      { key: 'semiA', label: 'Semi-Major axis (a)', symbol: 'a', defaultValue: 4, placeholder: 'Major axis' },
      { key: 'semiB', label: 'Semi-Minor axis (b)', symbol: 'b', defaultValue: 3, placeholder: 'Minor axis' }
    ]
  },

  // 3D Figures (Stanza 1)
  {
    id: 'solid_cube',
    name: 'Cube',
    category: '3d',
    subCategory: 'Polyhedrons (Flat Faces)',
    inputs: [{ key: 'side', label: 'Edge size (s)', symbol: 's', defaultValue: 6, placeholder: 'Edge depth' }]
  },
  {
    id: 'solid_cuboid',
    name: 'Cuboid / Rectangular Prism',
    category: '3d',
    subCategory: 'Polyhedrons (Flat Faces)',
    inputs: [
      { key: 'length', label: 'Length (l)', symbol: 'l', defaultValue: 8, placeholder: 'Length bounds' },
      { key: 'width', label: 'Width (w)', symbol: 'w', defaultValue: 5, placeholder: 'Width bounds' },
      { key: 'height', label: 'Height (h)', symbol: 'h', defaultValue: 6, placeholder: 'Height bounds' }
    ]
  },
  {
    id: 'solid_triprism',
    name: 'Triangular Prism',
    category: '3d',
    subCategory: 'Polyhedrons (Flat Faces)',
    inputs: [
      { key: 'sideA', label: 'Base side a', symbol: 'a', defaultValue: 6, placeholder: 'Base side a' },
      { key: 'sideB', label: 'Base side b', symbol: 'b', defaultValue: 6, placeholder: 'Base side b' },
      { key: 'sideC', label: 'Base side c', symbol: 'c', defaultValue: 6, placeholder: 'Base side c' },
      { key: 'height', label: 'Prism Length (L)', symbol: 'h', defaultValue: 10, placeholder: 'Prism length' }
    ]
  },
  {
    id: 'solid_pyramid',
    name: 'Pyramid (Square Base)',
    category: '3d',
    subCategory: 'Polyhedrons (Flat Faces)',
    inputs: [
      { key: 'base', label: 'Base Edge (a)', symbol: 'a', defaultValue: 6, placeholder: 'Base side' },
      { key: 'height', label: 'Altitude (h)', symbol: 'h', defaultValue: 8, placeholder: 'Pyramid height' }
    ]
  },
  {
    id: 'solid_sphere',
    name: 'Sphere',
    category: '3d',
    subCategory: 'Curved Solids',
    inputs: [{ key: 'radius', label: 'Radius (r)', symbol: 'r', defaultValue: 5, placeholder: 'Sphere radius' }]
  },
  {
    id: 'solid_cylinder',
    name: 'Cylinder',
    category: '3d',
    subCategory: 'Curved Solids',
    inputs: [
      { key: 'radius', label: 'Caps Radius (r)', symbol: 'r', defaultValue: 4, placeholder: 'Terminal radius' },
      { key: 'height', label: 'Height (h)', symbol: 'h', defaultValue: 9, placeholder: 'Cylinder height' }
    ]
  },
  {
    id: 'solid_cone',
    name: 'Cone',
    category: '3d',
    subCategory: 'Curved Solids',
    inputs: [
      { key: 'radius', label: 'Base Radius (r)', symbol: 'r', defaultValue: 6, placeholder: 'Base radius' },
      { key: 'height', label: 'Height (h)', symbol: 'h', defaultValue: 8, placeholder: 'Cone axis height' }
    ]
  },
  {
    id: 'solid_torus',
    name: 'Torus',
    category: '3d',
    subCategory: 'Curved Solids',
    inputs: [
      { key: 'majorR', label: 'Ring Radius (R)', symbol: 'R', defaultValue: 8, placeholder: 'Torus center to tube center' },
      { key: 'minorR', label: 'Tube Radius (r)', symbol: 'r', defaultValue: 2, placeholder: 'Inner tube radius' }
    ]
  },
  {
    id: 'plat_tetrahedron',
    name: 'Tetrahedron (4 Faces)',
    category: '3d',
    subCategory: 'Platonic Solids',
    inputs: [{ key: 'edge', label: 'Edge size (a)', symbol: 'a', defaultValue: 6, placeholder: 'Edge length' }]
  },
  {
    id: 'plat_octahedron',
    name: 'Octahedron (8 Faces)',
    category: '3d',
    subCategory: 'Platonic Solids',
    inputs: [{ key: 'edge', label: 'Edge size (a)', symbol: 'a', defaultValue: 6, placeholder: 'Edge length' }]
  },
  {
    id: 'plat_icosahedron',
    name: 'Icosahedron (20 Faces)',
    category: '3d',
    subCategory: 'Platonic Solids',
    inputs: [{ key: 'edge', label: 'Edge size (a)', symbol: 'a', defaultValue: 6, placeholder: 'Edge length' }]
  },
  {
    id: 'plat_dodecahedron',
    name: 'Dodecahedron (12 Faces)',
    category: '3d',
    subCategory: 'Platonic Solids',
    inputs: [{ key: 'edge', label: 'Edge size (a)', symbol: 'a', defaultValue: 6, placeholder: 'Edge length' }]
  }
];

export interface CalculationResult {
  result: number;
  steps: { title: string; detail: string }[];
  formulaTex: string;
}

// Global calculation function solving ANY chosen Stanza 2 metric for ANY active shape!
export function solveGeometry(
  shapeId: string,
  calcKey: string,
  rawVals: Record<string, string>
): CalculationResult {
  // Extract clean number values
  const v: Record<string, number> = {};
  const shape = SHAPES_LIST.find((s) => s.id === shapeId) || SHAPES_LIST[0];
  shape.inputs.forEach((inp) => {
    v[inp.key] = parseFloat(rawVals[inp.key]) || inp.defaultValue;
  });

  const steps: { title: string; detail: string }[] = [];
  let result = 0;
  let formulaTex = 'N/A';

  const registerResult = (resVal: number, fTex: string, title: string, detail: string) => {
    result = resVal;
    formulaTex = fTex;
    steps.push({ title, detail });
  };

  steps.push({
    title: 'Initialize Parameters',
    detail: `Evaluating dimensions for ${shape.name}: ` + shape.inputs.map((inp) => `${inp.symbol} = ${v[inp.key]}`).join(', ')
  });

  switch (shapeId) {
    // ----------------------------------------------------
    // TRIANGLES
    // ----------------------------------------------------
    case 'tri_equilateral': {
      const a = v.side;
      if (calcKey === 'area') {
        const val = (Math.sqrt(3) / 4) * a * a;
        registerResult(val, 'A = (\\sqrt{3} / 4) \\times a^2', 'Area Calculation', `A = (1.73205 / 4) * ${a}^2 = 0.43301 * ${a*a} = ${val.toFixed(4)}`);
      } else if (calcKey === 'perimeter' || calcKey === 'circumference') {
        registerResult(3 * a, 'P = 3 \\times a', 'Perimeter Calculation', `P = 3 * ${a} = ${3*a}`);
      } else if (calcKey === 'interior_angles') {
        registerResult(60, '\\theta_i = 60^\\circ', 'Interior Angles', `Each interior angle of any equilateral triangle is always exactly 60° (sum = 180°).`);
      } else if (calcKey === 'exterior_angles') {
        registerResult(120, '\\theta_e = 120^\\circ', 'Exterior Angles', `Each exterior angle is 180° - 60° = 120° (sum = 360°).`);
      } else if (calcKey === 'diagonal_length') {
        const h = (Math.sqrt(3) / 2) * a;
        registerResult(h, 'h_d = (\\sqrt{3} / 2) \\times a', 'Altitude as Diagonal Equivalent', `h_d = 0.86603 * ${a} = ${h.toFixed(4)}`);
      } else if (calcKey === 'radius') {
        const R = a / Math.sqrt(3);
        registerResult(R, 'R = a / \\sqrt{3}', 'Circumradius (R)', `R = ${a} / 1.73205 = ${R.toFixed(4)}`);
      } else if (calcKey === 'diameter') {
        const D = (2 * a) / Math.sqrt(3);
        registerResult(D, 'D = 2a / \\sqrt{3}', 'Circumdiameter (D)', `D = 2 * ${a} / 1.73205 = ${D.toFixed(4)}`);
      } else if (calcKey === 'apothem') {
        const r = a / (2 * Math.sqrt(3));
        registerResult(r, 'r = a / (2\\sqrt{3})', 'Apothem / Inradius (r)', `r = ${a} / 3.4641 = ${r.toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        const c = a / (2 * Math.sqrt(3));
        registerResult(c, 'y_c = a / (2\\sqrt{3})', 'Centroid Axis Distance', `Located along index symmetry axes exactly ${c.toFixed(4)} units vertically from the base.`);
      } else if (calcKey === 'moment_of_inertia') {
        const I = (Math.sqrt(3) / 96) * Math.pow(a, 4);
        registerResult(I, 'I_c = (\\sqrt{3}/96) \\times a^4', 'Second Moment of Area', `I_c = 0.01804 * ${a}^4 = 0.01804 * ${Math.pow(a, 4)} = ${I.toFixed(4)}`);
      } else {
        const r = 3 / ((Math.sqrt(3)/4)*a);
        registerResult(r, 'P/A = 12 / (\\sqrt{3}a)', 'Perimeter-to-Area ratio', `P/A = 12 / (1.73205 * ${a}) = ${r.toFixed(4)}`);
      }
      break;
    }

    case 'tri_isosceles': {
      const a = v.side;
      const b = v.base;
      const hRad = 4*a*a - b*b;
      const h = hRad > 0 ? Math.sqrt(hRad) / 2 : 0;
      const area = 0.5 * b * h;

      if (calcKey === 'area') {
        registerResult(area, 'A = (b / 4) \\times \\sqrt{4a^2 - b^2}', 'Area Calculation', `A = (${b}/4) * \\sqrt{4*${a*a} - ${b*b}} = ${b/4} * \\sqrt{${hRad}} = ${area.toFixed(4)}`);
      } else if (calcKey === 'perimeter' || calcKey === 'circumference') {
        registerResult(2*a + b, 'P = 2a + b', 'Perimeter calculation', `P = 2*${a} + ${b} = ${2*a+b}`);
      } else if (calcKey === 'interior_angles') {
        const beta = Math.acos(Math.min(1, Math.max(-1, b / (2*a)))) * (180 / Math.PI);
        const alpha = 180 - 2 * beta;
        registerResult(alpha, '\\alpha = 180^\\circ - 2\\beta', 'Angles: Base vs Vertex', `Common Base angle \\beta = ${beta.toFixed(2)}°, Vertex angle \\alpha = ${alpha.toFixed(2)}° (sum = 180°).`);
      } else if (calcKey === 'exterior_angles') {
        const beta = Math.acos(Math.min(1, Math.max(-1, b / (2*a)))) * (180 / Math.PI);
        const alpha = 180 - 2 * beta;
        registerResult(180 - alpha, '\\delta_{ext} = 180^\\circ - \\alpha', 'Vertex Exterior Angle', `Vertex ext = ${(180-alpha).toFixed(2)}°, Base ext = ${(180-beta).toFixed(2)}° (sum = 360°).`);
      } else if (calcKey === 'diagonal_length') {
        registerResult(h, 'h_d = \\sqrt{a^2 - b^2 / 4}', 'Pythagorean Altitude', `h = \\sqrt{${a*a} - ${b*b/4}} = ${h.toFixed(4)}`);
      } else if (calcKey === 'radius') {
        const R = area > 0 ? (a*a*b) / (4*area) : 0;
        registerResult(R, 'R = a^2b / 4A', 'Circumradius (R)', `R = ${a*a}*${b} / ${(4*area).toFixed(2)} = ${R.toFixed(4)}`);
      } else if (calcKey === 'diameter') {
        const R = area > 0 ? (a*a*b) / (4*area) : 0;
        registerResult(2*R, 'D = 2R', 'Diameter (D)', `D = 2 * ${R.toFixed(4)} = ${(2*R).toFixed(4)}`);
      } else if (calcKey === 'apothem') {
        const P = 2*a + b;
        const r = P > 0 ? (2*area) / P : 0;
        registerResult(r, 'r = 2A / P', 'Inradius (r)', `Inscribed radius r = 2*${area.toFixed(2)} / ${P} = ${r.toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        registerResult(h/3, 'y_c = h / 3', 'Centroid Axis', `Located at h/3 = ${h.toFixed(3)}/3 = ${(h/3).toFixed(4)} units vertically from bases.`);
      } else if (calcKey === 'moment_of_inertia') {
        const I = (b * Math.pow(h, 3)) / 36;
        registerResult(I, 'I = bh^3 / 36', 'Centroid Area Inertia', `I = ${b} * ${h.toFixed(2)}^3 / 36 = ${I.toFixed(4)}`);
      } else {
        const P = 2*a + b;
        const ratio = area > 0 ? P / area : 0;
        registerResult(ratio, 'P/A', 'Perimeter/Area index', `P/A = ${P} / ${area.toFixed(3)} = ${ratio.toFixed(4)}`);
      }
      break;
    }

    case 'tri_scalene': {
      const a = v.sideA;
      const b = v.sideB;
      const c = v.sideC;
      const s = (a + b + c) / 2;
      const ra = s * (s - a) * (s - b) * (s - c);
      const area = ra > 0 ? Math.sqrt(ra) : 0;

      if (calcKey === 'area') {
        registerResult(area, 'A = \\sqrt{s(s-a)(s-b)(s-c)}', "Heron\'s Area Solver", `Semiperimeter s = ${s}. Radicand = ${ra}. Area = ${area.toFixed(4)}`);
      } else if (calcKey === 'perimeter' || calcKey === 'circumference') {
        registerResult(a+b+c, 'P = a + b + c', 'Perimeter', `P = ${a} + ${b} + ${c} = ${a+b+c}`);
      } else if (calcKey === 'interior_angles') {
        const alpha = Math.acos(Math.min(1, Math.max(-1, (b*b + c*c - a*a) / (2*b*c)))) * (180/Math.PI);
        const beta = Math.acos(Math.min(1, Math.max(-1, (a*a + c*c - b*b) / (2*a*c)))) * (180/Math.PI);
        const gamma = 180 - alpha - beta;
        registerResult(alpha, '\\alpha = \\arccos((b^2+c^2-a^2)/2bc)', 'Interior angles', `\\alpha = ${alpha.toFixed(2)}°, \\beta = ${beta.toFixed(2)}°, \\gamma = ${gamma.toFixed(2)}° (sum = 180°).`);
      } else if (calcKey === 'exterior_angles') {
        const alpha = Math.acos(Math.min(1, Math.max(-1, (b*b + c*c - a*a) / (2*b*c)))) * (180/Math.PI);
        registerResult(180-alpha, '\\theta_{e,a} = 180^\\circ - \\alpha', 'First Exterior Angle', `Exterior angles are: ${(180-alpha).toFixed(2)}°, etc. (sum = 360°).`);
      } else if (calcKey === 'diagonal_length') {
        const ha = a > 0 ? (2*area)/a : 0;
        registerResult(ha, 'h_a = 2A / a', 'Height off side a', `Diagonal-equivalent Altitude h_a = 2 * ${area.toFixed(2)} / ${a} = ${ha.toFixed(4)}`);
      } else if (calcKey === 'radius') {
        const R = area > 0 ? (a*b*c) / (4*area) : 0;
        registerResult(R, 'R = abc / 4A', 'Circumradius (R)', `R = ${a}*${b}*${c} / ${(4*area).toFixed(2)} = ${R.toFixed(4)}`);
      } else if (calcKey === 'diameter') {
        const R = area > 0 ? (a*b*c) / (4*area) : 0;
        registerResult(2*R, 'D = 2R', 'Diameter (D)', `D = 2 * ${R.toFixed(4)} = ${(2*R).toFixed(4)}`);
      } else if (calcKey === 'apothem') {
        const r = s > 0 ? area / s : 0;
        registerResult(r, 'r = A / s', 'Inradius (r)', `Inscribed radius = ${area.toFixed(2)} / ${s} = ${r.toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        const ha = a > 0 ? (2*area)/a : 0;
        registerResult(ha/3, 'y_c = h_a / 3', 'Centroid Axis', `At elevation ${ha.toFixed(3)}/3 = ${(ha/3).toFixed(4)} units above base side a.`);
      } else if (calcKey === 'moment_of_inertia') {
        const ha = a > 0 ? (2*area)/a : 0;
        const I = (a * Math.pow(ha, 3)) / 36;
        registerResult(I, 'I = a h_a^3 / 36', 'Centroid horizontal inertia', `I = ${a} * ${ha.toFixed(2)}^3 / 36 = ${I.toFixed(4)}`);
      } else {
        const P = a+b+c;
        const ratio = area > 0 ? P / area : 0;
        registerResult(ratio, 'P/A', 'Perimeter to Area ratio', `P/A = ${P} / ${area.toFixed(3)} = ${ratio.toFixed(4)}`);
      }
      break;
    }

    case 'tri_right': {
      const a = v.base;
      const b = v.height;
      const c = Math.sqrt(a*a + b*b);
      const area = 0.5 * a * b;

      if (calcKey === 'area') {
        registerResult(area, 'A = ½ \\times a \\times b', 'Area Calculation', `A = 0.5 * ${a} * ${b} = ${area}`);
      } else if (calcKey === 'perimeter' || calcKey === 'circumference') {
        registerResult(a+b+c, 'P = a + b + c', 'Perimeter calculation', `P = ${a} + ${b} + ${c.toFixed(3)} = ${(a+b+c).toFixed(4)}`);
      } else if (calcKey === 'interior_angles') {
        const alpha = Math.atan2(b, a) * (180 / Math.PI);
        registerResult(alpha, '\\alpha = \\arctan(b/a)', 'Inside angles', `Right Angle = 90°, Acute 1 = ${alpha.toFixed(2)}°, Acute 2 = ${(90-alpha).toFixed(2)}° (sum = 180°).`);
      } else if (calcKey === 'exterior_angles') {
        const alpha = Math.atan2(b, a) * (180 / Math.PI);
        registerResult(180-alpha, '\\delta = 180^\\circ - \\alpha', 'Exterior angle', `Exterior levels: ${(180-alpha).toFixed(2)}°, 90°, ${(180-(90-alpha)).toFixed(2)}° (sum = 360°).`);
      } else if (calcKey === 'diagonal_length') {
        registerResult(c, 'c = \\sqrt{a^2 + b^2}', 'Hypotenuse as diagonal line', `Hypotenuse c = \\sqrt{${a*a} + ${b*b}} = ${c.toFixed(4)}`);
      } else if (calcKey === 'radius') {
        registerResult(c/2, 'R = c / 2', 'Circumradius', `R = ${c.toFixed(3)} / 2 = ${(c/2).toFixed(4)}`);
      } else if (calcKey === 'diameter') {
        registerResult(c, 'D = c', 'Circumdiameter', `D = ${c.toFixed(4)}`);
      } else if (calcKey === 'apothem') {
        const r = (a + b - c) / 2;
        registerResult(r, 'r = (a + b - c) / 2', 'Inradius (r)', `Inscribed circle r = (${a} + ${b} - ${c.toFixed(3)}) / 2 = ${r.toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        registerResult(a/3, 'x_c = a / 3, y_c = b / 3', 'Centroid Coordinates', `Located at x = ${(a/3).toFixed(3)}, y = ${(b/3).toFixed(3)} from the perpendicular corner.`);
      } else if (calcKey === 'moment_of_inertia') {
        const I = (a * Math.pow(b, 3)) / 36;
        registerResult(I, 'I_x = ab^3 / 36', 'Second Area Inertia', `I_x = ${a} * ${b}^3 / 36 = ${I.toFixed(4)}`);
      } else {
        const P = a+b+c;
        const ratio = P/area;
        registerResult(ratio, 'P/A', 'Shape compactness', `P/A = ${P.toFixed(3)} / ${area} = ${ratio.toFixed(4)}`);
      }
      break;
    }

    // ----------------------------------------------------
    // QUADRILATERALS
    // ----------------------------------------------------
    case 'quad_square': {
      const s = v.side;
      if (calcKey === 'area') {
        registerResult(s*s, 'A = s^2', 'Area Solver', `A = ${s}^2 = ${s*s}`);
      } else if (calcKey === 'perimeter' || calcKey === 'circumference') {
        registerResult(4*s, 'P = 4s', 'Perimeter', `P = 4 * ${s} = ${4*s}`);
      } else if (calcKey === 'interior_angles') {
        registerResult(90, '\\theta_i = 90^\\circ', 'Interior Angles', `90° (sum = 360°)`);
      } else if (calcKey === 'exterior_angles') {
        registerResult(90, '\\theta_e = 90^\\circ', 'Exterior Angles', `90° (sum = 360°)`);
      } else if (calcKey === 'diagonal_length') {
        const d = s * Math.sqrt(2);
        registerResult(d, 'd = s\\sqrt{2}', 'Diagonal', `d = ${s} * 1.4142 = ${d.toFixed(4)}`);
      } else if (calcKey === 'radius') {
        const R = (s * Math.sqrt(2)) / 2;
        registerResult(R, 'R = s\\sqrt{2} / 2', 'Circumradius', `R = ${(s*1.4142).toFixed(2)}/2 = ${R.toFixed(4)}`);
      } else if (calcKey === 'diameter') {
        const D = s * Math.sqrt(2);
        registerResult(D, 'D = s\\sqrt{2}', 'Diameter of circumcircle', `${D.toFixed(4)}`);
      } else if (calcKey === 'apothem') {
        registerResult(s/2, 'r = s / 2', 'Inradius (Apothem)', `r = ${s} / 2 = ${s/2}`);
      } else if (calcKey === 'centroid') {
        registerResult(s/2, 'x_c = s / 2, y_c = s / 2', 'Centroid location', `At center point coords (${s/2}, ${s/2})`);
      } else if (calcKey === 'moment_of_inertia') {
        const I = Math.pow(s, 4) / 12;
        registerResult(I, 'I = s^4 / 12', 'Area inertia', `I = ${s}^4 / 12 = ${I.toFixed(4)}`);
      } else {
        registerResult(4/s, 'P/A = 4 / s', 'Perimeter-to-area ratio', `P/A = 4 / ${s} = ${(4/s).toFixed(4)}`);
      }
      break;
    }

    case 'quad_rectangle': {
      const l = v.length;
      const w = v.width;
      const d = Math.sqrt(l*l + w*w);
      const area = l * w;

      if (calcKey === 'area') {
        registerResult(area, 'A = l \\times w', 'Area Calculation', `A = ${l} * ${w} = ${area}`);
      } else if (calcKey === 'perimeter' || calcKey === 'circumference') {
        registerResult(2*(l+w), 'P = 2(l + w)', 'Perimeter calculation', `P = 2 * (${l} + ${w}) = ${2*(l+w)}`);
      } else if (calcKey === 'interior_angles') {
        registerResult(90, '\\theta_i = 90^\\circ', 'Angles', `All four vertices possess 90° angles (sum = 360°).`);
      } else if (calcKey === 'exterior_angles') {
        registerResult(90, '\\theta_e = 90^\\circ', 'Exterior Angles', `90° (sum = 360°)`);
      } else if (calcKey === 'diagonal_length') {
        registerResult(d, 'd = \\sqrt{l^2 + w^2}', 'Hypot Diagonal line', `d = \\sqrt{${l*l} + ${w*w}} = ${d.toFixed(4)}`);
      } else if (calcKey === 'radius') {
        registerResult(d/2, 'R = d / 2', 'Bounding Circumradius', `R = ${d.toFixed(3)} / 2 = ${(d/2).toFixed(4)}`);
      } else if (calcKey === 'diameter') {
        registerResult(d, 'D = d', 'Diameter', `${d.toFixed(4)}`);
      } else if (calcKey === 'apothem') {
        registerResult(w/2, 'r_{in} = w / 2', 'Weighted Inradius', `Shortest center-to-edge radius = ${w}/2 = ${w/2}`);
      } else if (calcKey === 'centroid') {
        registerResult(l/2, 'x_c = l/2, y_c = w/2', 'Centroid Coords', `Center located at (${l/2}, ${w/2})`);
      } else if (calcKey === 'moment_of_inertia') {
        const I = (l * Math.pow(w, 3)) / 12;
        registerResult(I, 'I = l w^3 / 12', 'Second Area Inertia', `I = ${l} * ${w}^3 / 12 = ${I.toFixed(4)}`);
      } else {
        const ratio = (2*(l+w))/area;
        registerResult(ratio, 'P/A = 2(l+w) / (lw)', 'Perimeter-to-area index', `${2*(l+w)} / ${area} = ${ratio.toFixed(4)}`);
      }
      break;
    }

    case 'quad_parallelogram': {
      const b = v.base;
      const a = v.side;
      const thetaRad = (v.theta * Math.PI) / 180;
      const h = a * Math.sin(thetaRad);
      const area = b * h;

      if (calcKey === 'area') {
        registerResult(area, 'A = b \\times a \\sin(\\theta)', 'Area Solver', `Height h = ${a} * sin(${v.theta}°) = ${h.toFixed(3)}. A = ${b} * ${h.toFixed(3)} = ${area.toFixed(4)}`);
      } else if (calcKey === 'perimeter' || calcKey === 'circumference') {
        registerResult(2*(b+a), 'P = 2(a + b)', 'Perimeter', `P = 2 * (${a} + ${b}) = ${2*(a+b)}`);
      } else if (calcKey === 'interior_angles') {
        registerResult(v.theta, '\\theta_i', 'Interior Angles', `Acute interior angle = ${v.theta}°, Obtuse = ${180-v.theta}° (sum = 360°).`);
      } else if (calcKey === 'exterior_angles') {
        registerResult(180-v.theta, '\\theta_e', 'Exterior Angles', `Acute ext = ${180-v.theta}°, Obtuse ext = ${v.theta}° (sum = 360°).`);
      } else if (calcKey === 'diagonal_length') {
        const cosval = Math.cos(thetaRad);
        const d1 = Math.sqrt(a*a + b*b - 2*a*b*cosval);
        const d2 = Math.sqrt(a*a + b*b + 2*a*b*cosval);
        registerResult(d1, 'd = \\sqrt{a^2 + b^2 - 2ab \\cos(\\theta)}', 'Primary Diagonal (d1)', `d1 = ${d1.toFixed(4)}, d2 = ${d2.toFixed(4)}`);
      } else if (calcKey === 'radius') {
        const R = Math.sqrt(a*a+b*b)/2;
        registerResult(R, 'R = \\sqrt{a^2+b^2}/2', 'Circumradius equivalent', `${R.toFixed(4)}`);
      } else if (calcKey === 'diameter') {
        const D = Math.sqrt(a*a+b*b);
        registerResult(D, 'D = \\sqrt{a^2+b^2}', 'Circumcircle Diameter', `${D.toFixed(4)}`);
      } else if (calcKey === 'apothem') {
        registerResult(h/2, 'r = h / 2', 'Weighted Inradius apothem', `r = ${h.toFixed(3)} / 2 = ${(h/2).toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        registerResult(b/2, 'x_c, y_c', 'Inertial balance center', `Aligned directly on horizontal centroid midway across sides.`);
      } else if (calcKey === 'moment_of_inertia') {
        const I = (b * Math.pow(h, 3)) / 12;
        registerResult(I, 'I = bh^3 / 12', 'Second Moment of Area', `I = ${b} * ${h.toFixed(2)}^3 / 12 = ${I.toFixed(4)}`);
      } else {
        const ratio = (2*(b+a))/area;
        registerResult(ratio, 'P/A', 'Perimeter-to-area index', `${ratio.toFixed(4)}`);
      }
      break;
    }

    case 'quad_rhombus': {
      const s = v.side;
      const thetaRad = (v.theta * Math.PI) / 180;
      const h = s * Math.sin(thetaRad);
      const d1 = 2 * s * Math.sin(thetaRad / 2);
      const d2 = 2 * s * Math.cos(thetaRad / 2);
      const area = s * h;

      if (calcKey === 'area') {
        registerResult(area, 'A = s^2 \\sin(\\theta)', 'Area Calculation', `Height h = ${h.toFixed(3)}. A = ${s}^2 * sin(${v.theta}°) = ${area.toFixed(4)}`);
      } else if (calcKey === 'perimeter' || calcKey === 'circumference') {
        registerResult(4*s, 'P = 4s', 'Perimeter', `${4*s}`);
      } else if (calcKey === 'interior_angles') {
        registerResult(v.theta, '\\theta_i', 'Rhombus angles', `Primary angle = ${v.theta}°, Supplementary = ${180-v.theta}° (sum = 360°).`);
      } else if (calcKey === 'exterior_angles') {
        registerResult(180-v.theta, '\\theta_e', 'Exterior Angles', `Exterior: ${180-v.theta}° (sum = 360°).`);
      } else if (calcKey === 'diagonal_length') {
        registerResult(d1, 'd = 2s\\sin(\\theta/2)', 'Diagonal size (d1)', `d1 = ${d1.toFixed(4)} (Short), d2 = ${d2.toFixed(4)} (Long)`);
      } else if (calcKey === 'radius') {
        registerResult(h/2, 'R = s \\sin(\\theta) / 2', 'Inradius (R)', `Inscribed circular radius R = ${h.toFixed(3)}/2 = ${(h/2).toFixed(4)}`);
      } else if (calcKey === 'diameter') {
        registerResult(h, 'D = h', 'Inscribed Diameter', `D = ${h.toFixed(4)}`);
      } else if (calcKey === 'apothem') {
        registerResult(h/2, 'r = h / 2', 'Apothem (Inradius)', `${(h/2).toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        registerResult(s/2, 'x_c, y_c', 'Centroid location', `At center crossings of orthogonals.`);
      } else if (calcKey === 'moment_of_inertia') {
        const I = (s * Math.pow(h, 3)) / 12;
        registerResult(I, 'I = sh^3 / 12', 'Second Moment of Area', `I = ${I.toFixed(4)}`);
      } else {
        const ratio = (4*s)/area;
        registerResult(ratio, 'P/A', 'Perimeter/Area Ratio', `${ratio.toFixed(4)}`);
      }
      break;
    }

    case 'quad_trapezoid': {
      const a = v.baseA;
      const b = v.baseB;
      const c = v.sideC;
      const d = v.sideD;
      const h = v.height;
      const area = 0.5 * (a + b) * h;

      if (calcKey === 'area') {
        registerResult(area, 'A = \\frac{a+b}{2} \\times h', 'Area Solver', `A = (${a} + ${b})/2 * ${h} = ${area}`);
      } else if (calcKey === 'perimeter' || calcKey === 'circumference') {
        registerResult(a+b+c+d, 'P = a + b + c + d', 'Perimeter', `${a+b+c+d}`);
      } else if (calcKey === 'interior_angles') {
        registerResult(60, '\\theta_i', 'Geometric angles', `Sum is exactly 360°. Standard parallel interior angles average supplementary bounds (usually 180° combined per leg).`);
      } else if (calcKey === 'exterior_angles') {
        registerResult(120, '\\theta_e', 'Exterior Angle', `Symmetry sums of outer limits total 360°.`);
      } else if (calcKey === 'diagonal_length') {
        const d1 = Math.sqrt(h*h + Math.pow(a - Math.abs(a-b)/2, 2));
        registerResult(d1, 'd_{1} \\approx \\sqrt{h^2 + [a - |a-b|/2]^2}', 'Isosceles Diagonal approximation', `d ≈ ${d1.toFixed(4)}`);
      } else if (calcKey === 'radius') {
        const R = Math.sqrt(h*h + Math.pow(a - Math.abs(a-b)/2, 2))/2;
        registerResult(R, 'R \\approx d_1 / 2', 'Approximate circumscribing radius', `${R.toFixed(4)}`);
      } else if (calcKey === 'diameter') {
        const D = Math.sqrt(h*h + Math.pow(a - Math.abs(a-b)/2, 2));
        registerResult(D, 'D \\approx d_1', 'Inscribed bounding limit', `${D.toFixed(4)}`);
      } else if (calcKey === 'apothem') {
        registerResult(h/2, 'r = h / 2', 'Mid-height Apothem', `${h/2}`);
      } else if (calcKey === 'centroid') {
        const yc = (h / 3) * ((2*b + a) / (b + a));
        registerResult(yc, 'y_c = (h / 3) \\times \\frac{2b + a}{b + a}', 'Vert Centroid height from base a', `y_c = (${h}/3) * (${2*b}+${a})/(${b}+${a}) = ${yc.toFixed(4)} units`);
      } else if (calcKey === 'moment_of_inertia') {
        const I = (Math.pow(h, 3) * (a*a + 4*a*b + b*b)) / (36 * (a + b));
        registerResult(I, 'I_x = \\frac{h^3(a^2 + 4ab + b^2)}{36(a + b)}', 'Inertia of area', `I_x = ${I.toFixed(4)}`);
      } else {
        const P = a+b+c+d;
        registerResult(P/area, 'P/A', 'Perimeter is to area ratio', `${(P/area).toFixed(4)}`);
      }
      break;
    }

    case 'quad_kite': {
      const a = v.sideA;
      const b = v.sideB;
      const d1 = v.diag1;
      const d2 = v.diag2;
      const area = 0.5 * d1 * d2;

      if (calcKey === 'area') {
        registerResult(area, 'A = ½ \\times d1 \\times d2', 'Area Solver', `A = 0.5 * ${d1} * ${d2} = ${area}`);
      } else if (calcKey === 'perimeter' || calcKey === 'circumference') {
        registerResult(2*(a+b), 'P = 2(a + b)', 'Perimeter', `P = 2 * (${a} + ${b}) = ${2*(a+b)}`);
      } else if (calcKey === 'interior_angles') {
        registerResult(90, '\\theta', 'Orthogonal corner angle', `Symmetry intersection diagonal angles are pre-constrained at 90°. Sum = 360°.`);
      } else if (calcKey === 'exterior_angles') {
        registerResult(90, '\\theta', 'Exterior angles', `Sum = 360°.`);
      } else if (calcKey === 'diagonal_length') {
        registerResult(d1, 'd1', 'Diagonal parameters', `d1 = ${d1}, d2 = ${d2}`);
      } else if (calcKey === 'radius') {
        const r = (d1 * d2) / (2 * (a + b));
        registerResult(r, 'r = \\frac{d1 \\times d2}{2(a+b)}', 'Inradius (r)', `Inscribed radius r = ${area} / ${(a+b)} = ${r.toFixed(4)}`);
      } else if (calcKey === 'diameter') {
        const r = (d1 * d2) / (2 * (a + b));
        registerResult(2*r, 'D = 2r', 'Diameter (D)', `${(2*r).toFixed(4)}`);
      } else if (calcKey === 'apothem') {
        const r = (d1 * d2) / (2 * (a + b));
        registerResult(r, 'apothem', 'Equivalent apothem', `${r.toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        registerResult(d2/2, 'y_c', 'Equilibrium center along axis', `Lines of symmetry balance exact vectors.`);
      } else if (calcKey === 'moment_of_inertia') {
        const I = (d1 * Math.pow(d2, 3)) / 48;
        registerResult(I, 'I = d1 \\times d2^3 / 48', 'Central Area Inertia', `I = ${d1} * ${d2}^3 / 48 = ${I.toFixed(4)}`);
      } else {
        const P = 2*(a+b);
        registerResult(P/area, 'P/A', 'Perimeter/Area metrics', `${(P/area).toFixed(4)}`);
      }
      break;
    }

    // ----------------------------------------------------
    // HIGHER POLYGONS (GENERIC MULTI-SIDE REGULAR)
    // ----------------------------------------------------
    case 'poly_pentagon':
    case 'poly_hexagon':
    case 'poly_heptagon':
    case 'poly_octagon':
    case 'poly_nonagon':
    case 'poly_decagon': {
      const s = v.side;
      let n = 5;
      if (shapeId === 'poly_hexagon') n = 6;
      else if (shapeId === 'poly_heptagon') n = 7;
      else if (shapeId === 'poly_octagon') n = 8;
      else if (shapeId === 'poly_nonagon') n = 9;
      else if (shapeId === 'poly_decagon') n = 10;

      const apothem = s / (2 * Math.tan(Math.PI / n));
      const area = 0.5 * n * s * apothem;
      const R = s / (2 * Math.sin(Math.PI / n));

      if (calcKey === 'area') {
        registerResult(area, `A = \\frac{1}{4} n s^2 \\cot(\\pi/n)`, `${n}-Gon Area Calculation`, `A = 0.25 * ${n} * ${s*s} * cot(${180/n}°) = ${area.toFixed(4)}`);
      } else if (calcKey === 'perimeter' || calcKey === 'circumference') {
        registerResult(n*s, 'P = n \\times s', 'Perimeter', `P = ${n} * ${s} = ${n*s}`);
      } else if (calcKey === 'interior_angles') {
        const single = ((n - 2) * 180) / n;
        registerResult(single, '\\theta_i = \\frac{(n-2)180}{n}', 'Regular interior angles', `Each interior angle is ${single}° (sum = ${(n-2)*180}°).`);
      } else if (calcKey === 'exterior_angles') {
        const single = 360 / n;
        registerResult(single, '\\theta_e = 360 / n', 'Exterior angles', `Each exterior angle is ${single}° (sum = 360°).`);
      } else if (calcKey === 'diagonal_length') {
        const diag = d_n_polygons(n, s);
        registerResult(diag, 'd_{max} = s \\sin(...)/\\sin(...)', 'Max Diagonal Length', `Maximum diagonal span between non-adjacent vertices = ${diag.toFixed(4)}`);
      } else if (calcKey === 'radius') {
        registerResult(R, 'R = \\frac{s}{2 \\sin(\\pi/n)}', 'Circumradius (R)', `R = ${s} / (2 * sin(${180/n}°)) = ${R.toFixed(4)}`);
      } else if (calcKey === 'diameter') {
        registerResult(2*R, 'D = 2R', 'Bounding Diameter (D)', `D = ${(2*R).toFixed(4)}`);
      } else if (calcKey === 'apothem') {
        registerResult(apothem, 'a_p = \\frac{s}{2 \\tan(\\pi/n)}', 'Apothem Solver', `a_p = ${s} / (2 * tan(${180/n}°)) = ${apothem.toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        registerResult(0, 'x_c = 0, y_c = 0', 'Geometric Balancer', `Perfect concentric symmetry centers at coordinates origin (0, 0).`);
      } else if (calcKey === 'moment_of_inertia') {
        // Area Moment of inertia of regular polygon
        const I = (area / 24) * (12 * apothem * apothem + s * s);
        registerResult(I, 'I = \\frac{A}{24}(12 a_p^2 + s^2)', 'Rotational Area Inertia', `I = (${area.toFixed(2)}/24) * (12 * ${apothem.toFixed(2)}^2 + ${s*s}) = ${I.toFixed(4)}`);
      } else {
        const P = n*s;
        registerResult(P/area, 'P/A', 'Perimeter-to-area multiplier', `P/A = ${P} / ${area.toFixed(3)} = ${(P/area).toFixed(4)}`);
      }
      break;
    }

    // ----------------------------------------------------
    // CURVED 2D
    // ----------------------------------------------------
    case 'curve_circle': {
      const r = v.radius;
      if (calcKey === 'area') {
        registerResult(Math.PI*r*r, 'A = \\pi r^2', 'Circle Area', `A = π * ${r}^2 = ${Math.PI.toFixed(5)} * ${r*r} = ${(Math.PI*r*r).toFixed(4)}`);
      } else if (calcKey === 'perimeter' || calcKey === 'circumference') {
        registerResult(2*Math.PI*r, 'C = 2\\pi r', 'Circle Circumference', `C = 2 * π * ${r} = ${(2*Math.PI*r).toFixed(4)}`);
      } else if (calcKey === 'interior_angles' || calcKey === 'exterior_angles') {
        registerResult(360, 'AngleSum = 360^\\circ', 'Curvature Angular Limit', `Convex circular bounds sweep fully across 360°.`);
      } else if (calcKey === 'diagonal_length') {
        registerResult(2*r, 'D = 2r', 'Diameter coordinates diagonal', `${2*r}`);
      } else if (calcKey === 'radius') {
        registerResult(r, 'r = r', 'Radius', `${r}`);
      } else if (calcKey === 'diameter') {
        registerResult(2*r, 'D = 2r', 'Diameter (D)', `${2*r}`);
      } else if (calcKey === 'apothem') {
        registerResult(r, 'r', 'Centric Apothem equivalent', `${r}`);
      } else if (calcKey === 'centroid') {
        registerResult(0, '(0,0)', 'Centroid Balance', `Concentric axis center (0,0).`);
      } else if (calcKey === 'moment_of_inertia') {
        const I = (Math.PI * Math.pow(r, 4)) / 4;
        registerResult(I, 'I = \\pi r^4 / 4', 'Area Inertia', `I = π * ${Math.pow(r,4)} / 4 = ${I.toFixed(4)}`);
      } else {
        registerResult(2/r, 'P/A = 2 / r', 'Space ratio', `${(2/r).toFixed(4)}`);
      }
      break;
    }

    case 'curve_semicircle': {
      const r = v.radius;
      const area = 0.5 * Math.PI * r * r;
      const P = (Math.PI + 2) * r;

      if (calcKey === 'area') {
        registerResult(area, 'A = ½ \\pi r^2', 'Semicircle Area', `A = 0.5 * 3.14159 * ${r*r} = ${area.toFixed(4)}`);
      } else if (calcKey === 'perimeter' || calcKey === 'circumference') {
        registerResult(P, 'P = (\\pi + 2)r', 'Perimeter (including base)', `P = (3.14159 + 2) * ${r} = ${P.toFixed(4)}`);
      } else if (calcKey === 'interior_angles' || calcKey === 'exterior_angles') {
        registerResult(360, 'AngleSum', 'Angles', `Full semi-conic sums total 360°.`);
      } else if (calcKey === 'diagonal_length' || calcKey === 'diameter') {
        registerResult(2*r, 'D = 2r', 'Diameter base flat edge', `${2*r}`);
      } else if (calcKey === 'radius') {
        registerResult(r, 'r', 'Radius', `${r}`);
      } else if (calcKey === 'apothem') {
        registerResult(r/2, 'r/2', 'Middle elevation apothem', `${r/2}`);
      } else if (calcKey === 'centroid') {
        const yc = (4*r)/(3 * Math.PI);
        registerResult(yc, 'y_c = 4r / 3\\pi', 'Centroid Base offset distance', `Located exactly ${yc.toFixed(4)} units above the base axis flat line.`);
      } else if (calcKey === 'moment_of_inertia') {
        const I = (Math.PI/8 - 8/(9*Math.PI)) * Math.pow(r, 4);
        registerResult(I, 'I_x \\approx 0.10976 \\times r^4', 'Second area horizontal centroidal inertia', `I = 0.10976 * ${r}^4 = ${I.toFixed(4)}`);
      } else {
        registerResult(P/area, 'P/A', 'Perimeter to area ratio', `${(P/area).toFixed(4)}`);
      }
      break;
    }

    case 'curve_ellipse': {
      const a = v.semiA;
      const b = v.semiB;
      const area = Math.PI * a * b;

      if (calcKey === 'area') {
        registerResult(area, 'A = \\pi a b', 'Ellipse Area', `A = π * ${a} * ${b} = ${area.toFixed(4)}`);
      } else if (calcKey === 'perimeter' || calcKey === 'circumference') {
        const hRad = Math.pow(a-b,2)/Math.pow(a+b,2);
        const P = Math.PI * (a+b) * (1 + (3*hRad)/(10 + Math.sqrt(4 - 3*hRad))); // Ramanujan Formula II
        registerResult(P, 'C \\approx \\pi [ 3(a+b) - \\sqrt{(3a+b)(a+3b)} ]', 'Ramanujan Circumference solver', `C ≈ ${P.toFixed(4)}`);
      } else if (calcKey === 'interior_angles' || calcKey === 'exterior_angles') {
        registerResult(360, 'AngleSum', 'Conic limits', `360° total.`);
      } else if (calcKey === 'diagonal_length') {
        const focal = Math.max(0, a*a - b*b);
        const focus = 2 * Math.sqrt(focal);
        registerResult(focus, 'd_{focal} = 2\\sqrt{a^2 - b^2}', 'Inter-focal distance', `Distance between the two ellipses focal points = ${focus.toFixed(4)}`);
      } else if (calcKey === 'radius') {
        registerResult(Math.sqrt(a*b), 'R_{avg} = \\sqrt{ab}', 'Geometric Average Radius', `Average geometric radial size = ${Math.sqrt(a*b).toFixed(4)}`);
      } else if (calcKey === 'diameter') {
        registerResult(2*a, 'D_{major} = 2a', 'Major boundary size', `Major Diameter = ${2*a}, Minor Diameter = ${2*b}`);
      } else if (calcKey === 'apothem') {
        registerResult(b, 'r_{in} = b', 'Inradius limits', `${b}`);
      } else if (calcKey === 'centroid') {
        registerResult(0, '(0, 0)', 'Centroid Center coordinate', `Exactly at local coordinate origin.`);
      } else if (calcKey === 'moment_of_inertia') {
        const I_x = (Math.PI * a * Math.pow(b, 3)) / 4;
        registerResult(I_x, 'I_x = \\pi a b^3 / 4', 'Second moment of area', `I_x = ${I_x.toFixed(4)}`);
      } else {
        const hRad = Math.pow(a-b,2)/Math.pow(a+b,2);
        const P = Math.PI * (a+b) * (1 + (3*hRad)/(10 + Math.sqrt(4 - 3*hRad)));
        registerResult(P/area, 'P/A', 'Circumference/Area indicators', `${(P/area).toFixed(4)}`);
      }
      break;
    }

    // ----------------------------------------------------
    // POLYHEDRONS (3D)
    // ----------------------------------------------------
    case 'solid_cube': {
      const s = v.side;
      if (calcKey === 'volume') {
        registerResult(Math.pow(s,3), 'V = s^3', 'Cube Volume', `V = ${s}^3 = ${s*s*s}`);
      } else if (calcKey === 'surface_area') {
        registerResult(6*s*s, 'SA = 6s^2', 'Total Surface Area', `SA = 6 * ${s*s} = ${6*s*s}`);
      } else if (calcKey === 'lateral_surface_area') {
        registerResult(4*s*s, 'LSA = 4s^2', 'Lateral Face Area', `${4*s*s}`);
      } else if (calcKey === 'slant_height') {
        registerResult(s, 'h = s', 'Vertical Side Edge Slant', `${s}`);
      } else if (calcKey === 'space_diagonal') {
        const d = s * Math.sqrt(3);
        registerResult(d, 'd_{space} = s\\sqrt{3}', 'Space Diagonal (inside)', `d_space = ${s} * 1.732 = ${d.toFixed(4)}`);
      } else if (calcKey === 'face_diagonal') {
        const d = s * Math.sqrt(2);
        registerResult(d, 'd_{face} = s\\sqrt{2}', 'Face Diagonal (sides)', `d_face = ${s} * 1.414 = ${d.toFixed(4)}`);
      } else if (calcKey === 'edge_length') {
        registerResult(12*s, 'L_{total} = 12s', 'Total Edge Length', `All 12 edge lines sum = 12 * ${s} = ${12*s}`);
      } else if (calcKey === 'base_area') {
        registerResult(s*s, 'B_A = s^2', 'Base Face Area', `${s*s}`);
      } else if (calcKey === 'centroid') {
        registerResult(s/2, '(s/2, s/2, s/2)', 'Centroid Balance Coordinate', `Center at coordinates (${s/2}, ${s/2}, ${s/2})`);
      } else if (calcKey === 'moment_of_inertia') {
        const coeff = 1/6; // solid cube coefficient
        registerResult(coeff, 'I = \\frac{1}{6} M s^2', 'Solid Mass Rotational Inertia coefficient', `Mass multiplier ratio = 0.1667`);
      } else {
        const sa = 6*s*s;
        const vol = Math.pow(s,3);
        registerResult(sa/vol, 'SA / V = 6 / s', 'Area to Volume Ratio', `SA/V = 6 / ${s} = ${(6/s).toFixed(4)}`);
      }
      break;
    }

    case 'solid_cuboid': {
      const l = v.length;
      const w = v.width;
      const h = v.height;
      const sa = 2*(l*w + l*h + w*h);
      const vol = l * w * h;

      if (calcKey === 'volume') {
        registerResult(vol, 'V = l \\times w \\times h', 'Volume Capacity', `V = ${l} * ${w} * ${h} = ${vol}`);
      } else if (calcKey === 'surface_area') {
        registerResult(sa, 'SA = 2(lw + lh + wh)', 'Total Surface Area', `SA = 2*(${l*w} + ${l*h} + ${w*h}) = ${sa}`);
      } else if (calcKey === 'lateral_surface_area') {
        const lsa = 2*h*(l+w);
        registerResult(lsa, 'LSA = 2h(l + w)', 'Lateral Surface Area', `LSA = 2*${h}*(${l}+${w}) = ${lsa}`);
      } else if (calcKey === 'slant_height') {
        registerResult(h, 'h', 'Height Vertical slant', `${h}`);
      } else if (calcKey === 'space_diagonal') {
        const d = Math.sqrt(l*l + w*w + h*h);
        registerResult(d, 'd_{space} = \\sqrt{l^2 + w^2 + h^2}', 'Space Diagonal (inside corner-to-corner)', `${d.toFixed(4)}`);
      } else if (calcKey === 'face_diagonal') {
        const d = Math.sqrt(l*l + w*w);
        registerResult(d, 'd_{face} = \\sqrt{l^2 + w^2}', 'Base Face Diagonal', `${d.toFixed(4)}`);
      } else if (calcKey === 'edge_length') {
        registerResult(4*(l+w+h), 'L_{edge} = 4(l + w + h)', 'Sum of all 12 edges', `${4*(l+w+h)}`);
      } else if (calcKey === 'base_area') {
        registerResult(l*w, 'B_A = l \\times w', 'Bottom base plate area', `${l*w}`);
      } else if (calcKey === 'centroid') {
        registerResult(l/2, '(l/2, w/2, h/2)', 'Geometric center Balance coords', `Located exactly at coordinates (${l/2}, ${w/2}, ${h/2})`);
      } else if (calcKey === 'moment_of_inertia') {
        registerResult(0.08333, 'I = \\frac{1}{12} M (w^2+h^2)', 'Rotational mass coefficient around length axis', `0.08333`);
      } else {
        registerResult(sa/vol, 'SA/V', 'Surface-to-Volume compact indicator', `${(sa/vol).toFixed(4)}`);
      }
      break;
    }

    case 'solid_triprism': {
      const a = v.sideA;
      const b = v.sideB;
      const c = v.sideC;
      const h = v.height; // prism length
      const s = (a + b + c) / 2;
      const rbase = s*(s-a)*(s-b)*(s-c);
      const B_A = rbase > 0 ? Math.sqrt(rbase) : 0;
      const P_base = a + b + c;

      if (calcKey === 'volume') {
        registerResult(B_A * h, 'V = B_A \\times h', 'Triangular Prism Volume', `Base Area B_A = ${B_A.toFixed(3)}. Volume V = ${B_A.toFixed(3)} * ${h} = ${(B_A*h).toFixed(4)}`);
      } else if (calcKey === 'surface_area') {
        const saVal = 2*B_A + P_base*h;
        registerResult(saVal, 'SA = 2 B_A + P_{base} h', 'Total Surface Area', `SA = 2 * ${B_A.toFixed(2)} + ${P_base} * ${h} = ${saVal.toFixed(4)}`);
      } else if (calcKey === 'lateral_surface_area') {
        registerResult(P_base * h, 'LSA = P_{base} \\times h', 'Lateral Side Panels Area', `${P_base * h}`);
      } else if (calcKey === 'slant_height') {
        registerResult(h, 'h', 'Prism longitudinal edge size', `${h}`);
      } else if (calcKey === 'space_diagonal') {
        const dVal = Math.sqrt(Math.pow(a/Math.sqrt(3), 2) + h*h);
        registerResult(dVal, 'd_{space} \\approx \\sqrt{R_{base}^2 + h^2}', 'Space diagonal equivalent', `${dVal.toFixed(4)}`);
      } else if (calcKey === 'face_diagonal') {
        const dVal = Math.sqrt(a*a + h*h);
        registerResult(dVal, 'd_{face} = \\sqrt{a^2 + h^2}', 'Main rectangular face diagonal', `${dVal.toFixed(4)}`);
      } else if (calcKey === 'edge_length') {
        registerResult(2*P_base + 3*h, 'L_{total} = 2P_B + 3h', 'Sum of all 9 prism edges', `${2*P_base + 3*h}`);
      } else if (calcKey === 'base_area') {
        registerResult(B_A, 'B_A', 'Base Triangular Area', `${B_A.toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        registerResult(h/2, 'L / 2', 'Centroid elevation', `Located midway down the length (${h}/2 = ${h/2} units)`);
      } else if (calcKey === 'moment_of_inertia') {
        registerResult(0.08333, '1/12 scale', 'Center axis inertia coefficient', `0.08333`);
      } else {
        const saVal = 2*B_A + P_base*h;
        const volVal = B_A * h;
        registerResult(volVal > 0 ? saVal/volVal : 0, 'SA/V', 'Area to Volume index', `${(saVal/volVal).toFixed(4)}`);
      }
      break;
    }

    case 'solid_pyramid': {
      const a = v.base;
      const h = v.height;
      const slant = Math.sqrt(Math.pow(a/2, 2) + h*h);
      const baseArea = a * a;
      const lsa = 2 * a * slant;
      const sa = baseArea + lsa;

      if (calcKey === 'volume') {
        registerResult((1/3) * baseArea * h, 'V = \\frac{1}{3} a^2 h', 'Pyramid Volume', `V = 1/3 * ${baseArea} * ${h} = ${((1/3)*baseArea*h).toFixed(4)}`);
      } else if (calcKey === 'surface_area') {
        registerResult(sa, 'SA = a^2 + 2 a \\sqrt{h^2 + (a/2)^2}', 'Total Surface Area', `SA = ${baseArea} + 2*${a}*${slant.toFixed(3)} = ${sa.toFixed(4)}`);
      } else if (calcKey === 'lateral_surface_area') {
        registerResult(lsa, 'LSA = 2 a l_{slant}', 'Lateral Sides Area', `LSA = 2 * ${a} * ${slant.toFixed(3)} = ${lsa.toFixed(4)}`);
      } else if (calcKey === 'slant_height') {
        registerResult(slant, 'l = \\sqrt{h^2 + (a/2)^2}', 'Slant Altitude of Triangular Faces', `l = \\sqrt{${h*h} + ${a*a/4}} = ${slant.toFixed(4)}`);
      } else if (calcKey === 'space_diagonal') {
        const spaceEdge = Math.sqrt(h*h + a*a/2);
        registerResult(spaceEdge, 'e = \\sqrt{h^2 + a^2/2}', 'Slant space corner edge', `${spaceEdge.toFixed(4)}`);
      } else if (calcKey === 'face_diagonal') {
        const d = a * Math.sqrt(2);
        registerResult(d, 'd = a\\sqrt{2}', 'Base square diagonal length', `${d.toFixed(4)}`);
      } else if (calcKey === 'edge_length') {
        const e = Math.sqrt(h*h + a*a/2);
        const ltot = 4*a + 4*e;
        registerResult(ltot, 'L_{edges} = 4a + 4e', 'Sum of all 8 pyramid edges', `${ltot.toFixed(4)}`);
      } else if (calcKey === 'base_area') {
        registerResult(baseArea, 'B_A = a^2', 'Base Square Area', `${baseArea}`);
      } else if (calcKey === 'centroid') {
        registerResult(h/4, 'z_c = h / 4', 'Gravity height centroid', `Elevated ${h/4} units vertically up from bottom base center.`);
      } else if (calcKey === 'moment_of_inertia') {
        registerResult(0.05, '0.05', 'Centroid mass ratio', `Rotational inertia coordinate coefficient`);
      } else {
        const vol = (1/3) * baseArea * h;
        registerResult(vol > 0 ? sa/vol : 0, 'SA/V', 'Surface/Volume scale index', `${(sa/vol).toFixed(4)}`);
      }
      break;
    }

    // ----------------------------------------------------
    // CURVED SOLIDS
    // ----------------------------------------------------
    case 'solid_sphere': {
      const r = v.radius;
      if (calcKey === 'volume') {
        const vol = (4/3) * Math.PI * Math.pow(r,3);
        registerResult(vol, 'V = \\frac{4}{3} \\pi r^3', 'Sphere Volume', `V = 1.33333 * 3.14159 * ${Math.pow(r,3)} = ${vol.toFixed(4)}`);
      } else if (calcKey === 'surface_area' || calcKey === 'lateral_surface_area') {
        const sa = 4 * Math.PI * r * r;
        registerResult(sa, 'SA = 4\\pi r^2', 'Outer surface Area', `SA = 4 * 3.14159 * ${r*r} = ${sa.toFixed(4)}`);
      } else if (calcKey === 'slant_height') {
        registerResult(r, 'r', 'Radius equivalent', `${r}`);
      } else if (calcKey === 'space_diagonal' || calcKey === 'face_diagonal') {
        registerResult(2*r, 'D = 2r', 'Diagonal Diameter of core sphere', `${2*r}`);
      } else if (calcKey === 'edge_length') {
        registerResult(2 * Math.PI * r, '2\\pi r', 'Great Circle Boundary Perimeter', `${(2*Math.PI*r).toFixed(4)}`);
      } else if (calcKey === 'base_area') {
        registerResult(Math.PI * r * r, 'B_A = \\pi r^2', 'Great circular cross area', `${(Math.PI*r*r).toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        registerResult(0, '(0,0,0)', 'Sphere Centroid', `Perfect spherical origin center (0, 0, 0).`);
      } else if (calcKey === 'moment_of_inertia') {
        registerResult(0.4, 'I = \\frac{2}{5} M r^2', 'Solid Sphere Inertia Mass Ratio', `Ratio = 0.400`);
      } else {
        registerResult(3/r, 'SA/V = 3 / r', 'Surface/Volume compactness', `${(3/r).toFixed(4)}`);
      }
      break;
    }

    case 'solid_cylinder': {
      const r = v.radius;
      const h = v.height;
      const baseArea = Math.PI * r * r;
      const curved = 2 * Math.PI * r * h;
      const sa = 2 * baseArea + curved;
      const vol = baseArea * h;

      if (calcKey === 'volume') {
        registerResult(vol, 'V = \\pi r^2 h', 'Cylinder Volume', `V = π * ${r*r} * ${h} = ${vol.toFixed(4)}`);
      } else if (calcKey === 'surface_area') {
        registerResult(sa, 'SA = 2\\pi r^2 + 2\\pi r h', 'Total Surface Area', `SA = 2 * ${baseArea.toFixed(1)} + ${curved.toFixed(1)} = ${sa.toFixed(4)}`);
      } else if (calcKey === 'lateral_surface_area') {
        registerResult(curved, 'CSA = 2\\pi r h', 'Curved Lateral Tube Area', `CSA = 2*π*${r}*${h} = ${curved.toFixed(4)}`);
      } else if (calcKey === 'slant_height') {
        registerResult(h, 'h', 'Vertical line height', `${h}`);
      } else if (calcKey === 'space_diagonal') {
        const diag = Math.sqrt(Math.pow(2*r, 2) + h*h);
        registerResult(diag, 'd = \\sqrt{(2r)^2 + h^2}', 'Main bounding solid diagonal', `${diag.toFixed(4)}`);
      } else if (calcKey === 'face_diagonal') {
        const diag = Math.sqrt(Math.pow(2*r, 2) + h*h);
        registerResult(diag, 'd = \\sqrt{(2r)^2 + h^2}', 'Diagonal of rectangular projection', `${diag.toFixed(4)}`);
      } else if (calcKey === 'edge_length') {
        registerResult(4 * Math.PI * r, '4\\pi r', 'Sum of perimeter of upper and lower caps', `${(4*Math.PI*r).toFixed(4)}`);
      } else if (calcKey === 'base_area') {
        registerResult(baseArea, 'B_A = \\pi r^2', 'End Base circular Cap Area', `${baseArea.toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        registerResult(h/2, 'h / 2', 'Centroid center axis height', `Aligned directly inside the core spindle axis elevated ${h/2} units from foundations.`);
      } else if (calcKey === 'moment_of_inertia') {
        registerResult(0.5, 'I = \\frac{1}{2} M r^2', 'Solid Cylinder spin axis coefficient', `Ratio = 0.500`);
      } else {
        registerResult(sa/vol, 'SA/V', 'Surface/Volume indices', `${(sa/vol).toFixed(4)}`);
      }
      break;
    }

    case 'solid_cone': {
      const r = v.radius;
      const h = v.height;
      const slant = Math.sqrt(r*r + h*h);
      const baseArea = Math.PI * r * r;
      const sa = baseArea + Math.PI * r * slant;

      if (calcKey === 'volume') {
        registerResult((1/3)*baseArea*h, 'V = \\frac{1}{3} \\pi r^2 h', 'Cone Volume', `V = 1/3 * π * ${r*r} * ${h} = ${((1/3)*baseArea*h).toFixed(4)}`);
      } else if (calcKey === 'surface_area') {
        registerResult(sa, 'SA = \\pi r (r + l_{slant})', 'Total Surface Area', `SA = π * ${r} * (${r} + ${slant.toFixed(3)}) = ${sa.toFixed(4)}`);
      } else if (calcKey === 'lateral_surface_area') {
        registerResult(Math.PI * r * slant, 'CSA = \\pi r l_{slant}', 'Curved Cone Surface Area', `${(Math.PI*r*slant).toFixed(4)}`);
      } else if (calcKey === 'slant_height') {
        registerResult(slant, 'l = \\sqrt{r^2 + h^2}', 'Slant Height (l)', `l = \\sqrt{${r*r} + ${h*h}} = ${slant.toFixed(4)}`);
      } else if (calcKey === 'space_diagonal') {
        registerResult(slant, 'l', 'Slant diagonal', `${slant.toFixed(4)}`);
      } else if (calcKey === 'face_diagonal') {
        registerResult(slant, 'l', 'Triangular profile slant diagonal', `${slant.toFixed(4)}`);
      } else if (calcKey === 'edge_length') {
        registerResult(2 * Math.PI * r, '2\\pi r', 'Base Circle Perimeter', `${(2 * Math.PI * r).toFixed(4)}`);
      } else if (calcKey === 'base_area') {
        registerResult(baseArea, 'B_A = \\pi r^2', 'Base Circle Area', `${baseArea.toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        registerResult(h/4, 'z_c = h / 4', 'Gravity vertical centroid offset', `Elevated ${h/4} units vertically up from core circular center base.`);
      } else if (calcKey === 'moment_of_inertia') {
        registerResult(0.3, 'I = \\frac{3}{10} M r^2', 'Solid Cone spindle ratio', `Ratio = 0.300`);
      } else {
        const volVal = (1/3)*baseArea*h;
        registerResult(sa/volVal, 'SA/V', 'Area/Volume compact metric', `${(sa/volVal).toFixed(4)}`);
      }
      break;
    }

    case 'solid_torus': {
      const R = v.majorR;
      const r = v.minorR;
      const vol = 2 * Math.pow(Math.PI, 2) * R * r * r;
      const sa = 4 * Math.pow(Math.PI, 2) * R * r;

      if (calcKey === 'volume') {
        registerResult(vol, 'V = 2\\pi^2 R r^2', 'Torus Volume', `V = 2 * 9.8696 * ${R} * ${r*r} = ${vol.toFixed(4)}`);
      } else if (calcKey === 'surface_area' || calcKey === 'lateral_surface_area') {
        registerResult(sa, 'SA = 4\\pi^2 R r', 'Torus Surface Area', `SA = 4 * 9.8696 * ${R} * ${r} = ${sa.toFixed(4)}`);
      } else if (calcKey === 'slant_height') {
        registerResult(r, 'r', 'Tube radius limit equivalent', `${r}`);
      } else if (calcKey === 'space_diagonal') {
        registerResult(2*(R+r), 'D_{outer} = 2(R+r)', 'Max Toroidal Outer Span Diagonal', `${2*(R+r)}`);
      } else if (calcKey === 'face_diagonal') {
        registerResult(2*r, 'D_{tube} = 2r', 'Tube Face circular cross diameter', `${2*r}`);
      } else if (calcKey === 'edge_length') {
        registerResult(2 * Math.PI * R, 'C_{center} = 2\\pi R', 'Toroidal Spine Ring Sweep Length', `${(2*Math.PI*R).toFixed(4)}`);
      } else if (calcKey === 'base_area') {
        registerResult(Math.PI * r * r, 'B_A = \\pi r^2', 'Cross-sectional tube area', `${(Math.PI*r*r).toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        registerResult(0, '(0,0,0)', 'Centroid symmetry point', `Axial donut core center origin coordinate (0, 0, 0)`);
      } else if (calcKey === 'moment_of_inertia') {
        // Spin axis inertia of hollow torus
        registerResult(1, 'I \\approx M(R^2 + 0.75r^2)', 'Rotational mass Inertial index multiplier', `Torus rotational ratio`);
      } else {
        registerResult(sa/vol, 'SA/V = 2 / r', 'Surface-to-Volume compactness ratio', `SA/V = 2 / ${r} = ${(sa/vol).toFixed(4)}`);
      }
      break;
    }

    // ----------------------------------------------------
    // PLATONIC SOLIDS
    // ----------------------------------------------------
    case 'plat_tetrahedron': {
      const a = v.edge;
      if (calcKey === 'volume') {
        const val = Math.pow(a,3) / (6 * Math.sqrt(2));
        registerResult(val, 'V = \\frac{a^3}{6\\sqrt{2}}', 'Tetrahedron Volume', `V = ${a}^3 / 8.48528 = ${val.toFixed(4)}`);
      } else if (calcKey === 'surface_area') {
        const val = Math.sqrt(3) * a * a;
        registerResult(val, 'SA = \\sqrt{3} a^2', 'Total Surface Area (4 faces)', `SA = 1.732 * ${a*a} = ${val.toFixed(4)}`);
      } else if (calcKey === 'lateral_surface_area') {
        const val = (3 * Math.sqrt(3) / 4) * a * a;
        registerResult(val, 'LSA = 3 \\times A_{face}', 'Lateral area (3 faces)', `LSA = 3 * ${(Math.sqrt(3)/4*a*a).toFixed(2)} = ${val.toFixed(4)}`);
      } else if (calcKey === 'slant_height') {
        const val = (Math.sqrt(3)/2) * a;
        registerResult(val, 'l_s = \\frac{\\sqrt{3}}{2} a', 'Face Slant Altitude', `${val.toFixed(4)}`);
      } else if (calcKey === 'space_diagonal') {
        const val = a * Math.sqrt(2/3);
        registerResult(val, 'H = a\\sqrt{\\frac{2}{3}}', 'Solid vertical height diagonal', `${val.toFixed(4)}`);
      } else if (calcKey === 'face_diagonal') {
        registerResult(a, 'd_{face} = a', 'Face Diagonal (triangle edges)', `All 4 faces are equilateral; diagonals correspond directly to edges: ${a}`);
      } else if (calcKey === 'edge_length') {
        registerResult(6 * a, 'L = 6a', 'Total Edge Length', `6 edges * ${a} = ${6*a}`);
      } else if (calcKey === 'base_area') {
        const val = (Math.sqrt(3)/4) * a * a;
        registerResult(val, 'B_A = \\frac{\\sqrt{3}}{4} a^2', 'Base Equilateral triangular face area', `${val.toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        const val = a / (2 * Math.sqrt(6));
        registerResult(val, 'z_c = \\frac{a}{2\\sqrt{6}}', 'Centroid Base vertical offset', `Located ${val.toFixed(4)} units above the base centering triangle.`);
      } else if (calcKey === 'moment_of_inertia') {
        registerResult(0.05, 'I = 0.05 M a^2', 'Centroid mass rotational multiplier ratio', `Ratio = 0.050`);
      } else {
        const sa = Math.sqrt(3) * a * a;
        const vol = Math.pow(a,3) / (6 * Math.sqrt(2));
        registerResult(sa/vol, 'SA/V', 'Inertial surface density scale', `${(sa/vol).toFixed(4)}`);
      }
      break;
    }

    case 'plat_octahedron': {
      const a = v.edge;
      if (calcKey === 'volume') {
        const val = (Math.sqrt(2) / 3) * Math.pow(a,3);
        registerResult(val, 'V = \\frac{\\sqrt{2}}{3} a^3', 'Octahedron Volume', `V = 0.4714 * ${Math.pow(a,3)} = ${val.toFixed(4)}`);
      } else if (calcKey === 'surface_area') {
        const val = 2 * Math.sqrt(3) * a * a;
        registerResult(val, 'SA = 2\\sqrt{3} a^2', 'Total Surface Area (8 faces)', `SA = 3.4641 * ${a*a} = ${val.toFixed(4)}`);
      } else if (calcKey === 'lateral_surface_area') {
        const val = (3/2) * Math.sqrt(3) * a * a;
        registerResult(val, 'LSA = 6 \\times A_{face}', 'Lateral Face Area (6 faces)', `${val.toFixed(4)}`);
      } else if (calcKey === 'slant_height') {
        const val = (Math.sqrt(3)/2) * a;
        registerResult(val, 'l_s = \\frac{\\sqrt{3}}{2} a', 'Face Slant Altitude', `${val.toFixed(4)}`);
      } else if (calcKey === 'space_diagonal') {
        const val = a * Math.sqrt(2);
        registerResult(val, 'd = a\\sqrt{2}', 'Space Diagonal (farthest vertices)', `Diagonal = ${val.toFixed(4)}`);
      } else if (calcKey === 'face_diagonal') {
        registerResult(a, 'd_{face} = a', 'Face diagonal line length', `Equal to edge length: ${a}`);
      } else if (calcKey === 'edge_length') {
        registerResult(12 * a, 'L = 12a', 'Total Edge Length', `Octahedron boasts exactly 12 congruent edges = ${12*a}`);
      } else if (calcKey === 'base_area') {
        const val = (Math.sqrt(3)/4) * a * a;
        registerResult(val, 'B_A = \\frac{\\sqrt{3}}{4} a^2', 'Individual face area basis', `${val.toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        registerResult(0, '(0,0,0)', 'Centroid coordinates center', `Symmetry centroid is at center (0, 0, 0).`);
      } else if (calcKey === 'moment_of_inertia') {
        registerResult(0.1, 'I = 0.1 M a^2', 'Solid regular octahedron rotational ratio', `Ratio = 0.100`);
      } else {
        const sa = 2 * Math.sqrt(3) * a * a;
        const vol = (Math.sqrt(2) / 3) * Math.pow(a,3);
        registerResult(sa/vol, 'SA/V', 'Surface/Volume index', `${(sa/vol).toFixed(4)}`);
      }
      break;
    }

    case 'plat_icosahedron': {
      const a = v.edge;
      if (calcKey === 'volume') {
        const val = (5 / 12) * (3 + Math.sqrt(5)) * Math.pow(a,3);
        registerResult(val, 'V = \\frac{5}{12}(3 + \\sqrt{5}) a^3', 'Icosahedron Volume', `V = 2.1817 * ${Math.pow(a,3)} = ${val.toFixed(4)}`);
      } else if (calcKey === 'surface_area') {
        const val = 5 * Math.sqrt(3) * a * a;
        registerResult(val, 'SA = 5\\sqrt{3} a^2', 'Total Surface Area (20 faces)', `SA = 8.6603 * ${a*a} = ${val.toFixed(4)}`);
      } else if (calcKey === 'lateral_surface_area') {
        const val = 4.5 * Math.sqrt(3) * a * a;
        registerResult(val, 'LSA = 18 \\times A_{face}', 'Lateral Surface (18 faces)', `${val.toFixed(4)}`);
      } else if (calcKey === 'slant_height') {
        const val = (Math.sqrt(3)/2) * a;
        registerResult(val, 'l_s = \\frac{\\sqrt{3}}{2} a', 'Face Slant Height', `${val.toFixed(4)}`);
      } else if (calcKey === 'space_diagonal') {
        const val = a * Math.sqrt((5 + Math.sqrt(5)) / 2);
        registerResult(val, 'D = a\\sqrt{\\frac{5+\\sqrt{5}}{2}}', 'Diameter space diagonal (vertices)', `D = ${val.toFixed(4)}`);
      } else if (calcKey === 'face_diagonal') {
        registerResult(a, 'd_{face} = a', 'Face diagonal edge', `${a}`);
      } else if (calcKey === 'edge_length') {
        registerResult(30 * a, 'L = 30a', 'Total Edge Line length', `30 congruent edge spans = ${30*a}`);
      } else if (calcKey === 'base_area') {
        const val = (Math.sqrt(3)/4) * a * a;
        registerResult(val, 'B_A = \\frac{\\sqrt{3}}{4} a^2', 'Individual face area bases', `${val.toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        registerResult(0, '(0,0,0)', 'Icosahedron Centroid', `At geometric balance center (0, 0, 0).`);
      } else if (calcKey === 'moment_of_inertia') {
        registerResult(0.325, 'I \\approx 0.325 M a^2s', 'Rotational mass ratio index', `Ratio = 0.325`);
      } else {
        const sa = 5 * Math.sqrt(3) * a * a;
        const vol = (5 / 12) * (3 + Math.sqrt(5)) * Math.pow(a,3);
        registerResult(sa/vol, 'SA/V', 'Area/Volume ratio', `${(sa/vol).toFixed(4)}`);
      }
      break;
    }

    case 'plat_dodecahedron': {
      const a = v.edge;
      if (calcKey === 'volume') {
        const val = ((15 + 7 * Math.sqrt(5)) / 4) * Math.pow(a,3);
        registerResult(val, 'V = \\frac{15 + 7\\sqrt{5}}{4} a^3', 'Dodecahedron Volume', `V = 7.6631 * ${Math.pow(a,3)} = ${val.toFixed(4)}`);
      } else if (calcKey === 'surface_area') {
        const val = 3 * Math.sqrt(25 + 10 * Math.sqrt(5)) * a * a;
        registerResult(val, 'SA = 3\\sqrt{25 + 10\\sqrt{5}} a^2', 'Total Surface Area (12 faces)', `SA = 20.6457 * ${a*a} = ${val.toFixed(4)}`);
      } else if (calcKey === 'lateral_surface_area') {
        const face = 0.25 * Math.sqrt(25 + 10 * Math.sqrt(5)) * a * a;
        const val = 11 * face;
        registerResult(val, 'LSA = 11 \\times A_{face}', 'Lateral Surface Area (11 faces)', `${val.toFixed(4)}`);
      } else if (calcKey === 'slant_height') {
        const val = 0.5 * Math.sqrt(5 + 2 * Math.sqrt(5)) * a;
        registerResult(val, 'h_{face} = 0.5\\sqrt{5+2\\sqrt{5}}a', 'Pentagonal Face slant Height altitude', `${val.toFixed(4)}`);
      } else if (calcKey === 'space_diagonal') {
        const val = a * Math.sqrt(3) * ((1 + Math.sqrt(5)) / 2);
        registerResult(val, 'd = a\\sqrt{3}\\phi', 'Space Diagonal (Vertices max stretch)', `Diagonal = ${val.toFixed(4)}`);
      } else if (calcKey === 'face_diagonal') {
        const val = a * ((1 + Math.sqrt(5)) / 2);
        registerResult(val, 'd_{face} = a\\phi', 'Face Diagonal (Pentagon corners)', `Golden Ratio diagonal face span = 1.61803 * ${a} = ${val.toFixed(4)}`);
      } else if (calcKey === 'edge_length') {
        registerResult(30 * a, 'L = 30a', 'Total Edge Length', `30 congruent edges = ${30*a}`);
      } else if (calcKey === 'base_area') {
        const val = 0.25 * Math.sqrt(25 + 10 * Math.sqrt(5)) * a * a;
        registerResult(val, 'B_A = \\frac{1}{4}\\sqrt{25+10\\sqrt{5}} a^2', 'Base Pentagonal Flat Face Area', `${val.toFixed(4)}`);
      } else if (calcKey === 'centroid') {
        registerResult(0, '(0,0,0)', 'Centroid symmetry point', `Balanced exactly at core symmetry center point coordinates.`);
      } else if (calcKey === 'moment_of_inertia') {
        registerResult(0.7082, 'I \\approx 0.7082 M a^2', 'Solid dodecahedron rotational coefficient', `Ratio = 0.7082`);
      } else {
        const sa = 3 * Math.sqrt(25 + 10 * Math.sqrt(5)) * a * a;
        const vol = ((15 + 7 * Math.sqrt(5)) / 4) * Math.pow(a,3);
        registerResult(sa/vol, 'SA/V', 'Area/Volume rating', `${(sa/vol).toFixed(4)}`);
      }
      break;
    }
  }

  return { result, steps, formulaTex };
}

// Math Utility helper computes max diagonal for regular polygons using trigonometry
function d_n_polygons(n: number, s: number): number {
  const R = s / (2 * Math.sin(Math.PI / n));
  if (n % 2 === 0) {
    return 2 * R; // symmetric vertex diagonal
  } else {
    return R * (1 + Math.cos(Math.PI / (2 * n))); // non-symmetric apex diagonal
  }
}
