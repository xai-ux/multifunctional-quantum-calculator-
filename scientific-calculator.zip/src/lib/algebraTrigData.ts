export interface FormulaDefinition {
  id: string;
  name: string;
  formula: string;         // Standard representation (e.g. LaTeX)
  humanReadable: string;   // Clean readable format (Unicode characters)
  example: string;
}

export interface FormulaCategory {
  categoryName: string;
  description: string;
  items: FormulaDefinition[];
}

export const ALGEBRA_FORMULAS: FormulaCategory[] = [
  {
    categoryName: 'Product & Factoring Identities',
    description: 'Fundamental algebraic expansions for multiplying and factoring binomials and polynomials.',
    items: [
      {
        id: 'alg_square_sum',
        name: 'Square of a Sum',
        formula: '(a + b)^2 = a^2 + 2ab + b^2',
        humanReadable: '(a + b)² = a² + 2ab + b²',
        example: 'If a=3, b=2: (3 + 2)² = 25; 3² + 2(3)(2) + 2² = 9 + 12 + 4 = 25.'
      },
      {
        id: 'alg_square_diff',
        name: 'Square of a Difference',
        formula: '(a - b)^2 = a^2 - 2ab + b^2',
        humanReadable: '(a - b)² = a² - 2ab + b²',
        example: 'If a=5, b=1: (5 - 1)² = 16; 5² - 2(5)(1) + 1² = 25 - 10 + 1 = 16.'
      },
      {
        id: 'alg_diff_squares',
        name: 'Difference of Two Squares',
        formula: 'a^2 - b^2 = (a - b)(a + b)',
        humanReadable: 'a² - b² = (a - b)(a + b)',
        example: 'x² - 9 = (x - 3)(x + 3).'
      },
      {
        id: 'alg_cube_sum_exp',
        name: 'Cube of a Sum',
        formula: '(a + b)^3 = a^3 + 3a^2b + 3ab^2 + b^3',
        humanReadable: '(a + b)³ = a³ + 3a²b + 3ab² + b³',
        example: '(x + 2)³ = x³ + 6x² + 12x + 8.'
      },
      {
        id: 'alg_cube_diff_exp',
        name: 'Cube of a Difference',
        formula: '(a - b)^3 = a^3 - 3a^2b + 3ab^2 - b^3',
        humanReadable: '(a - b)³ = a³ - 3a²b + 3ab² - b³',
        example: '(x - 1)³ = x³ - 3x² + 3x - 1.'
      },
      {
        id: 'alg_sum_cubes',
        name: 'Sum of Two Cubes',
        formula: 'a^3 + b^3 = (a + b)(a^2 - ab + b^2)',
        humanReadable: 'a³ + b³ = (a + b)(a² - ab + b²)',
        example: 'x³ + 8 = (x + 2)(x² - 2x + 4).'
      },
      {
        id: 'alg_diff_cubes',
        name: 'Difference of Two Cubes',
        formula: 'a^3 - b^3 = (a - b)(a^2 + ab + b^2)',
        humanReadable: 'a³ - b³ = (a - b)(a² + ab + b²)',
        example: 'x³ - 27 = (x - 3)(x² + 3x + 9).'
      },
      {
        id: 'alg_square_trinomial',
        name: 'Square of a Trinomial',
        formula: '(a + b + c)^2 = a^2 + b^2 + c^2 + 2(ab + bc + ca)',
        humanReadable: '(a + b + c)² = a² + b² + c² + 2(ab + bc + ca)',
        example: '(x + y + 2)² = x² + y² + 4 + 2xy + 4y + 4x.'
      },
      {
        id: 'alg_cube_trinomial',
        name: 'Cube of a Trinomial',
        formula: '(a + b + c)^3 = a^3 + b^3 + c^3 + 3(a + b)(b + c)(c + a)',
        humanReadable: '(a + b + c)³ = a³ + b³ + c³ + 3(a + b)(b + c)(c + a)',
        example: 'If a=1, b=1, c=1: 3³ = 27; 1+1+1 + 3(2)(2)(2) = 3 + 24 = 27.'
      }
    ]
  },
  {
    categoryName: 'Quadratic Equations & Radicals',
    description: 'Formulas for solving second-degree polynomials and manipulating rational powers.',
    items: [
      {
        id: 'alg_quadratic',
        name: 'Quadratic Formula',
        formula: 'x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}',
        humanReadable: 'x = [-b ± √(b² - 4ac)] / (2a)',
        example: 'For x² - 5x + 6 = 0: x = [5 ± √(25 - 24)] / 2 = [5 ± 1] / 2 ➜ x = 3 or x = 2.'
      },
      {
        id: 'alg_discriminant',
        name: 'Discriminant (Δ)',
        formula: '\\Delta = b^2 - 4ac',
        humanReadable: 'Δ = b² - 4ac',
        example: 'For x² + x + 1 = 0: Δ = 1² - 4(1)(1) = -3 < 0 (complex roots).'
      },
      {
        id: 'alg_roots_sum_product',
        name: "Vieta's Formulas (Quadratic)",
        formula: 'x_1 + x_2 = -\\frac{b}{a}, \\quad x_1 x_2 = \\frac{c}{a}',
        humanReadable: 'Sum = -b/a,  Product = c/a',
        example: 'For 2x² - 8x + 6 = 0, sum of roots x₁ + x₂ = 8/2 = 4; product x₁·x₂ = 6/2 = 3.'
      },
      {
        id: 'alg_roots_cubic',
        name: "Vieta's Formulas (Cubic)",
        formula: 'x_1 + x_2 + x_3 = -\\frac{b}{a}, \\quad x_1x_2 + x_2x_3 + x_3x_1 = \\frac{c}{a}, \x00 \\quad x_1x_2x_3 = -\\frac{d}{a}',
        humanReadable: 'Sum = -b/a,  Product Sum = c/a,  Constant Prod = -d/a',
        example: 'For x³ - 6x² + 11x - 6 = 0: x₁ + x₂ + x₃ = 6; x₁·x₂·x₃ = 6.'
      },
      {
        id: 'alg_radical_prod',
        name: 'Product Rule of Radicals',
        formula: '\\sqrt[n]{ab} = \\sqrt[n]{a} \\cdot \\sqrt[n]{b}',
        humanReadable: 'ⁿ√(a · b) = ⁿ√a · ⁿ√b',
        example: '√50 = √(25·2) = √25 · √2 = 5√2.'
      },
      {
        id: 'alg_exponent_fraction',
        name: 'Fractional Exponents',
        formula: 'a^{\\frac{m}{n}} = \\sqrt[n]{a^m}',
        humanReadable: 'a^(m/n) = ⁿ√(a^m)',
        example: '8^(2/3) = ³√(8²) = ³√64 = 4.'
      },
      {
        id: 'alg_sqrt_double_rad',
        name: 'Square Root of a Double Radical',
        formula: '\\sqrt{a \\pm 2\\sqrt{b}} = \\sqrt{x} \\pm \\sqrt{y}',
        humanReadable: '√(a ± 2√b) = √x ± √y  [where x + y = a, x · y = b]',
        example: '√(5 + 2√6) = √3 + √2 (since 3+2=5, 3·2=6).'
      }
    ]
  },
  {
    categoryName: 'Logarithmic Definitions & Laws',
    description: 'Operational properties for exponential inverses in bases constant, log, or natural ln.',
    items: [
      {
        id: 'alg_log_def',
        name: 'Logarithm Definition',
        formula: '\\log_b(x) = y \\iff b^y = x',
        humanReadable: 'log_b(x) = y  ⟺  b^y = x',
        example: 'log₁₀(1000) = 3 because 10³ = 1000.'
      },
      {
        id: 'alg_log_product',
        name: 'Product Rule',
        formula: '\\log_b(xy) = \\log_b(x) + \\log_b(y)',
        humanReadable: 'log_b(xy) = log_b(x) + log_b(y)',
        example: 'log₂(8 · 4) = log₂(8) + log₂(4) = 3 + 2 = 5.'
      },
      {
        id: 'alg_log_quotient',
        name: 'Quotient Rule',
        formula: '\\log_b(\\frac{x}{y}) = \\log_b(x) - \\log_b(y)',
        humanReadable: 'log_b(x/y) = log_b(x) - log_b(y)',
        example: 'ln(e / 1) = ln(e) - ln(1) = 1 - 0 = 1.'
      },
      {
        id: 'alg_log_power',
        name: 'Power Rule',
        formula: '\\log_b(x^k) = k \\cdot \\log_b(x)',
        humanReadable: 'log_b(x^k) = k · log_b(x)',
        example: 'log₁₀(10⁵) = 5 · log₁₀(10) = 5 · 1 = 5.'
      },
      {
        id: 'alg_log_base_change',
        name: 'Change of Base Formula',
        formula: '\\log_a(x) = \\frac{\\log_b(x)}{\\log_b(a)}',
        humanReadable: 'log_a(x) = log_b(x) / log_b(a)',
        example: 'log₃(7) = ln(7) / ln(3) ≈ 1.9459 / 1.0986 = 1.7712.'
      },
      {
        id: 'alg_log_identity_inv',
        name: 'Reciprocal Base Identity',
        formula: '\\log_a(b) = \\frac{1}{\\log_b(a)}',
        humanReadable: 'log_a(b) = 1 / log_b(a)',
        example: 'log₈(2) = 1 / log₂(8) = 1 / 3 = 0.3333.'
      },
      {
        id: 'alg_log_base_power',
        name: 'Base-to-Power Identity',
        formula: '\\log_{b^r}(x) = \\frac{1}{r} \\log_b(x)',
        humanReadable: 'log_{b^r}(x) = (1/r) · log_b(x)',
        example: 'log₉(27) = log_{3²}(27) = ½ · log₃(27) = ½ · 3 = 1.5.'
      },
      {
        id: 'alg_log_inv_ident',
        name: 'Power of Base Log Identity',
        formula: 'b^{\\log_b(x)} = x',
        humanReadable: 'b^(log_b(x)) = x',
        example: '10^(log₁₀(15)) = 15.'
      },
      {
        id: 'alg_log_zero_unity',
        name: 'Zero and Unity Log Rules',
        formula: '\\log_b(1) = 0, \\quad \\log_b(b) = 1',
        humanReadable: 'log_b(1) = 0,  log_b(b) = 1',
        example: 'log₄(1) = 0;  log₄(4) = 1.'
      }
    ]
  },
  {
    categoryName: 'Sequences, Series & Progression',
    description: 'Formula constructs evaluating sequential progressions and finite/infinite series summations.',
    items: [
      {
        id: 'alg_ap_nth',
        name: 'N-th Term of AP',
        formula: 'a_n = a_1 + (n - 1)d',
        humanReadable: 'a_n = a₁ + (n - 1)d',
        example: 'For AP 3, 7, 11, ... (a₁=3, d=4), the 10th term = 3 + 9(4) = 39.'
      },
      {
        id: 'alg_ap_sum',
        name: 'Sum of n Terms of AP',
        formula: 'S_n = \\frac{n}{2}[2a_1 + (n - 1)d]',
        humanReadable: 'S_n = (n/2) · [2a₁ + (n - 1)d]',
        example: 'Sum of first 100 positive integers = (100/2) · [2(1) + 99(1)] = 50 · 101 = 5050.'
      },
      {
        id: 'alg_gp_nth',
        name: 'N-th Term of GP',
        formula: 'a_n = a_1 \\cdot r^{n-1}',
        humanReadable: 'a_n = a₁ · r^(n-1)',
        example: 'For GP 2, 6, 18, ... (a₁=2, r=3), 5th term = 2 · 3⁴ = 2 · 81 = 162.'
      },
      {
        id: 'alg_gp_sum',
        name: 'Sum of GP (Finite)',
        formula: 'S_n = \\frac{a_1(1 - r^n)}{1 - r}',
        humanReadable: 'S_n = [a₁ · (1 - r^n)] / (1 - r)',
        example: 'Sum 2, 4, 8, 16 (n=4): [2(1 - 2⁴)] / (1-2) = [2(-15)] / -1 = 30.'
      },
      {
        id: 'alg_gp_infinite',
        name: 'Infinite Geometric Series Sum',
        formula: 'S_\\infty = \\frac{a_1}{1 - r}',
        humanReadable: 'S_∞ = a₁ / (1 - r)  [for |r| < 1]',
        example: 'Sum of 1 + 1/2 + 1/4 + 1/8 + ... = 1 / (1 - 0.5) = 2.'
      },
      {
        id: 'alg_binomial_thm',
        name: 'Binomial Theorem',
        formula: '(a + b)^n = \\sum_{k=0}^{n} \\binom{n}{k} a^{n-k} b^k',
        humanReadable: '(a+b)ⁿ = Σ [C(n,k) · a^(n-k) · b^k]',
        example: '(x + y)⁴ = x⁴ + 4x³y + 6x²y² + 4xy³ + y⁴.'
      },
      {
        id: 'alg_sum_integers',
        name: 'Sum of First n Natural Numbers',
        formula: '\\sum_{k=1}^{n} k = \\frac{n(n + 1)}{2}',
        humanReadable: 'Sum(1..n) = n(n + 1) / 2',
        example: '1+2+...+10 = 10 · 11 / 2 = 55.'
      },
      {
        id: 'alg_sum_squares',
        name: 'Sum of Squares of First n Numbers',
        formula: '\\sum_{k=1}^{n} k^2 = \\frac{n(n+1)(2n+1)}{6}',
        humanReadable: 'Sum(k²) = n(n+1)(2n+1) / 6',
        example: '1² + 2² + 3² = 14; (3 · 4 · 7) / 6 = 14.'
      },
      {
        id: 'alg_sum_cubes',
        name: 'Sum of Cubes of First n Numbers',
        formula: '\\sum_{k=1}^{n} k^3 = \\left[ \\frac{n(n + 1)}{2} \\right]^2',
        humanReadable: 'Sum(k³) = [n(n + 1) / 2]²',
        example: '1³ + 2³ + 3³ = 36; [3 · 4 / 2]² = 36.'
      }
    ]
  },
  {
    categoryName: 'Complex Numbers & Exponent Rules',
    description: 'Fundamental equations for imaginary components, Euler representations, and logarithmic indices.',
    items: [
      {
        id: 'alg_complex_i',
        name: 'Imaginary Unit Definition',
        formula: 'i^2 = -1',
        humanReadable: 'i² = -1',
        example: '(3i)² = 9i² = -9.'
      },
      {
        id: 'alg_complex_conjugate',
        name: 'Product of Complex Conjugates',
        formula: '(a + bi)(a - bi) = a^2 + b^2',
        humanReadable: '(a + bi)(a - bi) = a² + b²',
        example: '(4 + 3i)(4 - 3i) = 16 - 9i² = 25.'
      },
      {
        id: 'alg_euler_identity',
        name: "Euler's Identity",
        formula: 'e^{i\\pi} + 1 = 0',
        humanReadable: 'e^(iπ) + 1 = 0',
        example: 'Derived from Euler\'s formula when θ = π.'
      },
      {
        id: 'alg_demoivre',
        name: "De Moivre's Theorem",
        formula: '[r(\\cos(\\theta) + i\\sin(\\theta))]^n = r^n[\\cos(n\\theta) + i\\sin(n\\theta)]',
        humanReadable: '[r(cos(θ) + i sin(θ))]ⁿ = rⁿ[cos(nθ) + i sin(nθ)]',
        example: '[cos(30°) + i sin(30°)]³ = cos(90°) + i sin(90°) = i.'
      },
      {
        id: 'alg_exp_prod',
        name: 'Exponent Product Law',
        formula: 'a^m \\cdot a^n = a^{m+n}',
        humanReadable: 'aᵐ · aⁿ = a^(m+n)',
        example: '2³ · 2⁴ = 2⁷ = 128.'
      },
      {
        id: 'alg_exp_quot',
        name: 'Exponent Quotient Law',
        formula: '\\frac{a^m}{a^n} = a^{m-n}',
        humanReadable: 'aᵐ / aⁿ = a^(m-n)',
        example: '5⁶ / 5⁴ = 5² = 25.'
      },
      {
        id: 'alg_exp_power',
        name: 'Power of a Power Law',
        formula: '(a^m)^n = a^{m \\cdot n}',
        humanReadable: '(aᵐ)ⁿ = a^(m·n)',
        example: '(2³)² = 2⁶ = 64.'
      },
      {
        id: 'alg_exp_distrib',
        name: 'Power of a Product Law',
        formula: '(ab)^n = a^n b^n',
        humanReadable: '(ab)ⁿ = aⁿ · bⁿ',
        example: '(2 · 3)³ = 6³ = 216; 2³ · 3³ = 8 · 27 = 216.'
      }
    ]
  },
  {
    categoryName: 'Vector Analysis',
    description: 'Fundamental algebraic formulations of multi-dimensional vector systems, including dot/cross products and geometric angles.',
    items: [
      {
        id: 'vec_dot_product',
        name: 'Dot Product (Scalar Product)',
        formula: '\\vec{a} \\cdot \\vec{b} = a_1b_1 + a_2b_2 + a_3b_3 = |\\vec{a}| |\\vec{b}| \\cos(\\theta)',
        humanReadable: 'a⃗ · b⃗ = a₁b₁ + a₂b₂ + a₃b₃ = |a⃗| · |b⃗| · cos(θ)',
        example: 'For a⃗ = (1, 3, -5) and b⃗ = (4, -2, -1): a⃗ · b⃗ = 1(4) + 3(-2) + (-5)(-1) = 4 - 6 + 5 = 3.'
      },
      {
        id: 'vec_cross_product',
        name: 'Vector Cross Product',
        formula: '\\vec{a} \\times \\vec{b} = (a_2b_3 - a_3b_2)\\hat{i} - (a_1b_3 - a_3b_1)\\hat{j} + (a_1b_2 - a_2b_1)\\hat{k}',
        humanReadable: 'a⃗ × b⃗ = (a₂b₃ - a₃b₂)î - (a₁b₃ - a₃b₁)ĵ + (a₁b₂ - a₂b₁)k̂',
        example: 'For a⃗ = (2, 3, 4) and b⃗ = (5, 6, 7): a⃗ × b⃗ = (3·7 - 4·6)î - (2·7 - 4·5)ĵ + (2·6 - 3·5)k̂ = -3î + 6ĵ - 3k̂.'
      },
      {
        id: 'vec_angle',
        name: 'Angle Between Two Vectors',
        formula: '\\cos(\\theta) = \\frac{\\vec{a} \\cdot \\vec{b}}{|\\vec{a}| |\\vec{b}|}',
        humanReadable: 'cos(θ) = (a⃗ · b⃗) / (|a⃗| · |b⃗|)',
        example: 'If a⃗ · b⃗ = 6, |a⃗| = 2, |b⃗| = 6: cos(θ) = 6 / (2 · 6) = 0.5 ➜ θ = 60°.'
      },
      {
        id: 'vec_magnitude',
        name: 'Vector Magnitude (3D)',
        formula: '|\\vec{v}| = \\sqrt{v_1^2 + v_2^2 + v_3^2}',
        humanReadable: '|v⃗| = √(v₁² + v₂² + v₃²)',
        example: 'For v⃗ = (3, -4, 12): |v⃗| = √(3² + (-4)² + 12²) = √(9 + 16 + 144) = 13.'
      }
    ]
  }
];

export const TRIG_FORMULAS: FormulaCategory[] = [
  {
    categoryName: 'Pythagorean & Reciprocal Identities',
    description: 'Symmetry links of modern trigonometric ratios based on the standard unit circle and perpendicular properties.',
    items: [
      {
        id: 'trig_pythag_1',
        name: 'Pythagorean Identity I',
        formula: '\\sin^2(\\theta) + \\cos^2(\\theta) = 1',
        humanReadable: 'sin²(θ) + cos²(θ) = 1',
        example: 'If sin(θ) = 0.6, cos²(θ) = 1 - 0.36 = 0.64 ➜ cos(θ) = 0.8.'
      },
      {
        id: 'trig_pythag_2',
        name: 'Pythagorean Identity II',
        formula: '1 + \\tan^2(\\theta) = \\sec^2(\\theta)',
        humanReadable: '1 + tan²(θ) = sec²(θ)',
        example: 'If tan(θ) = 2, sec²(θ) = 1 + 4 = 5 ➜ sec(θ) = √5.'
      },
      {
        id: 'trig_pythag_3',
        name: 'Pythagorean Identity III',
        formula: '1 + \\cot^2(\\theta) = \\csc^2(\\theta)',
        humanReadable: '1 + cot²(θ) = csc²(θ)',
        example: 'If cot(θ) = 3, csc²(θ) = 1 + 9 = 10 ➜ csc(θ) = √10.'
      },
      {
        id: 'trig_reciprocals',
        name: 'Reciprocal Definitions',
        formula: '\\csc(\\theta) = \\frac{1}{\\sin(\\theta)}, \\quad \\sec(\\theta) = \\frac{1}{\\cos(\\theta)}, \\quad \\cot(\\theta) = \\frac{1}{\\tan(\\theta)}',
        humanReadable: 'csc(θ) = 1/sin(θ),  sec(θ) = 1/cos(θ),  cot(θ) = 1/tan(θ)',
        example: 'If cos(θ) = 0.5, sec(θ) = 1 / 0.5 = 2.'
      },
      {
        id: 'trig_ratio_def',
        name: 'Ratio Definitions',
        formula: '\\tan(\\theta) = \\frac{\\sin(\\theta)}{\\cos(\\theta)}, \\quad \\cot(\\theta) = \\frac{\\cos(\\theta)}{\\sin(\\theta)}',
        humanReadable: 'tan(θ) = sin(θ) / cos(θ),  cot(θ) = cos(θ) / sin(θ)',
        example: 'If sin(θ) = 0.5 and cos(θ) = 0.866, then tan(θ) ≈ 0.5 / 0.866 = 0.577.'
      },
      {
        id: 'trig_sin_cos_var',
        name: 'Pythagorean Alternative Forms',
        formula: '\\sin^2(\\theta) = 1 - \\cos^2(\\theta), \\quad \\cos^2(\\theta) = 1 - \\sin^2(\\theta)',
        humanReadable: 'sin²(θ) = 1 - cos²(θ),  cos²(θ) = 1 - sin²(θ)',
        example: 'If cos(θ) = 0.8, sin²(θ) = 1 - 0.64 = 0.36.'
      }
    ]
  },
  {
    categoryName: 'Double & Half-Angle Formulas',
    description: 'Shortcuts resolving multiple frequencies or fractional divisions without computing raw boundaries.',
    items: [
      {
        id: 'trig_double_sin',
        name: 'Double Angle Sine',
        formula: '\\sin(2\\theta) = 2\\sin(\\theta)\\cos(\\theta)',
        humanReadable: 'sin(2θ) = 2 · sin(θ) · cos(θ)',
        example: 'If θ = 30°: sin(60°) = √3/2 ≈ 0.866; 2·sin(30°)·cos(30°) = 2 · (0.5) · (√3/2) = √3/2.'
      },
      {
        id: 'trig_double_cos',
        name: 'Double Angle Cosine',
        formula: '\\cos(2\\theta) = \\cos^2(\\theta) - \\sin^2(\\theta) = 2\\cos^2(\\theta) - 1 = 1 - 2\\sin^2(\\theta)',
        humanReadable: 'cos(2θ) = cos²(θ) - sin²(θ) = 2cos²(θ) - 1 = 1 - 2sin²(θ)',
        example: 'If θ = 45°: cos(90°) = 0; cos²(45°) - sin²(45°) = 0.5 - 0.5 = 0.'
      },
      {
        id: 'trig_double_tan',
        name: 'Double Angle Tangent',
        formula: '\\tan(2\\theta) = \\frac{2\\tan(\\theta)}{1 - \\tan^2(\\theta)}',
        humanReadable: 'tan(2θ) = 2tan(θ) / (1 - tan²(θ))',
        example: 'If tan(θ) = 1/2: tan(2θ) = (2 · 1/2) / (1 - 1/4) = 1 / (3/4) = 4/3.'
      },
      {
        id: 'trig_half_sin',
        name: 'Half Angle Sine',
        formula: '\\sin(\\frac{\\theta}{2}) = \\pm \\sqrt{\\frac{1 - \\cos(\\theta)}{2}}',
        humanReadable: 'sin(θ/2) = ± √[(1 - cos(θ)) / 2]',
        example: 'For θ = 90°: sin(45°) = √[(1 - 0) / 2] = 1/√2 ≈ 0.7071.'
      },
      {
        id: 'trig_half_cos',
        name: 'Half Angle Cosine',
        formula: '\\cos(\\frac{\\theta}{2}) = \\pm \\sqrt{\\frac{1 + \\cos(\\theta)}{2}}',
        humanReadable: 'cos(θ/2) = ± √[(1 + cos(θ)) / 2]',
        example: 'For θ = 60°: cos(30°) = √[(1 + 0.5) / 2] = √(1.5/2) = √3/2 ≈ 0.866.'
      },
      {
        id: 'trig_half_tan',
        name: 'Half Angle Tangent',
        formula: '\\tan(\\frac{\\theta}{2}) = \\frac{1 - \\cos(\\theta)}{\\sin(\\theta)} = \\frac{\\sin(\\theta)}{1 + \\cos(\\theta)}',
        humanReadable: 'tan(θ/2) = (1 - cos(θ)) / sin(θ) = sin(θ) / (1 + cos(θ))',
        example: 'For θ = 90°: tan(45°) = 1; (1 - 0) / 1 = 1.'
      },
      {
        id: 'trig_sin_power_red',
        name: 'Sine Squared Power Reduction',
        formula: '\\sin^2(\\theta) = \\frac{1 - \\cos(2\\theta)}{2}',
        humanReadable: 'sin²(θ) = [1 - cos(2θ)] / 2',
        example: 'For θ=45°, sin²(45°) = 0.5; [1 - cos(90°)] / 2 = 0.5.'
      },
      {
        id: 'trig_cos_power_red',
        name: 'Cosine Squared Power Reduction',
        formula: '\\cos^2(\\theta) = \\frac{1 + \\cos(2\\theta)}{2}',
        humanReadable: 'cos²(θ) = [1 + cos(2θ)] / 2',
        example: 'For θ=45°, cos²(45°) = 0.5; [1 + cos(90°)] / 2 = 0.5.'
      }
    ]
  },
  {
    categoryName: 'Sum & Difference Formulas',
    description: 'Expands functions whose inputs are summed or subtracted ratios.',
    items: [
      {
        id: 'trig_sum_sin',
        name: 'Angle Addition (Sine)',
        formula: '\\sin(A \\pm B) = \\sin(A)\\cos(B) \\pm \\cos(A)\\sin(B)',
        humanReadable: 'sin(A ± B) = sin(A)cos(B) ± cos(A)sin(B)',
        example: 'sin(75°) = sin(45°+30°) = sin(45°)cos(30°) + cos(45°)sin(30°) = (√2/2)(√3/2) + (√2/2)(1/2) = (√6+√2)/4 ≈ 0.9659.'
      },
      {
        id: 'trig_sum_cos',
        name: 'Angle Addition (Cosine)',
        formula: '\\cos(A \\pm B) = \\cos(A)\\cos(B) \\mp \\sin(A)\\sin(B)',
        humanReadable: 'cos(A ± B) = cos(A)cos(B) ∓ sin(A)sin(B)',
        example: 'cos(75°) = cos(45°)cos(30°) - sin(45°)sin(30°) = (√6-√2)/4 ≈ 0.2588.'
      },
      {
        id: 'trig_sum_tan',
        name: 'Angle Addition (Tangent)',
        formula: '\\tan(A \\pm B) = \\frac{\\tan(A) \\pm \\tan(B)}{1 \\mp \\tan(A)\\tan(B)}',
        humanReadable: 'tan(A ± B) = [tan(A) ± tan(B)] / [1 ∓ tan(A)tan(B)]',
        example: 'tan(45°+30°) = (1 + √3/3) / (1 - √3/3) = (3+√3)/(3-√3) = 2+√3 ≈ 3.7321.'
      },
      {
        id: 'trig_sum_cot',
        name: 'Angle Addition (Cotangent)',
        formula: '\\cot(A \\pm B) = \\frac{\\cot(A)\\cot(B) \\mp 1}{\\cot(B) \\pm \\cot(A)}',
        humanReadable: 'cot(A ± B) = [cot(A)cot(B) ∓ 1] / [cot(B) ± cot(A)]',
        example: 'For A=45°, B=45°: cot(90°) = 0; [1·1 - 1]/[1+1] = 0.'
      }
    ]
  },
  {
    categoryName: 'Sum-to-Product & Product-to-Sum',
    description: 'Transforms sums to products (great for simplify stages) and products to sums (great for integration).',
    items: [
      {
        id: 'trig_pts_sin_cos',
        name: 'Product to Sum (Sine-Cosine)',
        formula: '\\sin(A)\\cos(B) = \\frac{1}{2}[\\sin(A+B) + \\sin(A-B)]',
        humanReadable: 'sin(A)cos(B) = ½ · [sin(A+B) + sin(A-B)]',
        example: 'sin(5x)cos(3x) = 1/2 · [sin(8x) + sin(2x)].'
      },
      {
        id: 'trig_pts_cos_cos',
        name: 'Product to Sum (Cosine-Cosine)',
        formula: '\\cos(A)\\cos(B) = \\frac{1}{2}[\\cos(A+B) + \\cos(A-B)]',
        humanReadable: 'cos(A)cos(B) = ½ · [cos(A+B) + cos(A-B)]',
        example: 'cos(4x)cos(2x) = 1/2 · [cos(6x) + cos(2x)].'
      },
      {
        id: 'trig_pts_sin_sin',
        name: 'Product to Sum (Sine-Sine)',
        formula: '\\sin(A)\\sin(B) = \\frac{1}{2}[\\cos(A-B) - \\cos(A+B)]',
        humanReadable: 'sin(A)sin(B) = ½ · [cos(A-B) - cos(A+B)]',
        example: 'sin(5x)sin(3x) = 1/2 · [cos(2x) - cos(8x)].'
      },
      {
        id: 'trig_stp_sin_sum',
        name: 'Sum to Product (Sine Sum)',
        formula: '\\sin(A) + \\sin(B) = 2\\sin(\\frac{A+B}{2})\\cos(\\frac{A-B}{2})',
        humanReadable: 'sin(A) + sin(B) = 2sin((A+B)/2)cos((A-B)/2)',
        example: 'sin(5θ) + sin(3θ) = 2sin(4θ)cos(θ).'
      },
      {
        id: 'trig_stp_sin_diff',
        name: 'Sum to Product (Sine Difference)',
        formula: '\\sin(A) - \\sin(B) = 2\\cos(\\frac{A+B}{2})\\sin(\\frac{A-B}{2})',
        humanReadable: 'sin(A) - sin(B) = 2cos((A+B)/2)sin((A-B)/2)',
        example: 'sin(5θ) - sin(3θ) = 2cos(4θ)sin(θ).'
      },
      {
        id: 'trig_stp_cos_sum',
        name: 'Sum to Product (Cosine Sum)',
        formula: '\\cos(A) + \\cos(B) = 2\\cos(\\frac{A+B}{2})\\cos(\\frac{A-B}{2})',
        humanReadable: 'cos(A) + cos(B) = 2cos((A+B)/2)cos((A-B)/2)',
        example: 'cos(5θ) + cos(3θ) = 2cos(4θ)cos(θ).'
      },
      {
        id: 'trig_stp_cos_diff',
        name: 'Sum to Product (Cosine Difference)',
        formula: '\\cos(A) - \\cos(B) = -2\\sin(\\frac{A+B}{2})\\sin(\\frac{A-B}{2})',
        humanReadable: 'cos(A) - cos(B) = -2sin((A+B)/2)sin((A-B)/2)',
        example: 'cos(5θ) - cos(3θ) = -2sin(4θ)sin(θ).'
      }
    ]
  },
  {
    categoryName: 'Triangles Laws & Formulas',
    description: 'Trigonometric configurations resolving dimensions for any non-right (oblique) triangles.',
    items: [
      {
        id: 'trig_law_sines',
        name: 'Law of Sines',
        formula: '\\frac{a}{\\sin(A)} = \\frac{b}{\\sin(B)} = \\frac{c}{\\sin(C)} = 2R',
        humanReadable: 'a/sin(A) = b/sin(B) = c/sin(C) = 2R',
        example: 'In triangle with side a=10 opposite to A=30°: a / sin(30°) = 10 / 0.5 = 20 (so circumdiameter is 20).'
      },
      {
        id: 'trig_law_cosines',
        name: 'Law of Cosines',
        formula: 'c^2 = a^2 + b^2 - 2ab\\cos(C)',
        humanReadable: 'c² = a² + b² - 2ab · cos(C)',
        example: 'If a=5, b=8, C=60°: c² = 25 + 64 - 2(5)(8)(0.5) = 89 - 40 = 49 ➜ c = 7.'
      },
      {
        id: 'trig_triangle_area',
        name: 'Sine Area Formula',
        formula: '\\text{Area} = \\frac{1}{2}ab\\sin(C)',
        humanReadable: 'Area = ½ · a · b · sin(C)',
        example: 'If a=10, b=6, C=30°: Area = 0.5 · 10 · 6 · sin(30°) = 30 · 0.5 = 15.'
      },
      {
        id: 'trig_law_tangents',
        name: 'Law of Tangents',
        formula: '\\frac{a - b}{a + b} = \\frac{\\tan(\\frac{A - B}{2})}{\\tan(\\frac{A + B}{2})}',
        humanReadable: '(a - b) / (a + b) = tan((A - B)/2) / tan((A + B)/2)',
        example: 'Relates side lengths and angles in oblique triangles.'
      },
      {
        id: 'trig_heron_formula',
        name: "Heron's Formula",
        formula: '\\text{Area} = \\sqrt{s(s-a)(s-b)(s-c)}',
        humanReadable: 'Area = √[s(s-a)(s-b)(s-c)]  [where s = (a+b+c)/2]',
        example: 'For a triangle with sides 3, 4, 5: semiperimeter s = 6, Area = √(6·3·2·1) = 6.'
      }
    ]
  },
  {
    categoryName: 'Co-functions, Periodicity & Even-Odd Dynamics',
    description: 'Periodic phase shifts and symmetrical characteristics of functions based on negative angles.',
    items: [
      {
        id: 'trig_odd_sin',
        name: 'Sine Odd Symmetry',
        formula: '\\sin(-\\theta) = -\\sin(\\theta)',
        humanReadable: 'sin(-θ) = -sin(θ)',
        example: 'sin(-30°) = -sin(30°) = -0.5.'
      },
      {
        id: 'trig_even_cos',
        name: 'Cosine Even Symmetry',
        formula: '\\cos(-\\theta) = \\cos(\\theta)',
        humanReadable: 'cos(-θ) = cos(θ)',
        example: 'cos(-60°) = cos(60°) = 0.5.'
      },
      {
        id: 'trig_odd_tan',
        name: 'Tangent Odd Symmetry',
        formula: '\\tan(-\\theta) = -\\tan(\\theta)',
        humanReadable: 'tan(-θ) = -tan(θ)',
        example: 'tan(-45°) = -tan(45°) = -1.'
      },
      {
        id: 'trig_cofunc_sin_cos',
        name: 'Sine-Cosine Co-function',
        formula: '\\sin(\\frac{\\pi}{2} - \\theta) = \\cos(\\theta)',
        humanReadable: 'sin(π/2 - θ) = cos(θ)',
        example: 'sin(90° - 30°) = sin(60°) = cos(30°) = √3/2.'
      },
      {
        id: 'trig_cofunc_cos_sin',
        name: 'Cosine-Sine Co-function',
        formula: '\\cos(\\frac{\\pi}{2} - \\theta) = \\sin(\\theta)',
        humanReadable: 'cos(π/2 - θ) = sin(θ)',
        example: 'cos(90° - 30°) = cos(60°) = sin(30°) = 0.5.'
      },
      {
        id: 'trig_cofunc_tan_cot',
        name: 'Tangent-Cotangent Co-function',
        formula: '\\tan(\\frac{\\pi}{2} - \\theta) = \\cot(\\theta)',
        humanReadable: 'tan(π/2 - θ) = cot(θ)',
        example: 'tan(90° - 60°) = tan(30°) = cot(60°) = √3/3.'
      },
      {
        id: 'trig_triple_sin',
        name: 'Sine Triple Angle Formula',
        formula: '\\sin(3\\theta) = 3\\sin(\\theta) - 4\\sin^3(\\theta)',
        humanReadable: 'sin(3θ) = 3sin(θ) - 4sin³(θ)',
        example: 'For θ=30°: sin(90°) = 1; 3(0.5) - 4(0.125) = 1.5 - 0.5 = 1.'
      },
      {
        id: 'trig_triple_cos',
        name: 'Cosine Triple Angle Formula',
        formula: '\\cos(3\theta) = 4\\cos^3(\\theta) - 3\\cos(\\theta)',
        humanReadable: 'cos(3θ) = 4cos³(θ) - 3cos(θ)',
        example: 'For θ=0°: cos(0°) = 1; 4(1) - 3(1) = 1.'
      }
    ]
  }
];

export const SPECIAL_TRIG_VALUES = [
  { deg: 0, rad: '0', sin: '0', cos: '1', tan: '0', csc: '∞', sec: '1', cot: '∞' },
  { deg: 30, rad: 'π/6', sin: '1/2', cos: '√3/2', tan: '√3/3', csc: '2', sec: '2√3/3', cot: '√3' },
  { deg: 45, rad: 'π/4', sin: '√2/2', cos: '√2/2', tan: '1', csc: '√2', sec: '√2', cot: '1' },
  { deg: 60, rad: 'π/3', sin: '√3/2', cos: '1/2', tan: '√3', csc: '2√3/3', sec: '2', cot: '√3/3' },
  { deg: 90, rad: 'π/2', sin: '1', cos: '0', tan: '∞', csc: '1', sec: '∞', cot: '0' },
  { deg: 120, rad: '2π/3', sin: '√3/2', cos: '-1/2', tan: '-√3', csc: '2√3/3', sec: '-2', cot: '-√3/3' },
  { deg: 135, rad: '3π/4', sin: '√2/2', cos: '-√2/2', tan: '-1', csc: '√2', sec: '-√2', cot: '-1' },
  { deg: 150, rad: '5π/6', sin: '1/2', cos: '-√3/2', tan: '-√3/3', csc: '2', sec: '-2√3/3', cot: '-√3' },
  { deg: 180, rad: 'π', sin: '0', cos: '-1', tan: '0', csc: '∞', sec: '-1', cot: '∞' },
  { deg: 270, rad: '3π/2', sin: '-1', cos: '0', tan: '∞', csc: '-1', sec: '∞', cot: '0' },
  { deg: 360, rad: '2π', sin: '0', cos: '1', tan: '0', csc: '∞', sec: '1', cot: '∞' },
];
